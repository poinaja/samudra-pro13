# ♻ coding: utf-8 ♻ 
# ♻﴾sᴀмuᴅʀᴀ____ʙoтs﴿♻
# ♻cʀᴇᴀтoʀ: sᴀмuᴅʀᴀ♻
from samudra import *
from akad.ttypes import *
from thrift.unverting import *
from thrift.TMultiplexedProcessor import *
from thrift.TSerialization import *
from thrift.TRecursive import *
from thrift import transport, protocol, server
from multiprocessing import Pool, Process
from time import sleep
import pytz, datetime, pafy, time, timeit, random, sys, ast, re, os, json, subprocess, threading, string, codecs, requests, tweepy, ctypes, urllib, wikipedia, urllib.parse
from datetime import timedelta, date
from datetime import datetime
import html5lib
from random import randint
import requests,json,urllib3
import pyimgflip
_session = requests.session()
botStart = time.time()
try:
    import urllib.request as urllib2
except ImportError:
    import urllib2
#-----------------------------------------------------------------------
cl = LINE("")
cl.log("Auth Token : " + str(cl.authToken))

ki = LINE("")
ki.log("Auth Token : " + str(ki.authToken))

kk = LINE("")
kk.log("Auth Token : " + str(kk.authToken))

kc = LINE("")
kc.log("Auth Token : " + str(kc.authToken))

km = LINE("")
km.log("Auth Token : " + str(km.authToken))

kb = LINE("")
kb.log("Auth Token : " + str(kb.authToken))

kn = LINE("")
kn.log("Auth Token : " + str(kn.authToken))

ko = LINE("")
ko.log("Auth Token : " + str(ko.authToken))

kw = LINE("")
kw.log("Auth Token : " + str(kw.authToken))

ke = LINE("")
ke.log("Auth Token : " + str(ke.authToken))

ky = LINE("")
ky.log("Auth Token : " + str(ky.authToken))

aj = LINE("")
aj.log("Auth Token : " + str(aj.authToken))

sw = LINE("")
sw.log("Auth Token : " + str(sw.authToken))

print("---LOGIN DI SAMUDRA SUCCES---")
#-----------------------------------------------------------------------
stickeropen = codecs.open("sticker4.json","r","utf-8")
samstick = json.load(stickeropen)
paja = codecs.open("samudraadmin.json","r","utf-8")
samudraadmin = json.load(paja)
#------------------------------------------------------------------------
oepoll = OEPoll(cl)
call = cl
creator = [""]
owner = [""]
admin = [""]
staff = [""]
admin1 = [""]
selfmid = cl.getProfile().mid
Amid = ki.getProfile().mid
Bmid = kk.getProfile().mid
Cmid = kc.getProfile().mid
Dmid = km.getProfile().mid
Emid = kb.getProfile().mid
Fmid = kn.getProfile().mid
Gmid = ko.getProfile().mid
Hmid = kw.getProfile().mid
Imid = ke.getProfile().mid
Jmid = ky.getProfile().mid
Xmid = aj.getProfile().mid
Zmid = sw.getProfile().mid
KAC = [cl,ki,kk,kc,km,kb,kn,ko,kw,ke,ky,sw]
ABC = [ki,kk,kc,km,kb,kn,ko,kw,ke,ky]
Bots = [selfmid,Amid,Bmid,Cmid,Dmid,Emid,Fmid,Gmid,Hmid,Imid,Jmid,Xmid,Zmid]
Samudra = admin + staff

protectqr = []
protectkick = []
protectjoin = []
protectinvite = []
protectcancel = []
protectantijs = []
ghost = []

welcome = []
left = []

settings = {
    "Picture":False,
    "group":{},
    "groupPicture":False,
    "changePicture":False,
    "autoJoinTicket":False,
    "userAgent": [
        "Mozilla/5.0 (X11; U; Linux i586; de; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (X11; U; Linux amd64; rv:5.0) Gecko/20100101 Firefox/5.0 (Debian)",
        "Mozilla/5.0 (X11; U; Linux amd64; en-US; rv:5.0) Gecko/20110619 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0 FirePHP/0.5",
        "Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux x86_64) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; Linux ppc; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux AMD64) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; FreeBSD amd64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:5.0) Gecko/20110619 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; rv:6.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1.1; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.1; U; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.1; rv:2.0.1) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.0; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.0; rv:5.0) Gecko/20100101 Firefox/5.0"
    ]
}

wait = {
    "limit": 1,
    "owner":{},
    "admin":{},
    "addadmin":False,
    "delladmin":False,
    "staff":{},
    "addstaff":False,
    "dellstaff":False,
    "bots":{},
    "addbots":False,
    "dellbots":False,
    "blacklist":{},
    "wblacklist":False,
    "dblacklist":False,
    "Talkblacklist":{},
    "Talkwblacklist":False,
    "Talkdblacklist":False,
    "talkban":True,
    "contact":False,
    'autoJoin':True,
    'autoAdd':True,
    'left':False,
    'qr':False,
    'inv':False,
    'autoRead':False,
    'autoLeave':False,
    'autoLeave1':False,
    "detectMention":True,
    "Mentionkick":False,
    "welcomeOn":False,
    "leaveOn":False,
    "sticker":False,
    "selfbot":True,
    "setsticker":{
            "name": "",
            "status":False
            },
    "mention":"Ngintip lagi tak colok",
    "Respontag":"Nikah yuk",
    "welcome":"Selamat datang & semoga betah coy",
    "leave":"Selamat tinggal & semoga sampai tujuan amin",
    "comment":"Like like & like Samudra ",
    "message":"Makasih udah diadd butuh bantuan\nSelfbot only\nSelbot+asist\nProtect Room Ivent\nstiker Line\nPlease PM my creator\nid Line samudrabots.py\nmakasi sob..!\nhttps://line.me/ti/p/~samudrabots.py\nSamudra__Bots",
    }

read = {
    "readPoint":{},
    "readMember":{},
    "readTime":{},
    "ROM":{},
}

cctv = {
    "cyduk":{},
    "point":{},
    "sidermem":{}
}

with open('creator.json', 'r') as fp:
    creator = json.load(fp)
with open('owner.json', 'r') as fp:
    owner = json.load(fp)

Setbot = codecs.open("setting.json","r","utf-8")
Setmain = json.load(Setbot)

mulai = time.time()

tz = pytz.timezone("Asia/Jakarta")
timeNow = datetime.now(tz=tz)

def restart_program():
    python = sys.executable
    os.execl(python, python, * sys.argv)

def restartBot():
    python = sys.executable
    os.execl(python, python, *sys.argv)

def waktu(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d Hari %02d Jam %02d Menit %02d Detik' % (days, hours, mins, secs)

def runtime(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d Hari %02d Jam %02d Menit %02d Detik' % (days, hours, mins, secs)

def mentionMembers(to, mid):
    try:
        arrData = ""
        ginfo = cl.getGroup(to)
        textx = "「 Daftar Member 」\n\n1. "
        arr = []
        no = 1
        for i in mid:
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention
            if no < len(mid):
                no += 1
                textx += "「✭」{}. ".format(str(no))
            else:
                textx += "\n「 Total {} Member 」".format(str(len(mid)))
        cl.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def siderMembers(to, mid):
    try:
        arrData = ""
        textx = "Hello ".format(str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention+wait["mention"]
            if no < len(mid):
                no += 1
                textx += "%i. " % (num)
                num=(num+1)
            else:
                try:
                    no = "\n╚══[ {} ]".format(str(cl.getGroup(to).name))
                except:
                    no = "\n╚══[ Success ]"
        cl.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def welcomeMembers(to, mid):
    try:
        arrData = ""
        textx = "Hello ".format(str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            ginfo = cl.getGroup(to)
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention+wait["welcome"]+"\nNama grup : "+str(ginfo.name)
            if no < len(mid):
                no += 1
                textx += "%i " % (num)
                num=(num+1)
            else:
                try:
                    no = "\n╚══[ {} ]".format(str(cl.getGroup(to).name))
                except:
                    no = "\n╚══[ Success ]"
        cl.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def leaveMembers(to, mid):
    try:
        arrData = ""
        textx = "「 Respon Leave 」\nNah Loo ".format(str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            ginfo = cl.getGroup(to)
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention+wait["leave"]
            if no < len(mid):
                no += 1
                textx += "%i " % (num)
                num=(num+1)
            else:
                try:
                    no = "\n╚══[ {} ]".format(str(cl.getGroup(to).name))
                except:
                    no = "\n╚══[ Success ]"
        cl.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def sendMention(to, mid, firstmessage):
    try:
        arrData = ""
        text = "%s " %(str(firstmessage))
        arr = []
        mention = "@x \n"
        slen = str(len(text))
        elen = str(len(text) + len(mention) - 1)
        arrData = {'S':slen, 'E':elen, 'M':mid}
        arr.append(arrData)
        today = datetime.today()
        future = datetime(2018,3,1)
        hari = (str(future - today))
        comma = hari.find(",")
        hari = hari[:comma]
        teman = cl.getAllContactIds()
        gid = cl.getGroupIdsJoined()
        tz = pytz.timezone("Asia/Jakarta")
        timeNow = datetime.now(tz=tz)
        eltime = time.time() - mulai
        bot = runtime(eltime)
        text += mention+"◐ Jam : "+datetime.strftime(timeNow,'%H:%M:%S')+" Wib\n⏩ Group : "+str(len(gid))+"\n⏩ Teman : "+str(len(teman))+"\n⏩ Expired : In "+hari+"\n⏩ Version : ANTIJS2\n⏩ Tanggal : "+datetime.strftime(timeNow,'%Y-%m-%d')+"\n⏩ Runtime : \n • "+bot
        cl.sendMessage(to, text, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def command(text):
    pesan = text.lower()
    if pesan.startswith(Setmain["keyCommand"]):
        cmd = pesan.replace(Setmain["keyCommand"],"")
    else:
        cmd = "command"
    return cmd

def help():
    key = Setmain["keyCommand"]
    key = key.title()
    helpMessage = "▬▬▬▬▬▬﴾👻༗߷༗👻﴿▬▬▬▬▬\n" + \
                  "╔══﴾ sᴀмuᴅʀᴀ____ʙoтs ﴿\n"+\
                  "║👻➸ " + key + "Help\n" + \
                  "║👻➸ " + key + "Help2\n" + \
                  "║👻➸ " + key + "Me\n" + \
                  "║👻➸ " + key + "Mid「@」\n" + \
                  "║👻➸ " + key + "Mybot\n" + \
                  "║👻➸ " + key + "Respon\n" + \
                  "║👻➸ " + key + "Status\n" + \
                  "║👻➸ " + key + "About\n" + \
                  "║👻➸ " + key + "Restart\n" + \
                  "║👻➸ " + key + "Runtime\n" + \
                  "║👻➸ " + key + "Creator\n" + \
                  "║👻➸ " + key + "Speed/Sp\n" + \
                  "║👻➸ " + key + "Tagall/All/Sayang\n" + \
                  "║👻➸ " + key + "In\n" + \
                  "║👻➸ " + key + "Out\n" + \
                  "║👻➸ " + key + "Invite\n" + \
                  "║👻➸ " + key + "Inviteme\n" + \
                  "║👻➸ " + key + "Leaveall\n" + \
                  "║👻➸ " + key + "Byeme\n" + \
                  "║👻➸ " + key + "Sider「on/off」\n" + \
                  "║👻➸ " + key + "Ginfo\n" + \
                  "║👻➸ " + key + "Open\n" + \
                  "║👻➸ " + key + "Close\n" + \
                  "║👻➸ " + key + "Url\n" + \
                  "║👻➸ " + key + "Gruplist\n" + \
                  "║👻➸ " + key + "Remove chat\n" + \
                  "║👻➸ " + key + "Broadcast:「Text」\n" + \
                  "║👻➸ " + key + "Setkey「New Key」\n" + \
                  "║👻➸ " + key + "Mykey\n" + \
                  "║👻➸ " + key + "Resetkey\n" + \
                  "╠══[ Kicker ]\n" + \
                  "║👻➸ " + key + "Kick「@」\n" + \
                  "║👻➸ " + key + "Vkick「@」\n" + \
                  "║👻➸ " + key + "Cancelall \n" + \
                  "║👻➸ " + key + "Clean \n" + \
                  "║👻➸ " + key + "Nk 「@」\n" + \
                  "╠══[ ᴍᴇᴅɪᴀ ]\n" + \
                  "║👻➸ " + key + "Spamtag:「jumlahnya」\n" + \
                  "║👻➸ " + key + "Spamtag\n" + \
                  "║👻➸ " + key + "Spamcall:「jumlahnya」\n" + \
                  "║👻➸ " + key + "Spamcall\n" + \
                  "║👻➸ " + key + "Ytmp4:「Judul Video」\n" + \
                  "╠══[ protect ]\n" + \
                  "║👻➸ " + key + "Allpro「on/off」\n" + \
                  "║👻➸ " + key + "Protecturl「on/off」\n" + \
                  "║👻➸ " + key + "Protectjoin「on/off」\n" + \
                  "║👻➸ " + key + "Protectkick「on/off」\n" + \
                  "║👻➸ " + key + "Protectinvite「on/off」\n" + \
                  "║👻➸ " + key + "Protectcancel「on/off」\n" + \
                  "║👻➸ " + key + "Antijs「on/off」\n" + \
                  "╠══[ Set user ]\n" + \
                  "║👻➸ " + key + "Autojoin「on/off」\n" + \
                  "╠══[ Set Admin ]\n" + \
                  "║👻➸ " + key + "Self「on/off」\n" + \
                  "║👻➸ " + key + "Staff:on\n" + \
                  "║👻➸ " + key + "Staff:repeat\n" + \
                  "║👻➸ " + key + "Admin:on\n" + \
                  "║👻➸ " + key + "Admin:repeat\n" + \
                  "║👻➸ " + key + "Staffadd「@」\n" + \
                  "║👻➸ " + key + "Staffdell「@」\n" + \
                  "║👻➸ " + key + "Adminadd「@」\n" + \
                  "║👻➸ " + key + "Admindell「@」\n" + \
                  "║👻➸ " + key + "Refresh\n" + \
                  "║👻➸ " + key + "Listbot\n" + \
                  "║👻➸ " + key + "Listadmin\n" + \
                  "║👻➸ " + key + "Listprotect\n" + \
                  "╚══﴾ sᴀмuᴅʀᴀ____ʙoтs ﴿\n" + \
                  "▬▬▬▬﴾👻༗߷༗👻﴿▬▬▬▬\n" + \
                  "\nιɴԍᴀт ᴅι「 Refresh 」sᴇsuᴅᴀн ᴘᴀκᴀι\n"
    return helpMessage

def helpbot():
    key = Setmain["keyCommand"]
    key = key.title()
    helpMessage1 = "▬▬▬▬﴾👻༗߷༗👻﴿▬▬▬▬\n" + \
                  "╔══﴾ sᴀмuᴅʀᴀ____ʙoтs ﴿\n"+\
                  "║➸ " + key + "Blc\n" + \
                  "║➸ " + key + "Ban:on\n" + \
                  "║➸ " + key + "Unban:on\n" + \
                  "║➸ " + key + "Ban「@」\n" + \
                  "║➸ " + key + "Unban「@」\n" + \
                  "║➸ " + key + "Talkban「@」\n" + \
                  "║➸ " + key + "Untalkban「@」\n" + \
                  "║➸ " + key + "Talkban:on\n" + \
                  "║➸ " + key + "Untalkban:on\n" + \
                  "║➸ " + key + "Banlist\n" + \
                  "║➸ " + key + "Talkbanlist\n" + \
                  "║➸ " + key + "Ceban\n" + \
                  "║➸ " + key + "Refresh\n" + \
                  "╠══[ Cek Seting ]\n" + \
                  "║➸ " + key + "Cek sider\n" + \
                  "║➸ " + key + "Cek spam\n" + \
                  "║➸ " + key + "Cek pesan \n" + \
                  "║➸ " + key + "Cek respon \n" + \
                  "║➸ " + key + "Cek leave\n" + \
                  "║➸ " + key + "Cek welcome\n" + \
                  "║➸ " + key + "Set sider:「Text」\n" + \
                  "║➸ " + key + "Set spam:「Text」\n" + \
                  "║➸ " + key + "Set pesan:「Text」\n" + \
                  "║➸ " + key + "Set respon:「Text」\n" + \
                  "║➸ " + key + "Set leave:「Text」\n" + \
                  "║➸ " + key + "Set welcome:「Text」\n" + \
                  "║➸ " + key + "Setsticker meme「kirim photo」\n" + \
                  "║➸ " + key + "Setsticker respon「kirim photo」\n" + \
                  "║➸ " + key + "Setsticker sider「kirim photo」\n" + \
                  "║➸ " + key + "Setsticker welcome「kirim photo」\n" + \
                  "║➸ " + key + "Setsticker leave「kirim photo」\n" + \
                  "║➸ " + key + "Myname:「Nama」\n" + \
                  "║➸ " + key + "Gift:「Mid korban」「Jumlah」\n" + \
                  "║➸ " + key + "Spam:「Mid korban」「Jumlah」\n" + \
                  "╚══﴾ sᴀмuᴅʀᴀ____ʙoтs ﴿\n" + \
                  "▬▬▬▬﴾👻༗߷༗👻﴿▬▬▬▬\n" + \
                  "\nιɴԍᴀт ᴅι「 Refresh 」sᴇsuᴅᴀн ᴘᴀκᴀι\n"
    return helpMessage1

def bot(op):
    global time
    global ast
    global groupParam
    try:
        if op.type == 0:
            return
#---------------PRO QR----------------------------------------------------------
        if op.type == 11:
            if op.param1 in protectqr:
                try:
                    if random.choice(ABC).getGroup(op.param1).preventedJoinByTicket == False:
                        if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in famzadmin["staff"]:
                            X = random.choice(ABC).getGroup(op.param1)
                            X.preventedJoinByTicket = True
                            random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
                            random.choice(ABC).updateGroup(X)
                            wait["blacklist"][op.param2] = True
                except:
                    pass
            if wait["qr"] == True:
                try:
                    if random.choice(ABC).getGroup(op.param1).preventedJoinByTicket == False:
                        if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in famzadmin["staff"]:
                            X = random.choice(ABC).getGroup(op.param1)
                            X.preventedJoinByTicket = True
                            random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
                            random.choice(ABC).updateGroup(X)
                            wait["blacklist"][op.param2] = True
                except:
                    pass
#---------------AUTO LEFT-------------------------------------------------------
        if op.type == 13:
            if selfmid in op.param3:
                if wait["autoLeave"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin:
                        cl.acceptGroupInvitation(op.param1)
                        ginfo = cl.getGroup(op.param1)
                        cl.sendMessage(op.param1,"Selamat Tinggal\n Group " +str(ginfo.name))
                        cl.leaveGroup(op.param1)
                    else:
                        cl.acceptGroupInvitation(op.param1)
                        ginfo = cl.getGroup(op.param1)
                        cl.sendMessage(op.param1,"Hai " + str(ginfo.name))
#---------------AUTO JOIN-------------------------------------------------------
        if op.type == 13:
            if selfmid in op.param3:
                if wait["autoJoin"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin:
                        cl.acceptGroupInvitation(op.param1)
                        ginfo = cl.getGroup(op.param1)
                        cl.sendMessage(op.param1,"Anda Bukan Admin")
                        cl.leaveGroup(op.param1)
                    else:
                        cl.acceptGroupInvitation(op.param1)
        if op.type == 13:
            if Amid in op.param3:
                if wait["autoJoin"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin:
                        ki.acceptGroupInvitation(op.param1)
                        ginfo = ki.getGroup(op.param1)
                        ki.sendMessage(op.param1,"Selamat Tinggal\n Group " +str(ginfo.name))
                        ki.leaveGroup(op.param1)
                    else:
                        ki.acceptGroupInvitation(op.param1)
                        group = ki.getGroup(op.param1)
                        nama = [contact.mid for contact in group.members]
                        for x in nama:
                            if x in wait["blacklist"]:
                                try:
                                    ki.kickoutFromGroup(op.param1,[x])
                                except:
                                    pass
        if op.type == 13:
            if Bmid in op.param3:
                if wait["autoJoin"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin:
                        kk.acceptGroupInvitation(op.param1)
                        ginfo = kk.getGroup(op.param1)
                        ki.sendMessage(op.param1,"Selamat Tinggal\n Group " +str(ginfo.name))
                        kk.leaveGroup(op.param1)
                    else:
                        kk.acceptGroupInvitation(op.param1)
                        group = kk.getGroup(op.param1)
                        nama = [contact.mid for contact in group.members]
                        for x in nama:
                            if x in wait["blacklist"]:
                                try:
                                    kk.kickoutFromGroup(op.param1,[x])
                                except:
                                    pass
        if op.type == 13:
            if Cmid in op.param3:
                if wait["autoJoin"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin:
                        kc.acceptGroupInvitation(op.param1)
                        ginfo = kc.getGroup(op.param1)
                        kc.sendMessage(op.param1,"Selamat Tinggal\n Group " +str(ginfo.name))
                        kc.leaveGroup(op.param1)
                    else:
                        kc.acceptGroupInvitation(op.param1)
                        group = kc.getGroup(op.param1)
                        nama = [contact.mid for contact in group.members]
                        for x in nama:
                            if x in wait["blacklist"]:
                                try:
                                    kc.kickoutFromGroup(op.param1,[x])
                                except:
                                    pass
        if op.type == 13:
            if Dmid in op.param3:
                if wait["autoJoin"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin:
                        km.acceptGroupInvitation(op.param1)
                        ginfo = km.getGroup(op.param1)
                        km.sendMessage(op.param1,"Selamat Tinggal\n Group " +str(ginfo.name))
                        km.leaveGroup(op.param1)
                    else:
                        km.acceptGroupInvitation(op.param1)
                        group = km.getGroup(op.param1)
                        nama = [contact.mid for contact in group.members]
                        for x in nama:
                            if x in wait["blacklist"]:
                                try:
                                    km.kickoutFromGroup(op.param1,[x])
                                except:
                                    pass
        if op.type == 13:
            if Emid in op.param3:
                if wait["autoJoin"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin:
                        kb.acceptGroupInvitation(op.param1)
                        ginfo = kb.getGroup(op.param1)
                        kb.sendMessage(op.param1,"Selamat Tinggal\n Group " +str(ginfo.name))
                        kb.leaveGroup(op.param1)
                    else:
                        kb.acceptGroupInvitation(op.param1)
                        group = kb.getGroup(op.param1)
                        nama = [contact.mid for contact in group.members]
                        for x in nama:
                            if x in wait["blacklist"]:
                                try:
                                    kb.kickoutFromGroup(op.param1,[x])
                                except:
                                    pass
        if op.type == 13:
            if Fmid in op.param3:
                if wait["autoJoin"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin:
                        kn.acceptGroupInvitation(op.param1)
                        ginfo = kn.getGroup(op.param1)
                        kn.sendMessage(op.param1,"Selamat Tinggal\n Group " +str(ginfo.name))
                        kn.leaveGroup(op.param1)
                    else:
                        kn.acceptGroupInvitation(op.param1)
                        group = kn.getGroup(op.param1)
                        nama = [contact.mid for contact in group.members]
                        for x in nama:
                            if x in wait["blacklist"]:
                                try:
                                    kn.kickoutFromGroup(op.param1,[x])
                                except:
                                    pass
        if op.type == 13:
            if Gmid in op.param3:
                if wait["autoJoin"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin:
                        ko.acceptGroupInvitation(op.param1)
                        ginfo = ko.getGroup(op.param1)
                        ko.sendMessage(op.param1,"Selamat Tinggal\n Group " +str(ginfo.name))
                        ko.leaveGroup(op.param1)
                    else:
                        ko.acceptGroupInvitation(op.param1)
                        group = ko.getGroup(op.param1)
                        nama = [contact.mid for contact in group.members]
                        for x in nama:
                            if x in wait["blacklist"]:
                                try:
                                    ko.kickoutFromGroup(op.param1,[x])
                                except:
                                    pass
        if op.type == 13:
            if Hmid in op.param3:
                if wait["autoJoin"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin:
                        kw.acceptGroupInvitation(op.param1)
                        ginfo = kw.getGroup(op.param1)
                        kw.sendMessage(op.param1,"Selamat Tinggal\n Group " +str(ginfo.name))
                        kw.leaveGroup(op.param1)
                    else:
                        kw.acceptGroupInvitation(op.param1)
                        group = kw.getGroup(op.param1)
                        nama = [contact.mid for contact in group.members]
                        for x in nama:
                            if x in wait["blacklist"]:
                                try:
                                    kw.kickoutFromGroup(op.param1,[x])
                                except:
                                    pass
        if op.type == 13:
            if Imid in op.param3:
                if wait["autoJoin"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin:
                        ke.acceptGroupInvitation(op.param1)
                        ginfo = ke.getGroup(op.param1)
                        ke.sendMessage(op.param1,"Selamat Tinggal\n Group " +str(ginfo.name))
                        ke.leaveGroup(op.param1)
                    else:
                        ke.acceptGroupInvitation(op.param1)
                        group = ke.getGroup(op.param1)
                        nama = [contact.mid for contact in group.members]
                        for x in nama:
                            if x in wait["blacklist"]:
                                try:
                                    ke.kickoutFromGroup(op.param1,[x])
                                except:
                                    pass
        if op.type == 13:
            if Jmid in op.param3:
                if wait["autoJoin"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin:
                        ky.acceptGroupInvitation(op.param1)
                        ginfo = ky.getGroup(op.param1)
                        ky.sendMessage(op.param1,"Selamat Tinggal\n Group " +str(ginfo.name))
                        ky.leaveGroup(op.param1)
                    else:
                        ky.acceptGroupInvitation(op.param1)
                        group = ky.getGroup(op.param1)
                        nama = [contact.mid for contact in group.members]
                        for x in nama:
                            if x in wait["blacklist"]:
                                try:
                                    ky.kickoutFromGroup(op.param1,[x])
                                except:
                                    pass
#---------------PRO INVITE------------------------------------------------------
        if op.type == 13:
            if op.param3 in wait["blacklist"]:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in famzadmin["staff"]:
                    try:
                        inv1 = op.param3.replace('\x1e',',')
                        inv2 = inv1.split(',')
                        for _mid in inv2:
                            if _mid not in Bots and _mid not in owner and _mid not in admin and _mid not in famzadmin["staff"]:
                                random.choice(ABC).cancelGroupInvitation(op.param1,[_mid])
                                random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
                                wait["blacklist"][op.param2] = True
                    except:
                        pass
        if op.type == 13:
            if op.param2 in wait["blacklist"]:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in famzadmin["staff"]:
                    try:
                        inv1 = op.param3.replace('\x1e',',')
                        inv2 = inv1.split(',')
                        for _mid in inv2:
                            if _mid not in Bots and _mid not in owner and _mid not in admin and _mid not in famzadmin["staff"]:
                                random.choice(ABC).cancelGroupInvitation(op.param1,[_mid])
                                random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
                                wait["blacklist"][op.param2] = True
                    except:
                        pass
        if op.type == 13:
            if op.param2 in wait["blacklist"]:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in famzadmin["staff"]:
                    try:
                        group = random.choice(ABC).getGroup(op.param1)
                        gMembMids = [contact.mid for contact in group.invitee]
                        for _mid in gMembMids:
                            if _mid in wait["blacklist"]:
                                random.choice(ABC).cancelGroupInvitation(op.param1,[_mid])
                                random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
                    except:
                        pass
        if op.type == 13:
            if op.param3 in wait["blacklist"]:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in famzadmin["staff"]:
                    try:
                        group = random.choice(ABC).getGroup(op.param1)
                        gMembMids = [contact.mid for contact in group.invitee]
                        for _mid in gMembMids:
                            if _mid in wait["blacklist"]:
                                random.choice(ABC).cancelGroupInvitation(op.param1,[_mid])
                                random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
                    except:
                        pass
        if op.type == 13:
            if op.param1 in protectinvite:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in famzadmin["staff"]:
                    try:
                        inv1 = op.param3.replace('\x1e',',')
                        inv2 = inv1.split(',')
                        for _mid in inv2:
                            if _mid not in Bots and _mid not in owner and _mid not in admin and _mid not in famzadmin["staff"]:
                                random.choice(ABC).cancelGroupInvitation(op.param1,[_mid])
                                random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
                                wait["blacklist"][op.param2] = True
                    except:
                        pass
            if wait["inv"] == True:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in famzadmin["staff"]:
                    try:
                        inv1 = op.param3.replace('\x1e',',')
                        inv2 = inv1.split(',')
                        for _mid in inv2:
                            if _mid not in Bots and _mid not in owner and _mid not in admin and _mid not in famzadmin["staff"]:
                                random.choice(ABC).cancelGroupInvitation(op.param1,[_mid])
                                random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
                                wait["blacklist"][op.param2] = True
                    except:
                        pass
#---------------PRO JOIN--------------------------------------------------------
        if op.type == 17:
            if op.param2 in wait["blacklist"]:
                group = ki.getGroup(op.param1)
                gMembMids = [contact.mid for contact in group.members]
                for _mid in gMembMids:
                    if _mid in wait["blacklist"]:
                        ki.kickoutFromGroup(op.param1,[_mid])
        if op.type == 17:
            if op.param2 in wait["blacklist"]:
                group = kk.getGroup(op.param1)
                gMembMids = [contact.mid for contact in group.members]
                for _mid in gMembMids:
                    if _mid in wait["blacklist"]:
                        kk.kickoutFromGroup(op.param1,[_mid])
        if op.type == 17:
            if op.param2 in wait["blacklist"]:
                group = kc.getGroup(op.param1)
                gMembMids = [contact.mid for contact in group.members]
                for _mid in gMembMids:
                    if _mid in wait["blacklist"]:
                        kc.kickoutFromGroup(op.param1,[_mid])
        if op.type == 17:
            if op.param2 in wait["blacklist"]:
                group = km.getGroup(op.param1)
                gMembMids = [contact.mid for contact in group.members]
                for _mid in gMembMids:
                    if _mid in wait["blacklist"]:
                        km.kickoutFromGroup(op.param1,[_mid])
        if op.type == 17:
            if op.param2 in wait["blacklist"]:
                group = kb.getGroup(op.param1)
                gMembMids = [contact.mid for contact in group.members]
                for _mid in gMembMids:
                    if _mid in wait["blacklist"]:
                        kb.kickoutFromGroup(op.param1,[_mid])
        if op.type == 17:
            if op.param2 in wait["blacklist"]:
                group = kn.getGroup(op.param1)
                gMembMids = [contact.mid for contact in group.members]
                for _mid in gMembMids:
                    if _mid in wait["blacklist"]:
                        kn.kickoutFromGroup(op.param1,[_mid])
        if op.type == 17:
            if op.param2 in wait["blacklist"]:
                group = ko.getGroup(op.param1)
                gMembMids = [contact.mid for contact in group.members]
                for _mid in gMembMids:
                    if _mid in wait["blacklist"]:
                        ko.kickoutFromGroup(op.param1,[_mid])
        if op.type == 17:
            if op.param2 in wait["blacklist"]:
                group = kw.getGroup(op.param1)
                gMembMids = [contact.mid for contact in group.members]
                for _mid in gMembMids:
                    if _mid in wait["blacklist"]:
                        kw.kickoutFromGroup(op.param1,[_mid])
        if op.type == 17:
            if op.param2 in wait["blacklist"]:
                group = ke.getGroup(op.param1)
                gMembMids = [contact.mid for contact in group.members]
                for _mid in gMembMids:
                    if _mid in wait["blacklist"]:
                        ke.kickoutFromGroup(op.param1,[_mid])
        if op.type == 17:
            if op.param2 in wait["blacklist"]:
                group = ky.getGroup(op.param1)
                gMembMids = [contact.mid for contact in group.members]
                for _mid in gMembMids:
                    if _mid in wait["blacklist"]:
                        ky.kickoutFromGroup(op.param1,[_mid])
#---------------MEMBER MASUK----------------------------------------------------
        if op.type == 17:
            if op.param1 in welcome:
                if op.param2 in Bots:
                    pass
                ginfo = cl.getGroup(op.param1)
                contact = cl.getContact(op.param2).picturePath
                image = 'http://dl.profile.line.naver.jp'+contact
                welcomeMembers(op.param1, [op.param2])
                cl.sendImageWithURL(op.param1, image)
                cl.sendMessage(op.param1, None, contentMetadata= barstick["welcome"], contentType=7)
#---------------MEMBER LEFT-----------------------------------------------------
        if op.type == 15:
            if wait["left"] == True:
                if op.param2 in Bots:
                    pass
                ginfo = cl.getGroup(op.param1)
                leaveMembers(op.param1, [op.param2])
                cl.sendMessage(op.param1, None, contentMetadata= barstick["leave"], contentType=7)
        if op.type == 15:
            if op.param2 in Zmid:
                try:
                    ki.findAndAddContactsByMid(Zmid)
                    ki.inviteIntoGroup(op.param1,[Zmid])
                except:
                    try:
                        kk.findAndAddContactsByMid(Zmid)
                        kk.inviteIntoGroup(op.param1,[Zmid])
                    except:
                        try:
                            kc.findAndAddContactsByMid(Zmid)
                            kc.inviteIntoGroup(op.param1,[Zmid])
                        except:
                            try:
                                km.findAndAddContactsByMid(Zmid)
                                km.inviteIntoGroup(op.param1,[Zmid])
                            except:
                                try:
                                    kb.findAndAddContactsByMid(Zmid)
                                    kb.inviteIntoGroup(op.param1,[Zmid])
                                except:
                                    try:
                                        kn.findAndAddContactsByMid(Zmid)
                                        kn.inviteIntoGroup(op.param1,[Zmid])
                                    except:
                                        try:
                                            ko.findAndAddContactsByMid(Zmid)
                                            ko.inviteIntoGroup(op.param1,[Zmid])
                                        except:
                                            try:
                                                kw.findAndAddContactsByMid(Zmid)
                                                kw.inviteIntoGroup(op.param1,[Zmid])
                                            except:
                                                try:
                                                    ke.findAndAddContactsByMid(Zmid)
                                                    ke.inviteIntoGroup(op.param1,[Zmid])
                                                except:
                                                    try:
                                                        ky.findAndAddContactsByMid(Zmid)
                                                        ky.inviteIntoGroup(op.param1,[Zmid])
                                                    except:
                                                        pass
            if op.param2 in Xmid:
                try:
                    ki.findAndAddContactsByMid(Xmid)
                    ki.inviteIntoGroup(op.param1,[Xmid])
                except:
                    try:
                        kk.findAndAddContactsByMid(Xmid)
                        kk.inviteIntoGroup(op.param1,[Xmid])
                    except:
                        try:
                            kc.findAndAddContactsByMid(Xmid)
                            kc.inviteIntoGroup(op.param1,[Xmid])
                        except:
                            try:
                                km.findAndAddContactsByMid(Xmid)
                                km.inviteIntoGroup(op.param1,[Xmid])
                            except:
                                try:
                                    kb.findAndAddContactsByMid(Xmid)
                                    kb.inviteIntoGroup(op.param1,[Xmid])
                                except:
                                    try:
                                        kn.findAndAddContactsByMid(Xmid)
                                        kn.inviteIntoGroup(op.param1,[Xmid])
                                    except:
                                        try:
                                            ko.findAndAddContactsByMid(Xmid)
                                            ko.inviteIntoGroup(op.param1,[Xmid])
                                        except:
                                            try:
                                                kw.findAndAddContactsByMid(Xmid)
                                                kw.inviteIntoGroup(op.param1,[Xmid])
                                            except:
                                                try:
                                                    ke.findAndAddContactsByMid(Xmid)
                                                    ke.inviteIntoGroup(op.param1,[Xmid])
                                                except:
                                                    try:
                                                        ky.findAndAddContactsByMid(Xmid)
                                                        ky.inviteIntoGroup(op.param1,[Xmid])
                                                    except:
                                                        pass
#---------------PRO JOIN--------------------------------------------------------
        if op.type == 17:
            if op.param1 in protectjoin:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in famzadmin["staff"]:
                    try:
                        random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
                        wait["blacklist"][op.param2] = True
                    except:
                        pass
#---------------AUTO ADD--------------------------------------------------------
        if op.type == 0:
            return
        if op.type == 5:
            if wait["autoAdd"] == True:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin:
                    if (wait["message"] in [" "," ","\n",None]):
                        pass
                    else:
                        cl.sendMessage(op.param1, wait["message"])
#---------------PRO KICK--------------------------------------------------------
        if op.type == 19:
            if op.param1 in protectkick:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in famzadmin["staff"]:
                    try:
                        random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
                        wait["blacklist"][op.param2] = True
                    except:
                        pass
#---------------PRO CANCEL------------------------------------------------------
        if op.type == 32:
            if op.param1 in protectcancel:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in famzadmin["staff"]:
                    wait["blacklist"][op.param2] = True
                    try:
                        if op.param3 not in wait["blacklist"]:
                            random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
                    except:
                           pass
#------- Jika Bots Di Kick Atau Di Cancel -------------------------------------------------------
        if op.type == 19 or op.type == 32:
            if selfmid in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    wait["qr"] = True
                    wait["inv"] = True
                    try:
                        ki.findAndAddContactsByMid(selfmid)
                        ki.kickoutFromGroup(op.param1,[op.param2])
                        ki.inviteIntoGroup(op.param1,[op.param3])
                        cl.acceptGroupInvitation(op.param1)
                    except:
                        try:
                            kk.findAndAddContactsByMid(selfmid)
                            kk.kickoutFromGroup(op.param1,[op.param2])
                            kk.inviteIntoGroup(op.param1,[op.param3])
                            cl.acceptGroupInvitation(op.param1)
                        except:
                            try:
                                kc.findAndAddContactsByMid(selfmid)
                                kc.kickoutFromGroup(op.param1,[op.param2])
                                kc.inviteIntoGroup(op.param1,[op.param3])
                                cl.acceptGroupInvitation(op.param1)
                            except:
                                try:
                                    km.findAndAddContactsByMid(selfmid)
                                    km.kickoutFromGroup(op.param1,[op.param2])
                                    km.inviteIntoGroup(op.param1,[op.param3])
                                    cl.acceptGroupInvitation(op.param1)
                                except:
                                    try:
                                        kb.findAndAddContactsByMid(selfmid)
                                        kb.kickoutFromGroup(op.param1,[op.param2])
                                        kb.inviteIntoGroup(op.param1,[op.param3])
                                        cl.acceptGroupInvitation(op.param1)
                                    except:
                                        try:
                                            kn.findAndAddContactsByMid(selfmid)
                                            kn.kickoutFromGroup(op.param1,[op.param2])
                                            kn.inviteIntoGroup(op.param1,[op.param3])
                                            cl.acceptGroupInvitation(op.param1)
                                        except:
                                            try:
                                                ko.findAndAddContactsByMid(selfmid)
                                                ko.kickoutFromGroup(op.param1,[op.param2])
                                                ko.inviteIntoGroup(op.param1,[op.param3])
                                                cl.acceptGroupInvitation(op.param1)
                                            except:
                                                try:
                                                    kw.findAndAddContactsByMid(selfmid)
                                                    kw.kickoutFromGroup(op.param1,[op.param2])
                                                    kw.inviteIntoGroup(op.param1,[op.param3])
                                                    cl.acceptGroupInvitation(op.param1)
                                                except:
                                                    try:
                                                        ke.findAndAddContactsByMid(selfmid)
                                                        ke.kickoutFromGroup(op.param1,[op.param2])
                                                        ke.inviteIntoGroup(op.param1,[op.param3])
                                                        cl.acceptGroupInvitation(op.param1)
                                                    except:
                                                        try:
                                                            ky.findAndAddContactsByMid(selfmid)
                                                            ky.kickoutFromGroup(op.param1,[op.param2])
                                                            ky.inviteIntoGroup(op.param1,[op.param3])
                                                            cl.acceptGroupInvitation(op.param1)
                                                        except:
                                                            try:
                                                            	aj.acceptGroupInvitation(op.param1)
                                                            	sw.acceptGroupInvitation(op.param1)
                                                            	sw.kickoutFromGroup(op.param1,[op.param2])
                                                            	G = aj.getGroup(op.param1)
                                                            	G.preventedJoinByTicket = False
                                                            	aj.updateGroup(G)
                                                            	Ticket = aj.reissueGroupTicket(op.param1)
                                                            	cl.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	ki.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	kk.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	kc.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	km.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	kb.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	kn.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	ko.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	kw.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	ke.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	ky.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	aj.leaveGroup(op.param1)
                                                            	sw.leaveGroup(op.param1)
                                                            	G = cl.getGroup(op.param1)
                                                            	G.preventedJoinByTicket = True
                                                            	cl.updateGroup(G)
                                                            except:
                                                            	pass
                return

            if Amid in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    wait["qr"] = True
                    wait["inv"] = True
                    try:
                        kk.findAndAddContactsByMid(Amid)
                        kk.kickoutFromGroup(op.param1,[op.param2])
                        kk.inviteIntoGroup(op.param1,[op.param3])
                        ki.acceptGroupInvitation(op.param1)
                        group = ki.getGroup(op.param1)
                        nama = [contact.mid for contact in group.members]
                        for x in nama:
                            if x in wait["blacklist"]:
                                ki.kickoutFromGroup(op.param1,[x])
                    except:
                        try:
                            kc.findAndAddContactsByMid(Amid)
                            kc.kickoutFromGroup(op.param1,[op.param2])
                            kc.inviteIntoGroup(op.param1,[op.param3])
                            ki.acceptGroupInvitation(op.param1)
                            group = ki.getGroup(op.param1)
                            nama = [contact.mid for contact in group.members]
                            for x in nama:
                                if x in wait["blacklist"]:
                                    ki.kickoutFromGroup(op.param1,[x])
                        except:
                            try:
                                km.findAndAddContactsByMid(Amid)
                                km.kickoutFromGroup(op.param1,[op.param2])
                                km.inviteIntoGroup(op.param1,[op.param3])
                                ki.acceptGroupInvitation(op.param1)
                                group = ki.getGroup(op.param1)
                                nama = [contact.mid for contact in group.members]
                                for x in nama:
                                    if x in wait["blacklist"]:
                                        ki.kickoutFromGroup(op.param1,[x])
                            except:
                                try:
                                    kb.findAndAddContactsByMid(Amid)
                                    kb.kickoutFromGroup(op.param1,[op.param2])
                                    kb.inviteIntoGroup(op.param1,[op.param3])
                                    ki.acceptGroupInvitation(op.param1)
                                    group = ki.getGroup(op.param1)
                                    nama = [contact.mid for contact in group.members]
                                    for x in nama:
                                        if x in wait["blacklist"]:
                                            ki.kickoutFromGroup(op.param1,[x])
                                except:
                                    try:
                                        kn.findAndAddContactsByMid(Amid)
                                        kn.kickoutFromGroup(op.param1,[op.param2])
                                        kn.inviteIntoGroup(op.param1,[op.param3])
                                        ki.acceptGroupInvitation(op.param1)
                                        group = ki.getGroup(op.param1)
                                        nama = [contact.mid for contact in group.members]
                                        for x in nama:
                                            if x in wait["blacklist"]:
                                                ki.kickoutFromGroup(op.param1,[x])
                                    except:
                                        try:
                                            ko.findAndAddContactsByMid(Amid)
                                            ko.kickoutFromGroup(op.param1,[op.param2])
                                            ko.inviteIntoGroup(op.param1,[op.param3])
                                            ki.acceptGroupInvitation(op.param1)
                                            group = ki.getGroup(op.param1)
                                            nama = [contact.mid for contact in group.members]
                                            for x in nama:
                                                if x in wait["blacklist"]:
                                                    ki.kickoutFromGroup(op.param1,[x])
                                        except:
                                            try:
                                                kw.findAndAddContactsByMid(Amid)
                                                kw.kickoutFromGroup(op.param1,[op.param2])
                                                kw.inviteIntoGroup(op.param1,[op.param3])
                                                ki.acceptGroupInvitation(op.param1)
                                                group = ki.getGroup(op.param1)
                                                nama = [contact.mid for contact in group.members]
                                                for x in nama:
                                                    if x in wait["blacklist"]:
                                                        ki.kickoutFromGroup(op.param1,[x])
                                            except:
                                                try:
                                                    ke.findAndAddContactsByMid(Amid)
                                                    ke.kickoutFromGroup(op.param1,[op.param2])
                                                    ke.inviteIntoGroup(op.param1,[op.param3])
                                                    ki.acceptGroupInvitation(op.param1)
                                                    group = ki.getGroup(op.param1)
                                                    nama = [contact.mid for contact in group.members]
                                                    for x in nama:
                                                        if x in wait["blacklist"]:
                                                            ki.kickoutFromGroup(op.param1,[x])
                                                except:
                                                    try:
                                                        ky.findAndAddContactsByMid(Amid)
                                                        ky.kickoutFromGroup(op.param1,[op.param2])
                                                        ky.inviteIntoGroup(op.param1,[op.param3])
                                                        ki.acceptGroupInvitation(op.param1)
                                                        group = ki.getGroup(op.param1)
                                                        nama = [contact.mid for contact in group.members]
                                                        for x in nama:
                                                            if x in wait["blacklist"]:
                                                                ki.kickoutFromGroup(op.param1,[x])
                                                    except:
                                                        try:
                                                            random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
                                                            random.choice(ABC).inviteIntoGroup(op.param1,[op.param3])
                                                            ki.acceptGroupInvitation(op.param1)
                                                        except:
                                                            try:
                                                            	aj.acceptGroupInvitation(op.param1)
                                                            	sw.acceptGroupInvitation(op.param1)
                                                            	sw.kickoutFromGroup(op.param1,[op.param2])
                                                            	G = aj.getGroup(op.param1)
                                                            	G.preventedJoinByTicket = False
                                                            	aj.updateGroup(G)
                                                            	Ticket = aj.reissueGroupTicket(op.param1)
                                                            	cl.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	ki.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	kk.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	kc.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	km.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	kb.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	kn.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	ko.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	kw.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	ke.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	ky.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	aj.leaveGroup(op.param1)
                                                            	sw.leaveGroup(op.param1)
                                                            	G = cl.getGroup(op.param1)
                                                            	G.preventedJoinByTicket = True
                                                            	cl.updateGroup(G)
                                                            except:
                                                            	pass
                return

            if Bmid in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    wait["qr"] = True
                    wait["inv"] = True
                    try:
                        kc.findAndAddContactsByMid(Bmid)
                        kc.kickoutFromGroup(op.param1,[op.param2])
                        kc.inviteIntoGroup(op.param1,[op.param3])
                        kk.acceptGroupInvitation(op.param1)
                        group = kk.getGroup(op.param1)
                        nama = [contact.mid for contact in group.members]
                        for x in nama:
                            if x in wait["blacklist"]:
                                kk.kickoutFromGroup(op.param1,[x])
                    except:
                        try:
                            km.findAndAddContactsByMid(Bmid)
                            km.kickoutFromGroup(op.param1,[op.param2])
                            km.inviteIntoGroup(op.param1,[op.param3])
                            kk.acceptGroupInvitation(op.param1)
                            group = kk.getGroup(op.param1)
                            nama = [contact.mid for contact in group.members]
                            for x in nama:
                                if x in wait["blacklist"]:
                                    kk.kickoutFromGroup(op.param1,[x])
                        except:
                            try:
                                kb.findAndAddContactsByMid(Bmid)
                                kb.kickoutFromGroup(op.param1,[op.param2])
                                kb.inviteIntoGroup(op.param1,[op.param3])
                                kk.acceptGroupInvitation(op.param1)
                                group = kk.getGroup(op.param1)
                                nama = [contact.mid for contact in group.members]
                                for x in nama:
                                    if x in wait["blacklist"]:
                                        kk.kickoutFromGroup(op.param1,[x])
                            except:
                                try:
                                    kn.findAndAddContactsByMid(Bmid)
                                    kn.kickoutFromGroup(op.param1,[op.param2])
                                    kn.inviteIntoGroup(op.param1,[op.param3])
                                    kk.acceptGroupInvitation(op.param1)
                                    group = kk.getGroup(op.param1)
                                    nama = [contact.mid for contact in group.members]
                                    for x in nama:
                                        if x in wait["blacklist"]:
                                            kk.kickoutFromGroup(op.param1,[x])
                                except:
                                    try:
                                        ko.findAndAddContactsByMid(Bmid)
                                        ko.kickoutFromGroup(op.param1,[op.param2])
                                        ko.inviteIntoGroup(op.param1,[op.param3])
                                        kk.acceptGroupInvitation(op.param1)
                                        group = kk.getGroup(op.param1)
                                        nama = [contact.mid for contact in group.members]
                                        for x in nama:
                                            if x in wait["blacklist"]:
                                                kk.kickoutFromGroup(op.param1,[x])
                                    except:
                                        try:
                                            kw.findAndAddContactsByMid(Bmid)
                                            kw.kickoutFromGroup(op.param1,[op.param2])
                                            kw.inviteIntoGroup(op.param1,[op.param3])
                                            kk.acceptGroupInvitation(op.param1)
                                            group = kk.getGroup(op.param1)
                                            nama = [contact.mid for contact in group.members]
                                            for x in nama:
                                                if x in wait["blacklist"]:
                                                    kk.kickoutFromGroup(op.param1,[x])
                                        except:
                                            try:
                                                ke.findAndAddContactsByMid(Bmid)
                                                ke.kickoutFromGroup(op.param1,[op.param2])
                                                ke.inviteIntoGroup(op.param1,[op.param3])
                                                kk.acceptGroupInvitation(op.param1)
                                                group = kk.getGroup(op.param1)
                                                nama = [contact.mid for contact in group.members]
                                                for x in nama:
                                                    if x in wait["blacklist"]:
                                                        kk.kickoutFromGroup(op.param1,[x])
                                            except:
                                                try:
                                                    ky.findAndAddContactsByMid(Bmid)
                                                    ky.kickoutFromGroup(op.param1,[op.param2])
                                                    ky.inviteIntoGroup(op.param1,[op.param3])
                                                    kk.acceptGroupInvitation(op.param1)
                                                    group = kk.getGroup(op.param1)
                                                    nama = [contact.mid for contact in group.members]
                                                    for x in nama:
                                                        if x in wait["blacklist"]:
                                                            kk.kickoutFromGroup(op.param1,[x])
                                                except:
                                                    try:
                                                        ki.findAndAddContactsByMid(Bmid)
                                                        ki.kickoutFromGroup(op.param1,[op.param2])
                                                        ki.inviteIntoGroup(op.param1,[op.param3])
                                                        kk.acceptGroupInvitation(op.param1)
                                                        group = kk.getGroup(op.param1)
                                                        nama = [contact.mid for contact in group.members]
                                                        for x in nama:
                                                            if x in wait["blacklist"]:
                                                                kk.kickoutFromGroup(op.param1,[x])
                                                    except:
                                                        try:
                                                            random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
                                                            random.choice(ABC).inviteIntoGroup(op.param1,[op.param3])
                                                            kk.acceptGroupInvitation(op.param1)
                                                        except:
                                                            try:
                                                            	aj.acceptGroupInvitation(op.param1)
                                                            	sw.acceptGroupInvitation(op.param1)
                                                            	sw.kickoutFromGroup(op.param1,[op.param2])
                                                            	G = aj.getGroup(op.param1)
                                                            	G.preventedJoinByTicket = False
                                                            	aj.updateGroup(G)
                                                            	Ticket = aj.reissueGroupTicket(op.param1)
                                                            	cl.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	ki.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	kk.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	kc.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	km.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	kb.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	kn.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	ko.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	kw.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	ke.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	ky.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	aj.leaveGroup(op.param1)
                                                            	sw.leaveGroup(op.param1)
                                                            	G = cl.getGroup(op.param1)
                                                            	G.preventedJoinByTicket = True
                                                            	cl.updateGroup(G)
                                                            except:
                                                            	pass

                return

            if Cmid in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    wait["qr"] = True
                    wait["inv"] = True
                    try:
                        km.findAndAddContactsByMid(Cmid)
                        km.kickoutFromGroup(op.param1,[op.param2])
                        km.inviteIntoGroup(op.param1,[op.param3])
                        kc.acceptGroupInvitation(op.param1)
                        group = kc.getGroup(op.param1)
                        nama = [contact.mid for contact in group.members]
                        for x in nama:
                            if x in wait["blacklist"]:
                                kc.kickoutFromGroup(op.param1,[x])
                    except:
                        try:
                            kb.findAndAddContactsByMid(Cmid)
                            kb.kickoutFromGroup(op.param1,[op.param2])
                            kb.inviteIntoGroup(op.param1,[op.param3])
                            kc.acceptGroupInvitation(op.param1)
                            group = kc.getGroup(op.param1)
                            nama = [contact.mid for contact in group.members]
                            for x in nama:
                                if x in wait["blacklist"]:
                                    kc.kickoutFromGroup(op.param1,[x])
                        except:
                            try:
                                kn.findAndAddContactsByMid(Cmid)
                                kn.kickoutFromGroup(op.param1,[op.param2])
                                kn.inviteIntoGroup(op.param1,[op.param3])
                                kc.acceptGroupInvitation(op.param1)
                                group = kc.getGroup(op.param1)
                                nama = [contact.mid for contact in group.members]
                                for x in nama:
                                    if x in wait["blacklist"]:
                                        kc.kickoutFromGroup(op.param1,[x])
                            except:
                                try:
                                    ko.findAndAddContactsByMid(Cmid)
                                    ko.kickoutFromGroup(op.param1,[op.param2])
                                    ko.inviteIntoGroup(op.param1,[op.param3])
                                    kc.acceptGroupInvitation(op.param1)
                                    group = kc.getGroup(op.param1)
                                    nama = [contact.mid for contact in group.members]
                                    for x in nama:
                                        if x in wait["blacklist"]:
                                            kc.kickoutFromGroup(op.param1,[x])
                                except:
                                    try:
                                        kw.findAndAddContactsByMid(Cmid)
                                        kw.kickoutFromGroup(op.param1,[op.param2])
                                        kw.inviteIntoGroup(op.param1,[op.param3])
                                        kc.acceptGroupInvitation(op.param1)
                                        group = kc.getGroup(op.param1)
                                        nama = [contact.mid for contact in group.members]
                                        for x in nama:
                                            if x in wait["blacklist"]:
                                                kc.kickoutFromGroup(op.param1,[x])
                                    except:
                                        try:
                                            ke.findAndAddContactsByMid(Cmid)
                                            ke.kickoutFromGroup(op.param1,[op.param2])
                                            ke.inviteIntoGroup(op.param1,[op.param3])
                                            kc.acceptGroupInvitation(op.param1)
                                            group = kc.getGroup(op.param1)
                                            nama = [contact.mid for contact in group.members]
                                            for x in nama:
                                                if x in wait["blacklist"]:
                                                    kc.kickoutFromGroup(op.param1,[x])
                                        except:
                                            try:
                                                ky.findAndAddContactsByMid(Cmid)
                                                ky.kickoutFromGroup(op.param1,[op.param2])
                                                ky.inviteIntoGroup(op.param1,[op.param3])
                                                kc.acceptGroupInvitation(op.param1)
                                                group = kc.getGroup(op.param1)
                                                nama = [contact.mid for contact in group.members]
                                                for x in nama:
                                                    if x in wait["blacklist"]:
                                                        kc.kickoutFromGroup(op.param1,[x])
                                            except:
                                                try:
                                                    ki.findAndAddContactsByMid(Cmid)
                                                    ki.kickoutFromGroup(op.param1,[op.param2])
                                                    ki.inviteIntoGroup(op.param1,[op.param3])
                                                    kc.acceptGroupInvitation(op.param1)
                                                    group = kc.getGroup(op.param1)
                                                    nama = [contact.mid for contact in group.members]
                                                    for x in nama:
                                                        if x in wait["blacklist"]:
                                                            kc.kickoutFromGroup(op.param1,[x])
                                                except:
                                                    try:
                                                        kk.findAndAddContactsByMid(Cmid)
                                                        kk.kickoutFromGroup(op.param1,[op.param2])
                                                        kk.inviteIntoGroup(op.param1,[op.param3])
                                                        kc.acceptGroupInvitation(op.param1)
                                                        group = kc.getGroup(op.param1)
                                                        nama = [contact.mid for contact in group.members]
                                                        for x in nama:
                                                            if x in wait["blacklist"]:
                                                                kc.kickoutFromGroup(op.param1,[x])
                                                    except:
                                                        try:
                                                            random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
                                                            random.choice(ABC).inviteIntoGroup(op.param1,[op.param3])
                                                            kc.acceptGroupInvitation(op.param1)
                                                        except:
                                                            try:
                                                            	aj.acceptGroupInvitation(op.param1)
                                                            	sw.acceptGroupInvitation(op.param1)
                                                            	sw.kickoutFromGroup(op.param1,[op.param2])
                                                            	G = aj.getGroup(op.param1)
                                                            	G.preventedJoinByTicket = False
                                                            	aj.updateGroup(G)
                                                            	Ticket = aj.reissueGroupTicket(op.param1)
                                                            	cl.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	ki.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	kk.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	kc.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	km.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	kb.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	kn.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	ko.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	kw.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	ke.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	ky.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	aj.leaveGroup(op.param1)
                                                            	sw.leaveGroup(op.param1)
                                                            	G = cl.getGroup(op.param1)
                                                            	G.preventedJoinByTicket = True
                                                            	cl.updateGroup(G)
                                                            except:
                                                            	pass

                return

            if Dmid in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    wait["qr"] = True
                    wait["inv"] = True
                    try:
                        kb.findAndAddContactsByMid(Dmid)
                        kb.kickoutFromGroup(op.param1,[op.param2])
                        kb.inviteIntoGroup(op.param1,[op.param3])
                        km.acceptGroupInvitation(op.param1)
                        group = km.getGroup(op.param1)
                        nama = [contact.mid for contact in group.members]
                        for x in nama:
                            if x in wait["blacklist"]:
                                km.kickoutFromGroup(op.param1,[x])
                    except:
                        try:
                            kn.findAndAddContactsByMid(Dmid)
                            kn.kickoutFromGroup(op.param1,[op.param2])
                            kn.inviteIntoGroup(op.param1,[op.param3])
                            km.acceptGroupInvitation(op.param1)
                            group = km.getGroup(op.param1)
                            nama = [contact.mid for contact in group.members]
                            for x in nama:
                                if x in wait["blacklist"]:
                                    km.kickoutFromGroup(op.param1,[x])
                        except:
                            try:
                                ko.findAndAddContactsByMid(Dmid)
                                ko.kickoutFromGroup(op.param1,[op.param2])
                                ko.inviteIntoGroup(op.param1,[op.param3])
                                km.acceptGroupInvitation(op.param1)
                                group = km.getGroup(op.param1)
                                nama = [contact.mid for contact in group.members]
                                for x in nama:
                                    if x in wait["blacklist"]:
                                        km.kickoutFromGroup(op.param1,[x])
                            except:
                                try:
                                    kw.findAndAddContactsByMid(Dmid)
                                    kw.kickoutFromGroup(op.param1,[op.param2])
                                    kw.inviteIntoGroup(op.param1,[op.param3])
                                    km.acceptGroupInvitation(op.param1)
                                    group = km.getGroup(op.param1)
                                    nama = [contact.mid for contact in group.members]
                                    for x in nama:
                                        if x in wait["blacklist"]:
                                            km.kickoutFromGroup(op.param1,[x])
                                except:
                                    try:
                                        ke.findAndAddContactsByMid(Dmid)
                                        ke.kickoutFromGroup(op.param1,[op.param2])
                                        ke.inviteIntoGroup(op.param1,[op.param3])
                                        km.acceptGroupInvitation(op.param1)
                                        group = km.getGroup(op.param1)
                                        nama = [contact.mid for contact in group.members]
                                        for x in nama:
                                            if x in wait["blacklist"]:
                                                km.kickoutFromGroup(op.param1,[x])
                                    except:
                                        try:
                                            ky.findAndAddContactsByMid(Dmid)
                                            ky.kickoutFromGroup(op.param1,[op.param2])
                                            ky.inviteIntoGroup(op.param1,[op.param3])
                                            km.acceptGroupInvitation(op.param1)
                                            group = km.getGroup(op.param1)
                                            nama = [contact.mid for contact in group.members]
                                            for x in nama:
                                                if x in wait["blacklist"]:
                                                    km.kickoutFromGroup(op.param1,[x])
                                        except:
                                            try:
                                                ki.findAndAddContactsByMid(Dmid)
                                                ki.kickoutFromGroup(op.param1,[op.param2])
                                                ki.inviteIntoGroup(op.param1,[op.param3])
                                                km.acceptGroupInvitation(op.param1)
                                                group = km.getGroup(op.param1)
                                                nama = [contact.mid for contact in group.members]
                                                for x in nama:
                                                    if x in wait["blacklist"]:
                                                        km.kickoutFromGroup(op.param1,[x])
                                            except:
                                                try:
                                                    kk.findAndAddContactsByMid(Dmid)
                                                    kk.kickoutFromGroup(op.param1,[op.param2])
                                                    kk.inviteIntoGroup(op.param1,[op.param3])
                                                    km.acceptGroupInvitation(op.param1)
                                                    group = km.getGroup(op.param1)
                                                    nama = [contact.mid for contact in group.members]
                                                    for x in nama:
                                                        if x in wait["blacklist"]:
                                                            km.kickoutFromGroup(op.param1,[x])
                                                except:
                                                    try:
                                                        kc.findAndAddContactsByMid(Dmid)
                                                        kc.kickoutFromGroup(op.param1,[op.param2])
                                                        kc.inviteIntoGroup(op.param1,[op.param3])
                                                        km.acceptGroupInvitation(op.param1)
                                                        group = km.getGroup(op.param1)
                                                        nama = [contact.mid for contact in group.members]
                                                        for x in nama:
                                                            if x in wait["blacklist"]:
                                                                km.kickoutFromGroup(op.param1,[x])
                                                    except:
                                                        try:
                                                            random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
                                                            random.choice(ABC).inviteIntoGroup(op.param1,[op.param3])
                                                            km.acceptGroupInvitation(op.param1)
                                                        except:
                                                            try:
                                                            	aj.acceptGroupInvitation(op.param1)
                                                            	sw.acceptGroupInvitation(op.param1)
                                                            	sw.kickoutFromGroup(op.param1,[op.param2])
                                                            	G = aj.getGroup(op.param1)
                                                            	G.preventedJoinByTicket = False
                                                            	aj.updateGroup(G)
                                                            	Ticket = aj.reissueGroupTicket(op.param1)
                                                            	cl.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	ki.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	kk.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	kc.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	km.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	kb.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	kn.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	ko.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	kw.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	ke.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	ky.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	aj.leaveGroup(op.param1)
                                                            	sw.leaveGroup(op.param1)
                                                            	G = cl.getGroup(op.param1)
                                                            	G.preventedJoinByTicket = True
                                                            	cl.updateGroup(G)
                                                            except:
                                                            	pass

                return

            if Emid in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    wait["qr"] = True
                    wait["inv"] = True
                    try:
                        kn.findAndAddContactsByMid(Emid)
                        kn.kickoutFromGroup(op.param1,[op.param2])
                        kn.inviteIntoGroup(op.param1,[op.param3])
                        kb.acceptGroupInvitation(op.param1)
                        group = kb.getGroup(op.param1)
                        nama = [contact.mid for contact in group.members]
                        for x in nama:
                            if x in wait["blacklist"]:
                                kb.kickoutFromGroup(op.param1,[x])
                    except:
                        try:
                            ko.findAndAddContactsByMid(Emid)
                            ko.kickoutFromGroup(op.param1,[op.param2])
                            ko.inviteIntoGroup(op.param1,[op.param3])
                            kb.acceptGroupInvitation(op.param1)
                            group = kb.getGroup(op.param1)
                            nama = [contact.mid for contact in group.members]
                            for x in nama:
                                if x in wait["blacklist"]:
                                    kb.kickoutFromGroup(op.param1,[x])
                        except:
                            try:
                                kw.findAndAddContactsByMid(Emid)
                                kw.kickoutFromGroup(op.param1,[op.param2])
                                kw.inviteIntoGroup(op.param1,[op.param3])
                                kb.acceptGroupInvitation(op.param1)
                                group = kb.getGroup(op.param1)
                                nama = [contact.mid for contact in group.members]
                                for x in nama:
                                    if x in wait["blacklist"]:
                                        kb.kickoutFromGroup(op.param1,[x])
                            except:
                                try:
                                    ke.findAndAddContactsByMid(Emid)
                                    ke.kickoutFromGroup(op.param1,[op.param2])
                                    ke.inviteIntoGroup(op.param1,[op.param3])
                                    kb.acceptGroupInvitation(op.param1)
                                    group = kb.getGroup(op.param1)
                                    nama = [contact.mid for contact in group.members]
                                    for x in nama:
                                        if x in wait["blacklist"]:
                                            kb.kickoutFromGroup(op.param1,[x])
                                except:
                                    try:
                                        ky.findAndAddContactsByMid(Emid)
                                        ky.kickoutFromGroup(op.param1,[op.param2])
                                        ky.inviteIntoGroup(op.param1,[op.param3])
                                        kb.acceptGroupInvitation(op.param1)
                                        group = kb.getGroup(op.param1)
                                        nama = [contact.mid for contact in group.members]
                                        for x in nama:
                                            if x in wait["blacklist"]:
                                                kb.kickoutFromGroup(op.param1,[x])
                                    except:
                                        try:
                                            ki.findAndAddContactsByMid(Emid)
                                            ki.kickoutFromGroup(op.param1,[op.param2])
                                            ki.inviteIntoGroup(op.param1,[op.param3])
                                            kb.acceptGroupInvitation(op.param1)
                                            group = kb.getGroup(op.param1)
                                            nama = [contact.mid for contact in group.members]
                                            for x in nama:
                                                if x in wait["blacklist"]:
                                                    kb.kickoutFromGroup(op.param1,[x])
                                        except:
                                            try:
                                                kk.findAndAddContactsByMid(Emid)
                                                kk.kickoutFromGroup(op.param1,[op.param2])
                                                kk.inviteIntoGroup(op.param1,[op.param3])
                                                kb.acceptGroupInvitation(op.param1)
                                                group = kb.getGroup(op.param1)
                                                nama = [contact.mid for contact in group.members]
                                                for x in nama:
                                                    if x in wait["blacklist"]:
                                                        kb.kickoutFromGroup(op.param1,[x])
                                            except:
                                                try:
                                                    kc.findAndAddContactsByMid(Emid)
                                                    kc.kickoutFromGroup(op.param1,[op.param2])
                                                    kc.inviteIntoGroup(op.param1,[op.param3])
                                                    kb.acceptGroupInvitation(op.param1)
                                                    group = kb.getGroup(op.param1)
                                                    nama = [contact.mid for contact in group.members]
                                                    for x in nama:
                                                        if x in wait["blacklist"]:
                                                            kb.kickoutFromGroup(op.param1,[x])
                                                except:
                                                    try:
                                                        km.findAndAddContactsByMid(Emid)
                                                        km.kickoutFromGroup(op.param1,[op.param2])
                                                        km.inviteIntoGroup(op.param1,[op.param3])
                                                        kb.acceptGroupInvitation(op.param1)
                                                        group = kb.getGroup(op.param1)
                                                        nama = [contact.mid for contact in group.members]
                                                        for x in nama:
                                                            if x in wait["blacklist"]:
                                                                kb.kickoutFromGroup(op.param1,[x])
                                                    except:
                                                        try:
                                                            random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
                                                            random.choice(ABC).inviteIntoGroup(op.param1,[op.param3])
                                                            kb.acceptGroupInvitation(op.param1)
                                                        except:
                                                            try:
                                                            	aj.acceptGroupInvitation(op.param1)
                                                            	sw.acceptGroupInvitation(op.param1)
                                                            	sw.kickoutFromGroup(op.param1,[op.param2])
                                                            	G = aj.getGroup(op.param1)
                                                            	G.preventedJoinByTicket = False
                                                            	aj.updateGroup(G)
                                                            	Ticket = aj.reissueGroupTicket(op.param1)
                                                            	cl.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	ki.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	kk.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	kc.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	km.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	kb.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	kn.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	ko.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	kw.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	ke.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	ky.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	aj.leaveGroup(op.param1)
                                                            	sw.leaveGroup(op.param1)
                                                            	G = cl.getGroup(op.param1)
                                                            	G.preventedJoinByTicket = True
                                                            	cl.updateGroup(G)
                                                            except:
                                                            	pass

                return

            if Fmid in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    wait["qr"] = True
                    wait["inv"] = True
                    try:
                        ko.findAndAddContactsByMid(Fmid)
                        ko.kickoutFromGroup(op.param1,[op.param2])
                        ko.inviteIntoGroup(op.param1,[op.param3])
                        kn.acceptGroupInvitation(op.param1)
                        group = kn.getGroup(op.param1)
                        nama = [contact.mid for contact in group.members]
                        for x in nama:
                            if x in wait["blacklist"]:
                                kn.kickoutFromGroup(op.param1,[x])
                    except:
                        try:
                            kw.findAndAddContactsByMid(Fmid)
                            kw.kickoutFromGroup(op.param1,[op.param2])
                            kw.inviteIntoGroup(op.param1,[op.param3])
                            kn.acceptGroupInvitation(op.param1)
                            group = kn.getGroup(op.param1)
                            nama = [contact.mid for contact in group.members]
                            for x in nama:
                                if x in wait["blacklist"]:
                                    kn.kickoutFromGroup(op.param1,[x])
                        except:
                            try:
                                ke.findAndAddContactsByMid(Fmid)
                                ke.kickoutFromGroup(op.param1,[op.param2])
                                ke.inviteIntoGroup(op.param1,[op.param3])
                                kn.acceptGroupInvitation(op.param1)
                                group = kn.getGroup(op.param1)
                                nama = [contact.mid for contact in group.members]
                                for x in nama:
                                    if x in wait["blacklist"]:
                                        kn.kickoutFromGroup(op.param1,[x])
                            except:
                                try:
                                    ky.findAndAddContactsByMid(Fmid)
                                    ky.kickoutFromGroup(op.param1,[op.param2])
                                    ky.inviteIntoGroup(op.param1,[op.param3])
                                    kn.acceptGroupInvitation(op.param1)
                                    group = kn.getGroup(op.param1)
                                    nama = [contact.mid for contact in group.members]
                                    for x in nama:
                                        if x in wait["blacklist"]:
                                            kn.kickoutFromGroup(op.param1,[x])
                                except:
                                    try:
                                        ki.findAndAddContactsByMid(Fmid)
                                        ki.kickoutFromGroup(op.param1,[op.param2])
                                        ki.inviteIntoGroup(op.param1,[op.param3])
                                        kn.acceptGroupInvitation(op.param1)
                                        group = kn.getGroup(op.param1)
                                        nama = [contact.mid for contact in group.members]
                                        for x in nama:
                                            if x in wait["blacklist"]:
                                                kn.kickoutFromGroup(op.param1,[x])
                                    except:
                                        try:
                                            kk.findAndAddContactsByMid(Fmid)
                                            kk.kickoutFromGroup(op.param1,[op.param2])
                                            kk.inviteIntoGroup(op.param1,[op.param3])
                                            kn.acceptGroupInvitation(op.param1)
                                            group = kn.getGroup(op.param1)
                                            nama = [contact.mid for contact in group.members]
                                            for x in nama:
                                                if x in wait["blacklist"]:
                                                    kn.kickoutFromGroup(op.param1,[x])
                                        except:
                                            try:
                                                kc.findAndAddContactsByMid(Fmid)
                                                kc.kickoutFromGroup(op.param1,[op.param2])
                                                kc.inviteIntoGroup(op.param1,[op.param3])
                                                kn.acceptGroupInvitation(op.param1)
                                                group = kn.getGroup(op.param1)
                                                nama = [contact.mid for contact in group.members]
                                                for x in nama:
                                                    if x in wait["blacklist"]:
                                                        kn.kickoutFromGroup(op.param1,[x])
                                            except:
                                                try:
                                                    km.findAndAddContactsByMid(Fmid)
                                                    km.kickoutFromGroup(op.param1,[op.param2])
                                                    km.inviteIntoGroup(op.param1,[op.param3])
                                                    kn.acceptGroupInvitation(op.param1)
                                                    group = kn.getGroup(op.param1)
                                                    nama = [contact.mid for contact in group.members]
                                                    for x in nama:
                                                        if x in wait["blacklist"]:
                                                            kn.kickoutFromGroup(op.param1,[x])
                                                except:
                                                    try:
                                                        kb.findAndAddContactsByMid(Fmid)
                                                        kb.kickoutFromGroup(op.param1,[op.param2])
                                                        kb.inviteIntoGroup(op.param1,[op.param3])
                                                        kn.acceptGroupInvitation(op.param1)
                                                        group = kn.getGroup(op.param1)
                                                        nama = [contact.mid for contact in group.members]
                                                        for x in nama:
                                                            if x in wait["blacklist"]:
                                                                kn.kickoutFromGroup(op.param1,[x])
                                                    except:
                                                        try:
                                                            random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
                                                            random.choice(ABC).inviteIntoGroup(op.param1,[op.param3])
                                                            kn.acceptGroupInvitation(op.param1)
                                                        except:
                                                            try:
                                                            	aj.acceptGroupInvitation(op.param1)
                                                            	sw.acceptGroupInvitation(op.param1)
                                                            	sw.kickoutFromGroup(op.param1,[op.param2])
                                                            	G = aj.getGroup(op.param1)
                                                            	G.preventedJoinByTicket = False
                                                            	aj.updateGroup(G)
                                                            	Ticket = aj.reissueGroupTicket(op.param1)
                                                            	cl.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	ki.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	kk.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	kc.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	km.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	kb.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	kn.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	ko.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	kw.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	ke.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	ky.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	aj.leaveGroup(op.param1)
                                                            	sw.leaveGroup(op.param1)
                                                            	G = cl.getGroup(op.param1)
                                                            	G.preventedJoinByTicket = True
                                                            	cl.updateGroup(G)
                                                            except:
                                                            	pass

                return

            if Gmid in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    wait["qr"] = True
                    wait["inv"] = True
                    try:
                        kw.findAndAddContactsByMid(Gmid)
                        kw.kickoutFromGroup(op.param1,[op.param2])
                        kw.inviteIntoGroup(op.param1,[op.param3])
                        ko.acceptGroupInvitation(op.param1)
                        group = ko.getGroup(op.param1)
                        nama = [contact.mid for contact in group.members]
                        for x in nama:
                            if x in wait["blacklist"]:
                                ko.kickoutFromGroup(op.param1,[x])
                    except:
                        try:
                            ke.findAndAddContactsByMid(Gmid)
                            ke.kickoutFromGroup(op.param1,[op.param2])
                            ke.inviteIntoGroup(op.param1,[op.param3])
                            ko.acceptGroupInvitation(op.param1)
                            group = ko.getGroup(op.param1)
                            nama = [contact.mid for contact in group.members]
                            for x in nama:
                                if x in wait["blacklist"]:
                                    ko.kickoutFromGroup(op.param1,[x])
                        except:
                            try:
                                ky.findAndAddContactsByMid(Gmid)
                                ky.kickoutFromGroup(op.param1,[op.param2])
                                ky.inviteIntoGroup(op.param1,[op.param3])
                                ko.acceptGroupInvitation(op.param1)
                                group = ko.getGroup(op.param1)
                                nama = [contact.mid for contact in group.members]
                                for x in nama:
                                    if x in wait["blacklist"]:
                                        ko.kickoutFromGroup(op.param1,[x])
                            except:
                                try:
                                    ki.findAndAddContactsByMid(Gmid)
                                    ki.kickoutFromGroup(op.param1,[op.param2])
                                    ki.inviteIntoGroup(op.param1,[op.param3])
                                    ko.acceptGroupInvitation(op.param1)
                                    group = ko.getGroup(op.param1)
                                    nama = [contact.mid for contact in group.members]
                                    for x in nama:
                                        if x in wait["blacklist"]:
                                            ko.kickoutFromGroup(op.param1,[x])
                                except:
                                    try:
                                        kk.findAndAddContactsByMid(Gmid)
                                        kk.kickoutFromGroup(op.param1,[op.param2])
                                        kk.inviteIntoGroup(op.param1,[op.param3])
                                        ko.acceptGroupInvitation(op.param1)
                                        group = ko.getGroup(op.param1)
                                        nama = [contact.mid for contact in group.members]
                                        for x in nama:
                                            if x in wait["blacklist"]:
                                                ko.kickoutFromGroup(op.param1,[x])
                                    except:
                                        try:
                                            kc.findAndAddContactsByMid(Gmid)
                                            kc.kickoutFromGroup(op.param1,[op.param2])
                                            kc.inviteIntoGroup(op.param1,[op.param3])
                                            ko.acceptGroupInvitation(op.param1)
                                            group = ko.getGroup(op.param1)
                                            nama = [contact.mid for contact in group.members]
                                            for x in nama:
                                                if x in wait["blacklist"]:
                                                    ko.kickoutFromGroup(op.param1,[x])
                                        except:
                                            try:
                                                km.findAndAddContactsByMid(Gmid)
                                                km.kickoutFromGroup(op.param1,[op.param2])
                                                km.inviteIntoGroup(op.param1,[op.param3])
                                                ko.acceptGroupInvitation(op.param1)
                                                group = ko.getGroup(op.param1)
                                                nama = [contact.mid for contact in group.members]
                                                for x in nama:
                                                    if x in wait["blacklist"]:
                                                        ko.kickoutFromGroup(op.param1,[x])
                                            except:
                                                try:
                                                    kb.findAndAddContactsByMid(Gmid)
                                                    kb.kickoutFromGroup(op.param1,[op.param2])
                                                    kb.inviteIntoGroup(op.param1,[op.param3])
                                                    ko.acceptGroupInvitation(op.param1)
                                                    group = ko.getGroup(op.param1)
                                                    nama = [contact.mid for contact in group.members]
                                                    for x in nama:
                                                        if x in wait["blacklist"]:
                                                            ko.kickoutFromGroup(op.param1,[x])
                                                except:
                                                    try:
                                                        kn.findAndAddContactsByMid(Gmid)
                                                        kn.kickoutFromGroup(op.param1,[op.param2])
                                                        kn.inviteIntoGroup(op.param1,[op.param3])
                                                        ko.acceptGroupInvitation(op.param1)
                                                        group = ko.getGroup(op.param1)
                                                        nama = [contact.mid for contact in group.members]
                                                        for x in nama:
                                                            if x in wait["blacklist"]:
                                                                ko.kickoutFromGroup(op.param1,[x])
                                                    except:
                                                        try:
                                                            random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
                                                            random.choice(ABC).inviteIntoGroup(op.param1,[op.param3])
                                                            ko.acceptGroupInvitation(op.param1)
                                                        except:
                                                            try:
                                                            	aj.acceptGroupInvitation(op.param1)
                                                            	sw.acceptGroupInvitation(op.param1)
                                                            	sw.kickoutFromGroup(op.param1,[op.param2])
                                                            	G = aj.getGroup(op.param1)
                                                            	G.preventedJoinByTicket = False
                                                            	aj.updateGroup(G)
                                                            	Ticket = aj.reissueGroupTicket(op.param1)
                                                            	cl.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	ki.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	kk.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	kc.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	km.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	kb.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	kn.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	ko.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	kw.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	ke.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	ky.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	aj.leaveGroup(op.param1)
                                                            	sw.leaveGroup(op.param1)
                                                            	G = cl.getGroup(op.param1)
                                                            	G.preventedJoinByTicket = True
                                                            	cl.updateGroup(G)
                                                            except:
                                                            	pass

                return

            if Hmid in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    wait["qr"] = True
                    wait["inv"] = True
                    try:
                        ke.findAndAddContactsByMid(Hmid)
                        ke.kickoutFromGroup(op.param1,[op.param2])
                        ke.inviteIntoGroup(op.param1,[op.param3])
                        kw.acceptGroupInvitation(op.param1)
                        group = kw.getGroup(op.param1)
                        nama = [contact.mid for contact in group.members]
                        for x in nama:
                            if x in wait["blacklist"]:
                                kw.kickoutFromGroup(op.param1,[x])
                    except:
                        try:
                            ky.findAndAddContactsByMid(Hmid)
                            ky.kickoutFromGroup(op.param1,[op.param2])
                            ky.inviteIntoGroup(op.param1,[op.param3])
                            kw.acceptGroupInvitation(op.param1)
                            group = kw.getGroup(op.param1)
                            nama = [contact.mid for contact in group.members]
                            for x in nama:
                                if x in wait["blacklist"]:
                                    kw.kickoutFromGroup(op.param1,[x])
                        except:
                            try:
                                ki.findAndAddContactsByMid(Hmid)
                                ki.kickoutFromGroup(op.param1,[op.param2])
                                ki.inviteIntoGroup(op.param1,[op.param3])
                                kw.acceptGroupInvitation(op.param1)
                                group = kw.getGroup(op.param1)
                                nama = [contact.mid for contact in group.members]
                                for x in nama:
                                    if x in wait["blacklist"]:
                                        kw.kickoutFromGroup(op.param1,[x])
                            except:
                                try:
                                    kk.findAndAddContactsByMid(Hmid)
                                    kk.kickoutFromGroup(op.param1,[op.param2])
                                    kk.inviteIntoGroup(op.param1,[op.param3])
                                    kw.acceptGroupInvitation(op.param1)
                                    group = kw.getGroup(op.param1)
                                    nama = [contact.mid for contact in group.members]
                                    for x in nama:
                                        if x in wait["blacklist"]:
                                            kw.kickoutFromGroup(op.param1,[x])
                                except:
                                    try:
                                        kc.findAndAddContactsByMid(Hmid)
                                        kc.kickoutFromGroup(op.param1,[op.param2])
                                        kc.inviteIntoGroup(op.param1,[op.param3])
                                        kw.acceptGroupInvitation(op.param1)
                                        group = kw.getGroup(op.param1)
                                        nama = [contact.mid for contact in group.members]
                                        for x in nama:
                                            if x in wait["blacklist"]:
                                                kw.kickoutFromGroup(op.param1,[x])
                                    except:
                                        try:
                                            km.findAndAddContactsByMid(Hmid)
                                            km.kickoutFromGroup(op.param1,[op.param2])
                                            km.inviteIntoGroup(op.param1,[op.param3])
                                            kw.acceptGroupInvitation(op.param1)
                                            group = kw.getGroup(op.param1)
                                            nama = [contact.mid for contact in group.members]
                                            for x in nama:
                                                if x in wait["blacklist"]:
                                                    kw.kickoutFromGroup(op.param1,[x])
                                        except:
                                            try:
                                                kb.findAndAddContactsByMid(Hmid)
                                                kb.kickoutFromGroup(op.param1,[op.param2])
                                                kb.inviteIntoGroup(op.param1,[op.param3])
                                                kw.acceptGroupInvitation(op.param1)
                                                group = kw.getGroup(op.param1)
                                                nama = [contact.mid for contact in group.members]
                                                for x in nama:
                                                    if x in wait["blacklist"]:
                                                        kw.kickoutFromGroup(op.param1,[x])
                                            except:
                                                try:
                                                    kn.findAndAddContactsByMid(Hmid)
                                                    kn.kickoutFromGroup(op.param1,[op.param2])
                                                    kn.inviteIntoGroup(op.param1,[op.param3])
                                                    kw.acceptGroupInvitation(op.param1)
                                                    group = kw.getGroup(op.param1)
                                                    nama = [contact.mid for contact in group.members]
                                                    for x in nama:
                                                        if x in wait["blacklist"]:
                                                            kw.kickoutFromGroup(op.param1,[x])
                                                except:
                                                    try:
                                                        ke.findAndAddContactsByMid(Hmid)
                                                        ke.kickoutFromGroup(op.param1,[op.param2])
                                                        ke.inviteIntoGroup(op.param1,[op.param3])
                                                        kw.acceptGroupInvitation(op.param1)
                                                        group = kw.getGroup(op.param1)
                                                        nama = [contact.mid for contact in group.members]
                                                        for x in nama:
                                                            if x in wait["blacklist"]:
                                                                kw.kickoutFromGroup(op.param1,[x])
                                                    except:
                                                        try:
                                                            random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
                                                            random.choice(ABC).inviteIntoGroup(op.param1,[op.param3])
                                                            kw.acceptGroupInvitation(op.param1)
                                                        except:
                                                            try:
                                                            	aj.acceptGroupInvitation(op.param1)
                                                            	sw.acceptGroupInvitation(op.param1)
                                                            	sw.kickoutFromGroup(op.param1,[op.param2])
                                                            	G = aj.getGroup(op.param1)
                                                            	G.preventedJoinByTicket = False
                                                            	aj.updateGroup(G)
                                                            	Ticket = aj.reissueGroupTicket(op.param1)
                                                            	cl.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	ki.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	kk.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	kc.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	km.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	kb.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	kn.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	ko.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	kw.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	ke.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	ky.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	aj.leaveGroup(op.param1)
                                                            	sw.leaveGroup(op.param1)
                                                            	G = cl.getGroup(op.param1)
                                                            	G.preventedJoinByTicket = True
                                                            	cl.updateGroup(G)
                                                            except:
                                                            	pass

                return

            if Imid in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    wait["qr"] = True
                    wait["inv"] = True
                    try:
                        ky.findAndAddContactsByMid(Imid)
                        ky.kickoutFromGroup(op.param1,[op.param2])
                        ky.inviteIntoGroup(op.param1,[op.param3])
                        ke.acceptGroupInvitation(op.param1)
                        group = ke.getGroup(op.param1)
                        nama = [contact.mid for contact in group.members]
                        for x in nama:
                            if x in wait["blacklist"]:
                                ke.kickoutFromGroup(op.param1,[x])
                    except:
                        try:
                            ki.findAndAddContactsByMid(Imid)
                            ki.kickoutFromGroup(op.param1,[op.param2])
                            ki.inviteIntoGroup(op.param1,[op.param3])
                            ke.acceptGroupInvitation(op.param1)
                            group = ke.getGroup(op.param1)
                            nama = [contact.mid for contact in group.members]
                            for x in nama:
                                if x in wait["blacklist"]:
                                    ke.kickoutFromGroup(op.param1,[x])
                        except:
                            try:
                                kk.findAndAddContactsByMid(Imid)
                                kk.kickoutFromGroup(op.param1,[op.param2])
                                kk.inviteIntoGroup(op.param1,[op.param3])
                                ke.acceptGroupInvitation(op.param1)
                                group = ke.getGroup(op.param1)
                                nama = [contact.mid for contact in group.members]
                                for x in nama:
                                    if x in wait["blacklist"]:
                                        ke.kickoutFromGroup(op.param1,[x])
                            except:
                                try:
                                    kc.findAndAddContactsByMid(Imid)
                                    kc.kickoutFromGroup(op.param1,[op.param2])
                                    kc.inviteIntoGroup(op.param1,[op.param3])
                                    ke.acceptGroupInvitation(op.param1)
                                    group = ke.getGroup(op.param1)
                                    nama = [contact.mid for contact in group.members]
                                    for x in nama:
                                        if x in wait["blacklist"]:
                                            ke.kickoutFromGroup(op.param1,[x])
                                except:
                                    try:
                                        km.findAndAddContactsByMid(Imid)
                                        km.kickoutFromGroup(op.param1,[op.param2])
                                        km.inviteIntoGroup(op.param1,[op.param3])
                                        ke.acceptGroupInvitation(op.param1)
                                        group = ke.getGroup(op.param1)
                                        nama = [contact.mid for contact in group.members]
                                        for x in nama:
                                            if x in wait["blacklist"]:
                                                ke.kickoutFromGroup(op.param1,[x])
                                    except:
                                        try:
                                            kb.findAndAddContactsByMid(Imid)
                                            kb.kickoutFromGroup(op.param1,[op.param2])
                                            kb.inviteIntoGroup(op.param1,[op.param3])
                                            ke.acceptGroupInvitation(op.param1)
                                            group = ke.getGroup(op.param1)
                                            nama = [contact.mid for contact in group.members]
                                            for x in nama:
                                                if x in wait["blacklist"]:
                                                    ke.kickoutFromGroup(op.param1,[x])
                                        except:
                                            try:
                                                kn.findAndAddContactsByMid(Imid)
                                                kn.kickoutFromGroup(op.param1,[op.param2])
                                                kn.inviteIntoGroup(op.param1,[op.param3])
                                                ke.acceptGroupInvitation(op.param1)
                                                group = ke.getGroup(op.param1)
                                                nama = [contact.mid for contact in group.members]
                                                for x in nama:
                                                    if x in wait["blacklist"]:
                                                        ke.kickoutFromGroup(op.param1,[x])
                                            except:
                                                try:
                                                    ko.findAndAddContactsByMid(Imid)
                                                    ko.kickoutFromGroup(op.param1,[op.param2])
                                                    ko.inviteIntoGroup(op.param1,[op.param3])
                                                    ke.acceptGroupInvitation(op.param1)
                                                    group = ke.getGroup(op.param1)
                                                    nama = [contact.mid for contact in group.members]
                                                    for x in nama:
                                                        if x in wait["blacklist"]:
                                                            ke.kickoutFromGroup(op.param1,[x])
                                                except:
                                                    try:
                                                        kw.findAndAddContactsByMid(Imid)
                                                        kw.kickoutFromGroup(op.param1,[op.param2])
                                                        kw.inviteIntoGroup(op.param1,[op.param3])
                                                        ke.acceptGroupInvitation(op.param1)
                                                        group = ke.getGroup(op.param1)
                                                        nama = [contact.mid for contact in group.members]
                                                        for x in nama:
                                                            if x in wait["blacklist"]:
                                                                ke.kickoutFromGroup(op.param1,[x])
                                                    except:
                                                        try:
                                                            random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
                                                            random.choice(ABC).inviteIntoGroup(op.param1,[op.param3])
                                                            ke.acceptGroupInvitation(op.param1)
                                                        except:
                                                            try:
                                                            	aj.acceptGroupInvitation(op.param1)
                                                            	sw.acceptGroupInvitation(op.param1)
                                                            	sw.kickoutFromGroup(op.param1,[op.param2])
                                                            	G = aj.getGroup(op.param1)
                                                            	G.preventedJoinByTicket = False
                                                            	aj.updateGroup(G)
                                                            	Ticket = aj.reissueGroupTicket(op.param1)
                                                            	cl.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	ki.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	kk.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	kc.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	km.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	kb.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	kn.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	ko.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	kw.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	ke.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	ky.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	aj.leaveGroup(op.param1)
                                                            	sw.leaveGroup(op.param1)
                                                            	G = cl.getGroup(op.param1)
                                                            	G.preventedJoinByTicket = True
                                                            	cl.updateGroup(G)
                                                            except:
                                                            	pass

                return

            if Jmid in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    wait["qr"] = True
                    wait["inv"] = True
                    try:
                        ki.findAndAddContactsByMid(Jmid)
                        ki.kickoutFromGroup(op.param1,[op.param2])
                        ki.inviteIntoGroup(op.param1,[op.param3])
                        ky.acceptGroupInvitation(op.param1)
                        group = ky.getGroup(op.param1)
                        nama = [contact.mid for contact in group.members]
                        for x in nama:
                            if x in wait["blacklist"]:
                                ky.kickoutFromGroup(op.param1,[x])
                    except:
                        try:
                            kk.findAndAddContactsByMid(Jmid)
                            kk.kickoutFromGroup(op.param1,[op.param2])
                            kk.inviteIntoGroup(op.param1,[op.param3])
                            ky.acceptGroupInvitation(op.param1)
                            group = ky.getGroup(op.param1)
                            nama = [contact.mid for contact in group.members]
                            for x in nama:
                                if x in wait["blacklist"]:
                                    ky.kickoutFromGroup(op.param1,[x])
                        except:
                            try:
                                kc.findAndAddContactsByMid(Jmid)
                                kc.kickoutFromGroup(op.param1,[op.param2])
                                kc.inviteIntoGroup(op.param1,[op.param3])
                                ky.acceptGroupInvitation(op.param1)
                                group = ky.getGroup(op.param1)
                                nama = [contact.mid for contact in group.members]
                                for x in nama:
                                    if x in wait["blacklist"]:
                                        ky.kickoutFromGroup(op.param1,[x])
                            except:
                                try:
                                    km.findAndAddContactsByMid(Jmid)
                                    km.kickoutFromGroup(op.param1,[op.param2])
                                    km.inviteIntoGroup(op.param1,[op.param3])
                                    ky.acceptGroupInvitation(op.param1)
                                    group = ky.getGroup(op.param1)
                                    nama = [contact.mid for contact in group.members]
                                    for x in nama:
                                        if x in wait["blacklist"]:
                                            ky.kickoutFromGroup(op.param1,[x])
                                except:
                                    try:
                                        kb.findAndAddContactsByMid(Jmid)
                                        kb.kickoutFromGroup(op.param1,[op.param2])
                                        kb.inviteIntoGroup(op.param1,[op.param3])
                                        ky.acceptGroupInvitation(op.param1)
                                        group = ky.getGroup(op.param1)
                                        nama = [contact.mid for contact in group.members]
                                        for x in nama:
                                            if x in wait["blacklist"]:
                                                ky.kickoutFromGroup(op.param1,[x])
                                    except:
                                        try:
                                            kn.findAndAddContactsByMid(Jmid)
                                            kn.kickoutFromGroup(op.param1,[op.param2])
                                            kn.inviteIntoGroup(op.param1,[op.param3])
                                            ky.acceptGroupInvitation(op.param1)
                                            group = ky.getGroup(op.param1)
                                            nama = [contact.mid for contact in group.members]
                                            for x in nama:
                                                if x in wait["blacklist"]:
                                                    ky.kickoutFromGroup(op.param1,[x])
                                        except:
                                            try:
                                                ko.findAndAddContactsByMid(Jmid)
                                                ko.kickoutFromGroup(op.param1,[op.param2])
                                                ko.inviteIntoGroup(op.param1,[op.param3])
                                                ky.acceptGroupInvitation(op.param1)
                                                group = ky.getGroup(op.param1)
                                                nama = [contact.mid for contact in group.members]
                                                for x in nama:
                                                    if x in wait["blacklist"]:
                                                        ky.kickoutFromGroup(op.param1,[x])
                                            except:
                                                try:
                                                    kw.findAndAddContactsByMid(Jmid)
                                                    kw.kickoutFromGroup(op.param1,[op.param2])
                                                    kw.inviteIntoGroup(op.param1,[op.param3])
                                                    ky.acceptGroupInvitation(op.param1)
                                                    group = ky.getGroup(op.param1)
                                                    nama = [contact.mid for contact in group.members]
                                                    for x in nama:
                                                        if x in wait["blacklist"]:
                                                            ky.kickoutFromGroup(op.param1,[x])
                                                except:
                                                    try:
                                                        ke.findAndAddContactsByMid(Jmid)
                                                        ke.kickoutFromGroup(op.param1,[op.param2])
                                                        ke.inviteIntoGroup(op.param1,[op.param3])
                                                        ky.acceptGroupInvitation(op.param1)
                                                        group = ky.getGroup(op.param1)
                                                        nama = [contact.mid for contact in group.members]
                                                        for x in nama:
                                                            if x in wait["blacklist"]:
                                                                ky.kickoutFromGroup(op.param1,[x])
                                                    except:
                                                        try:
                                                            random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
                                                            random.choice(ABC).inviteIntoGroup(op.param1,[op.param3])
                                                            ky.acceptGroupInvitation(op.param1)
                                                        except:
                                                            try:
                                                            	aj.acceptGroupInvitation(op.param1)
                                                            	sw.acceptGroupInvitation(op.param1)
                                                            	sw.kickoutFromGroup(op.param1,[op.param2])
                                                            	G = aj.getGroup(op.param1)
                                                            	G.preventedJoinByTicket = False
                                                            	aj.updateGroup(G)
                                                            	Ticket = aj.reissueGroupTicket(op.param1)
                                                            	cl.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	ki.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	kk.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	kc.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	km.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	kb.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	kn.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	ko.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	kw.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	ke.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	ky.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                            	aj.leaveGroup(op.param1)
                                                            	sw.leaveGroup(op.param1)
                                                            	G = cl.getGroup(op.param1)
                                                            	G.preventedJoinByTicket = True
                                                            	cl.updateGroup(G)
                                                            except:
                                                            	pass

                return

            if Zmid in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    wait["qr"] = True
                    wait["inv"] = True
                    try:
                        ki.findAndAddContactsByMid(Zmid)
                        ki.kickoutFromGroup(op.param1,[op.param2])
                        ki.inviteIntoGroup(op.param1,[op.param3])
                    except:
                        try:
                            kk.findAndAddContactsByMid(Zmid)
                            kk.kickoutFromGroup(op.param1,[op.param2])
                            kk.inviteIntoGroup(op.param1,[op.param3])
                        except:
                            try:
                                kc.findAndAddContactsByMid(Zmid)
                                kc.kickoutFromGroup(op.param1,[op.param2])
                                kc.inviteIntoGroup(op.param1,[op.param3])
                            except:
                                try:
                                    km.findAndAddContactsByMid(Zmid)
                                    km.kickoutFromGroup(op.param1,[op.param2])
                                    km.inviteIntoGroup(op.param1,[op.param3])
                                except:
                                    try:
                                        kb.findAndAddContactsByMid(Zmid)
                                        kb.kickoutFromGroup(op.param1,[op.param2])
                                        kb.inviteIntoGroup(op.param1,[op.param3])
                                    except:
                                        try:
                                            kn.findAndAddContactsByMid(Zmid)
                                            kn.kickoutFromGroup(op.param1,[op.param2])
                                            kn.inviteIntoGroup(op.param1,[op.param3])
                                        except:
                                            try:
                                                ko.findAndAddContactsByMid(Zmid)
                                                ko.kickoutFromGroup(op.param1,[op.param2])
                                                ko.inviteIntoGroup(op.param1,[op.param3])
                                            except:
                                                try:
                                                    kw.findAndAddContactsByMid(Zmid)
                                                    kw.kickoutFromGroup(op.param1,[op.param2])
                                                    kw.inviteIntoGroup(op.param1,[op.param3])
                                                except:
                                                    try:
                                                        ke.findAndAddContactsByMid(Zmid)
                                                        ke.kickoutFromGroup(op.param1,[op.param2])
                                                        ke.inviteIntoGroup(op.param1,[op.param3])
                                                    except:
                                                        try:
                                                            ky.findAndAddContactsByMid(Zmid)
                                                            ky.kickoutFromGroup(op.param1,[op.param2])
                                                            ky.inviteIntoGroup(op.param1,[op.param3])
                                                        except:
                                                            pass

                return

            if Xmid in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    wait["qr"] = True
                    wait["inv"] = True
                    try:
                        ki.findAndAddContactsByMid(Xmid)
                        ki.kickoutFromGroup(op.param1,[op.param2])
                        ki.inviteIntoGroup(op.param1,[op.param3])
                    except:
                        try:
                            kk.findAndAddContactsByMid(Xmid)
                            kk.kickoutFromGroup(op.param1,[op.param2])
                            kk.inviteIntoGroup(op.param1,[op.param3])
                        except:
                            try:
                                kc.findAndAddContactsByMid(Xmid)
                                kc.kickoutFromGroup(op.param1,[op.param2])
                                kc.inviteIntoGroup(op.param1,[op.param3])
                            except:
                                try:
                                    km.findAndAddContactsByMid(Xmid)
                                    km.kickoutFromGroup(op.param1,[op.param2])
                                    km.inviteIntoGroup(op.param1,[op.param3])
                                except:
                                    try:
                                        kb.findAndAddContactsByMid(Xmid)
                                        kb.kickoutFromGroup(op.param1,[op.param2])
                                        kb.inviteIntoGroup(op.param1,[op.param3])
                                    except:
                                        try:
                                            kn.findAndAddContactsByMid(Xmid)
                                            kn.kickoutFromGroup(op.param1,[op.param2])
                                            kn.inviteIntoGroup(op.param1,[op.param3])
                                        except:
                                            try:
                                                ko.findAndAddContactsByMid(Xmid)
                                                ko.kickoutFromGroup(op.param1,[op.param2])
                                                ko.inviteIntoGroup(op.param1,[op.param3])
                                            except:
                                                try:
                                                    kw.findAndAddContactsByMid(Xmid)
                                                    kw.kickoutFromGroup(op.param1,[op.param2])
                                                    kw.inviteIntoGroup(op.param1,[op.param3])
                                                except:
                                                    try:
                                                        ke.findAndAddContactsByMid(Xmid)
                                                        ke.kickoutFromGroup(op.param1,[op.param2])
                                                        ke.inviteIntoGroup(op.param1,[op.param3])
                                                    except:
                                                        try:
                                                            ky.findAndAddContactsByMid(Xmid)
                                                            ky.kickoutFromGroup(op.param1,[op.param2])
                                                            ky.inviteIntoGroup(op.param1,[op.param3])
                                                        except:
                                                            pass

                return

            if op.param3 in admin1:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin:
                    wait["blacklist"][op.param2] = True
                    wait["qr"] = True
                    wait["inv"] = True
                    try:
                        ki.kickoutFromGroup(op.param1,[op.param2])
                        ls = cl.getContact(admin1).mid
                        cl.findAndAddContactsByMid(ls)
                        cl.inviteIntoGroup(op.param1,[ls])
                    except:
                        try:
                            kk.kickoutFromGroup(op.param1,[op.param2])
                            ls = ki.getContact(admin1).mid
                            ki.findAndAddContactsByMid(ls)
                            ki.inviteIntoGroup(op.param1,[ls])
                        except:
                            try:
                                kc.kickoutFromGroup(op.param1,[op.param2])
                                ls = kk.getContact(admin1).mid
                                kk.findAndAddContactsByMid(ls)
                                kk.inviteIntoGroup(op.param1,[ls])
                            except:
                                try:
                                    km.kickoutFromGroup(op.param1,[op.param2])
                                    ls = kc.getContact(admin1).mid
                                    kc.findAndAddContactsByMid(ls)
                                    kc.inviteIntoGroup(op.param1,[ls])
                                except:
                                    try:
                                        kb.kickoutFromGroup(op.param1,[op.param2])
                                        ls = km.getContact(admin1).mid
                                        km.findAndAddContactsByMid(ls)
                                        km.inviteIntoGroup(op.param1,[ls])
                                    except:
                                        try:
                                            kn.kickoutFromGroup(op.param1,[op.param2])
                                            ls = kb.getContact(admin1).mid
                                            kb.findAndAddContactsByMid(ls)
                                            kb.inviteIntoGroup(op.param1,[ls])
                                        except:
                                            try:
                                                ko.kickoutFromGroup(op.param1,[op.param2])
                                                ls = kn.getContact(admin1).mid
                                                kn.findAndAddContactsByMid(ls)
                                                kn.inviteIntoGroup(op.param1,[ls])
                                            except:
                                                try:
                                                    kw.kickoutFromGroup(op.param1,[op.param2])
                                                    ls = ko.getContact(admin1).mid
                                                    ko.findAndAddContactsByMid(ls)
                                                    ko.inviteIntoGroup(op.param1,[ls])
                                                except:
                                                    try:
                                                        ke.kickoutFromGroup(op.param1,[op.param2])
                                                        ls = kw.getContact(admin1).mid
                                                        kw.findAndAddContactsByMid(ls)
                                                        kw.inviteIntoGroup(op.param1,[ls])
                                                    except:
                                                        try:
                                                            ky.kickoutFromGroup(op.param1,[op.param2])
                                                            ls = ke.getContact(admin1).mid
                                                            ke.findAndAddContactsByMid(ls)
                                                            ke.inviteIntoGroup(op.param1,[ls])
                                                        except:
                                                            pass
                return

            if op.param3 in admin:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin:
                    wait["blacklist"][op.param2] = True
                    wait["qr"] = True
                    wait["inv"] = True
                    try:
                        ki.kickoutFromGroup(op.param1,[op.param2])
                        cl.findAndAddContactsByMid("ub8d98fa1689f21b1162cb757aba42ad3")
                        cl.inviteIntoGroup(op.param1,["ub8d98fa1689f21b1162cb757aba42ad3"])
                    except:
                        try:
                            kk.kickoutFromGroup(op.param1,[op.param2])
                            kk.findAndAddContactsByMid("ub8d98fa1689f21b1162cb757aba42ad3")
                            kk.inviteIntoGroup(op.param1,["ub8d98fa1689f21b1162cb757aba42ad3"])
                        except:
                            try:
                                kc.kickoutFromGroup(op.param1,[op.param2])
                                kc.findAndAddContactsByMid("ub8d98fa1689f21b1162cb757aba42ad3")
                                kc.inviteIntoGroup(op.param1,["ub8d98fa1689f21b1162cb757aba42ad3"])
                            except:
                                try:
                                    km.kickoutFromGroup(op.param1,[op.param2])
                                    km.findAndAddContactsByMid("ub8d98fa1689f21b1162cb757aba42ad3")
                                    km.inviteIntoGroup(op.param1,["ub8d98fa1689f21b1162cb757aba42ad3"])
                                except:
                                    try:
                                        kb.kickoutFromGroup(op.param1,[op.param2])
                                        kb.findAndAddContactsByMid("ub8d98fa1689f21b1162cb757aba42ad3")
                                        kb.inviteIntoGroup(op.param1,["ub8d98fa1689f21b1162cb757aba42ad3"])
                                    except:
                                        try:
                                            kn.kickoutFromGroup(op.param1,[op.param2])
                                            kn.findAndAddContactsByMid("ub8d98fa1689f21b1162cb757aba42ad3")
                                            kn.inviteIntoGroup(op.param1,["ub8d98fa1689f21b1162cb757aba42ad3"])
                                        except:
                                            try:
                                                ko.kickoutFromGroup(op.param1,[op.param2])
                                                ko.findAndAddContactsByMid("ub8d98fa1689f21b1162cb757aba42ad3")
                                                ko.inviteIntoGroup(op.param1,["ub8d98fa1689f21b1162cb757aba42ad3"])
                                            except:
                                                try:
                                                    kw.kickoutFromGroup(op.param1,[op.param2])
                                                    kw.findAndAddContactsByMid("ub8d98fa1689f21b1162cb757aba42ad3")
                                                    kw.inviteIntoGroup(op.param1,["ub8d98fa1689f21b1162cb757aba42ad3"])
                                                except:
                                                    try:
                                                        ke.kickoutFromGroup(op.param1,[op.param2])
                                                        ke.findAndAddContactsByMid("ub8d98fa1689f21b1162cb757aba42ad3")
                                                        ke.inviteIntoGroup(op.param1,["ub8d98fa1689f21b1162cb757aba42ad3"])
                                                    except:
                                                        try:
                                                            ky.kickoutFromGroup(op.param1,[op.param2])
                                                            ky.findAndAddContactsByMid("ub8d98fa1689f21b1162cb757aba42ad3")
                                                            ky.inviteIntoGroup(op.param1,["ub8d98fa1689f21b1162cb757aba42ad3"])
                                                        except:
                                                            pass
                return
#-------------------------------------------------------------------------------
        if op.type == 55:
            try:
                if op.param1 in Setmain["ARreadPoint"]:
                   if op.param2 in Setmain["ARreadMember"][op.param1]:
                       pass
                   else:
                       Setmain["ARreadMember"][op.param1][op.param2] = True
                else:
                   pass
            except:
                pass

            if cctv['cyduk'][op.param1]==True:
                if op.param1 in cctv['point']:
                    Name = cl.getContact(op.param2).displayName
                    if Name in cctv['sidermem'][op.param1]:
                        pass
                    else:
                        cctv['sidermem'][op.param1] += "\n~ " + Name
                        siderMembers(op.param1, [op.param2])
                        contact = cl.getContact(op.param2)
                        image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                        cl.sendImageWithURL(op.param1, image)
                        cl.sendMessage(op.param1, None, contentMetadata= barstick["sider"], contentType=7)

        if op.type == 55:
            if op.param2 in wait["blacklist"]:
                random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
            else:
                pass

        if op.type == 55:
            if op.param3 in wait["blacklist"]:
                random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
            else:
                pass

        if op.type == 26:
           if wait["selfbot"] == True:
               msg = op.message
               if msg._from not in Bots:
                 if wait["talkban"] == True:
                   if msg._from in wait["Talkblacklist"]:
                      try:
                          random.choice(ABC).kickoutFromGroup(msg.to, [msg._from])
                      except:
                          pass
               if 'MENTION' in msg.contentMetadata.keys() != None:
                 if wait["detectMention"] == True:
                   name = re.findall(r'@(\w+)', msg.text)
                   mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                   mentionees = mention['MENTIONEES']
                   for mention in mentionees:
                        if mention ['M'] in selfmid:
                           cl.sendMessage(msg.to, wait["Respontag"])
                           cl.sendMessage(msg.to, None, contentMetadata= barstick["respon"], contentType=7)
                           break
               if 'MENTION' in msg.contentMetadata.keys() != None:
                 if wait["Mentionkick"] == True:
                   name = re.findall(r'@(\w+)', msg.text)
                   mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                   mentionees = mention['MENTIONEES']
                   for mention in mentionees:
                        if mention ['M'] in selfmid:
                           cl.mentiontag(msg.to,[msg._from])
                           cl.sendMessage(msg.to, "Jangan tag saya....")
                           cl.kickoutFromGroup(msg.to, [msg._from])
                           break
               if msg.contentType == 7:
                 if wait["sticker"] == True:
                    msg.contentType = 0
                    cl.sendMessage(msg.to,"「Cek ID Sticker」\n❧STKID : " + msg.contentMetadata["STKID"] + "\n❧STKPKGID : " + msg.contentMetadata["STKPKGID"] + "\n❧STKVER : " + msg.contentMetadata["STKVER"]+ "\n\n「Link Sticker」" + "\nline://shop/detail/" + msg.contentMetadata["STKPKGID"])
               if msg.contentType == 13:
                 if wait["contact"] == True:
                    msg.contentType = 0
                    cl.sendMessage(msg.to,msg.contentMetadata["mid"])
                    if 'displayName' in msg.contentMetadata:
                        contact = cl.getContact(msg.contentMetadata["mid"])
                        path = cl.getContact(msg.contentMetadata["mid"]).picturePath
                        image = 'http://dl.profile.line.naver.jp'+path
                        cl.sendMessage(msg.to,"❧Nama : " + msg.contentMetadata["displayName"] + "\n❧MID : " + msg.contentMetadata["mid"] + "\n❧Status Msg : " + contact.statusMessage + "\n❧Picture URL : http://dl.profile.line-cdn.net/" + contact.pictureStatus)
                        cl.sendImageWithURL(msg.to, image)

        if op.type == 25 or op.type == 26:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0 or msg.toType == 2:
               if msg.toType == 0:
                    to = receiver
               elif msg.toType == 2:
                    to = receiver
               if msg.contentType == 7:
                 if wait["sticker"] == True:
                    msg.contentType = 0
                    cl.sendMessage(msg.to,"STKID : " + msg.contentMetadata["STKID"] + "\nSTKPKGID : " + msg.contentMetadata["STKPKGID"] + "\nSTKVER : " + msg.contentMetadata["STKVER"]+ "\n\n「Link Sticker」" + "\nline://shop/detail/" + msg.contentMetadata["STKPKGID"])
               if msg.contentType == 13:
                 if wait["contact"] == True:
                    msg.contentType = 0
                    cl.sendMessage(msg.to,msg.contentMetadata["mid"])
                    if 'displayName' in msg.contentMetadata:
                        contact = cl.getContact(msg.contentMetadata["mid"])
                        path = cl.getContact(msg.contentMetadata["mid"]).picturePath
                        image = 'http://dl.profile.line.naver.jp'+path
                        cl.sendMessage(msg.to,"❧Nama : " + msg.contentMetadata["displayName"] + "\n❧MID : " + msg.contentMetadata["mid"] + "\n❧Status Msg : " + contact.statusMessage + "\n❧Picture URL : http://dl.profile.line-cdn.net/" + contact.pictureStatus)
                        cl.sendImageWithURL(msg.to, image)
#ADD Bots
               if msg.contentType == 13:
                 if msg._from in admin:
                  if wait["addbots"] == True:
                    if msg.contentMetadata["mid"] in Bots:
                        cl.sendMessage(msg.to,"Contact itu sudah jadi anggota bot")
                        wait["addbots"] = True
                    else:
                        Bots.append(msg.contentMetadata["mid"])
                        wait["addbots"] = True
                        cl.sendMessage(msg.to,"Berhasil menambahkan ke anggota bot")
                 if wait["dellbots"] == True:
                    if msg.contentMetadata["mid"] in Bots:
                        Bots.remove(msg.contentMetadata["mid"])
                        cl.sendMessage(msg.to,"Berhasil menghapus dari anggota bot")
                    else:
                        wait["dellbots"] = True
                        cl.sendMessage(msg.to,"Contact itu bukan anggota bot bot")
#ADD STAFF
                 if msg._from in admin:
                  if wait["addstaff"] == True:
                    if msg.contentMetadata["mid"] in famzadmin["staff"]:
                        cl.sendMessage(msg.to,"was staff")
                    else:
                        famzadmin["staff"][msg.contentMetadata["mid"]] = True
                        f=codecs.open('famzadmin.json','w','utf-8')
                        json.dump(famzadmin, f, sort_keys=True, indent=4,ensure_ascii=False)
                        cl.sendMessage(msg.to,"succes add staff")
                 if wait["dellstaff"] == True:
                    if msg.contentMetadata["mid"] in famzadmin["staff"]:
                        del famzadmin["staff"][msg.contentMetadata["mid"]]
                        f=codecs.open('famzadmin.json','w','utf-8')
                        json.dump(famzadmin, f, sort_keys=True, indent=4,ensure_ascii=False)
                        cl.sendMessage(msg.to,"Succes remove staff")
                    else:
                        cl.sendMessage(msg.to,"Contact not in list staff")
#ADD ADMIN
                 if msg._from in admin:
                  if wait["addadmin"] == True:
                    if msg.contentMetadata["mid"] in admin:
                        cl.sendMessage(msg.to,"Contact itu sudah jadi admin")
                        wait["addadmin"] = True
                    else:
                        admin.append(msg.contentMetadata["mid"])
                        wait["addadmin"] = True
                        cl.sendMessage(msg.to,"Berhasil menambahkan ke admin")
                 if wait["delladmin"] == True:
                    if msg.contentMetadata["mid"] in admin:
                        admin.remove(msg.contentMetadata["mid"])
                        cl.sendMessage(msg.to,"Berhasil menghapus dari admin")
                    else:
                        wait["delladmin"] = True
                        cl.sendMessage(msg.to,"Contact itu bukan admin")
#ADD BLACKLIST
                 if msg._from in admin:
                  if wait["wblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["blacklist"]:
                        cl.sendMessage(msg.to,"Contact itu sudah ada di blacklist")
                        wait["wblacklist"] = True
                    else:
                        wait["blacklist"][msg.contentMetadata["mid"]] = True
                        wait["wblacklist"] = True
                        cl.sendMessage(msg.to,"Berhasil menambahkan ke blacklist user")
                  if wait["dblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["blacklist"]:
                        del wait["blacklist"][msg.contentMetadata["mid"]]
                        cl.sendMessage(msg.to,"Berhasil menghapus dari blacklist user")
                    else:
                        wait["dblacklist"] = True
                        cl.sendMessage(msg.to,"Contact itu tidak ada di blacklist")
#TALKBAN
                 if msg._from in admin:
                  if wait["Talkwblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["Talkblacklist"]:
                        cl.sendMessage(msg.to,"Contact itu sudah ada di Talkban")
                        wait["Talkwblacklist"] = True
                    else:
                        wait["Talkblacklist"][msg.contentMetadata["mid"]] = True
                        wait["Talkwblacklist"] = True
                        cl.sendMessage(msg.to,"Berhasil menambahkan ke Talkban user")
                  if wait["Talkdblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["Talkblacklist"]:
                        del wait["Talkblacklist"][msg.contentMetadata["mid"]]
                        cl.sendMessage(msg.to,"Berhasil menghapus dari Talkban user")
                    else:
                        wait["Talkdblacklist"] = True
                        cl.sendMessage(msg.to,"Contact itu tidak ada di Talkban")
#UPDATE FOTO
               if msg.contentType == 1:
                 if msg._from in admin:
                    if Setmain["Addimage"] == True:
                        msgid = msg.id
                        fotoo = "https://obs.line-apps.com/talk/m/download.nhn?oid="+msgid
                        headers = cl.Talk.Headers
                        r = requests.get(fotoo, headers=headers, stream=True)
                        if r.status_code == 200:
                            path = os.path.join(os.path.dirname(__file__), 'dataPhotos/%s.jpg' % Setmain["Img"])
                            with open(path, 'wb') as fp:
                                shutil.copyfileobj(r.raw, fp)
                            cl.sendMessage(msg.to, "Berhasil menambahkan gambar")
                        Setmain["Img"] = {}
                        Setmain["Addimage"] = False

               if msg.toType == 2:
                 if msg._from in admin:
                   if settings["groupPicture"] == True:
                     path = cl.downloadObjectMsg(msg_id)
                     settings["groupPicture"] = False
                     cl.updateGroupPicture(msg.to, path)
                     cl.sendMessage(msg.to, "Berhasil mengubah foto group")

               if msg.contentType == 1:
                   if msg._from in admin:
                       if selfmid in Setmain["ARfoto"]:
                            path = cl.downloadObjectMsg(msg_id)
                            del Setmain["ARfoto"][selfmid]
                            cl.updateProfilePicture(path)
                            cl.sendMessage(msg.to,"succes change photo")

               if msg.contentType == 7:
                 if msg._from in admin:
                    if wait["setsticker"]["status"] == True:
                        barstick[wait["setsticker"]["name"]] = {"STKID":msg.contentMetadata["STKID"],"STKPKGID":msg.contentMetadata["STKPKGID"],"STKVER":msg.contentMetadata["STKVER"]}
                        f = codecs.open("sticker4.json","w","utf-8")
                        json.dump(barstick, f, sort_keys=True, indent=4, ensure_ascii=False)
                        cl.sendMessage(msg.to, "Berhasil mengganti sticker {}".format(str(wait["setsticker"]["name"])))
                        wait["setsticker"]["status"] = False
                        wait["setsticker"]["name"] = ""

               if msg.contentType == 1:
                 if msg._from in admin:
                        if Amid in Setmain["ARfoto"]:
                            path = ki.downloadObjectMsg(msg_id)
                            del Setmain["ARfoto"][Amid]
                            ki.updateProfilePicture(path)
                            ki.sendMessage(msg.to,"succes change photo")
                        elif Bmid in Setmain["ARfoto"]:
                            path = kk.downloadObjectMsg(msg_id)
                            del Setmain["ARfoto"][Bmid]
                            kk.updateProfilePicture(path)
                            kk.sendMessage(msg.to,"succes change photo")
                        elif Cmid in Setmain["ARfoto"]:
                            path = kc.downloadObjectMsg(msg_id)
                            del Setmain["ARfoto"][Cmid]
                            kc.updateProfilePicture(path)
                            kc.sendMessage(msg.to,"succes change photo")
                        elif Dmid in Setmain["ARfoto"]:
                            path = km.downloadObjectMsg(msg_id)
                            del Setmain["ARfoto"][Dmid]
                            km.updateProfilePicture(path)
                            km.sendMessage(msg.to,"succes change photo")
                        elif Emid in Setmain["ARfoto"]:
                            path = kb.downloadObjectMsg(msg_id)
                            del Setmain["ARfoto"][Emid]
                            kb.updateProfilePicture(path)
                            kb.sendMessage(msg.to,"succes change photo")
                        elif Fmid in Setmain["ARfoto"]:
                            path = kn.downloadObjectMsg(msg_id)
                            del Setmain["ARfoto"][Fmid]
                            kn.updateProfilePicture(path)
                            kn.sendMessage(msg.to,"succes change photo")
                        elif Gmid in Setmain["ARfoto"]:
                            path = ko.downloadObjectMsg(msg_id)
                            del Setmain["ARfoto"][Gmid]
                            ko.updateProfilePicture(path)
                            ko.sendMessage(msg.to,"succes change photo")
                        elif Hmid in Setmain["ARfoto"]:
                            path = kw.downloadObjectMsg(msg_id)
                            del Setmain["ARfoto"][Hmid]
                            kw.updateProfilePicture(path)
                            kw.sendMessage(msg.to,"succes change photo")
                        elif Imid in Setmain["ARfoto"]:
                            path = ke.downloadObjectMsg(msg_id)
                            del Setmain["ARfoto"][Imid]
                            ke.updateProfilePicture(path)
                            ke.sendMessage(msg.to,"succes change photo")
                        elif Jmid in Setmain["ARfoto"]:
                            path = ky.downloadObjectMsg(msg_id)
                            del Setmain["ARfoto"][Jmid]
                            ky.updateProfilePicture(path)
                            ky.sendMessage(msg.to,"succes change photo")
                        elif Xmid in Setmain["ARfoto"]:
                            path = aj.downloadObjectMsg(msg_id)
                            del Setmain["ARfoto"][Xmid]
                            aj.updateProfilePicture(path)
                            aj.sendMessage(msg.to,"succes change photo")
                        elif Zmid in Setmain["ARfoto"]:
                            path = sw.downloadObjectMsg(msg_id)
                            del Setmain["ARfoto"][Zmid]
                            sw.updateProfilePicture(path)
                            sw.sendMessage(msg.to,"succes change photo")

               if msg.contentType == 1:
                 if msg._from in admin:
                   if settings["changePicture"] == True:
                     path1 = ki.downloadObjectMsg(msg_id)
                     path2 = kk.downloadObjectMsg(msg_id)
                     path3 = kc.downloadObjectMsg(msg_id)
                     path4 = km.downloadObjectMsg(msg_id)
                     path5 = kb.downloadObjectMsg(msg_id)
                     path6 = kn.downloadObjectMsg(msg_id)
                     path7 = ko.downloadObjectMsg(msg_id)
                     path8 = kw.downloadObjectMsg(msg_id)
                     path9 = ke.downloadObjectMsg(msg_id)
                     path10 = ky.downloadObjectMsg(msg_id)
                     settings["changePicture"] = False
                     ki.updateProfilePicture(path1)
                     ki.sendMessage(msg.to, "succes change photo")
                     kk.updateProfilePicture(path2)
                     kk.sendMessage(msg.to, "succes change photo")
                     kc.updateProfilePicture(path3)
                     kc.sendMessage(msg.to, "succes change photo")
                     km.updateProfilePicture(path4)
                     km.sendMessage(msg.to, "succes change photo")
                     kb.updateProfilePicture(path5)
                     kb.sendMessage(msg.to, "succes change photo")
                     kn.updateProfilePicture(path6)
                     kn.sendMessage(msg.to, "succes change photo")
                     ko.updateProfilePicture(path7)
                     ko.sendMessage(msg.to, "succes change photo")
                     kw.updateProfilePicture(path8)
                     kw.sendMessage(msg.to, "succes change photo")
                     ke.updateProfilePicture(path9)
                     ke.sendMessage(msg.to, "succes change photo")
                     ky.updateProfilePicture(path10)
                     ky.sendMessage(msg.to, "succes change photo")

               if msg.contentType == 0:
                    if Setmain["autoRead"] == True:
                        cl.sendChatChecked(msg.to, msg_id)
                        ki.sendChatChecked(msg.to, msg_id)
                        kk.sendChatChecked(msg.to, msg_id)
                        kc.sendChatChecked(msg.to, msg_id)
                        km.sendChatChecked(msg.to, msg_id)
                        kb.sendChatChecked(msg.to, msg_id)
                        kn.sendChatChecked(msg.to, msg_id)
                        ko.sendChatChecked(msg.to, msg_id)
                        kw.sendChatChecked(msg.to, msg_id)
                        ke.sendChatChecked(msg.to, msg_id)
                        ky.sendChatChecked(msg.to, msg_id)

                    if text is None:
                        return
                    else:
                        cmd = command(text)
                        if cmd == "help":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               helpMessage = help()
                               cl.sendMessage(msg.to, str(helpMessage))

                        if cmd == "self on":
                            if msg._from in admin:
                                wait["selfbot"] = True
                                cl.sendMessage(msg.to, "Selfbot active")

                        elif cmd == "self off":
                            if msg._from in admin:
                                wait["selfbot"] = False
                                cl.sendMessage(msg.to, "Selfbot not active")

                        elif cmd == "help2":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               helpMessage1 = helpbot()
                               cl.sendMessage(msg.to, str(helpMessage1))

                        elif cmd == "status":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                tz = pytz.timezone("Asia/Jakarta")
                                timeNow = datetime.now(tz=tz)
                                md = "❧﴾ sᴀмuᴅʀᴀ____ʙoтs ﴿\n"
                                if wait["sticker"] == True: md+="❧Sticker「ON」\n"
                                else: md+="❧Sticker「OFF」\n"
                                if wait["contact"] == True: md+="❧Contact「ON」\n"
                                else: md+="❧Contact「OFF」\n"
                                if wait["talkban"] == True: md+="❧Talkban「ON」\n"
                                else: md+="❧Talkban「OFF」\n"
                                if wait["Mentionkick"] == True: md+="❧Notag���ON」\n"
                                else: md+="❧Notag「OFF���\n"
                                if wait["detectMention"] == True: md+="❧Respon「ON」\n"
                                else: md+="❧Respon「OFF」\n"
                                if wait["autoJoin"] == True: md+="❧Autojoin「ON」\n"
                                else: md+="❧Autojoin「OFF」\n"
                                if wait["autoAdd"] == True: md+="❧Autoadd「ON」\n"
                                else: md+="❧Autoadd「OFF」\n"
                                if msg.to in welcome: md+="❧Welcome「ON」\n"
                                else: md+="❧Welcome「OFF」\n"
                                if wait["autoLeave"] == True: md+="❧Autoleave「ON」\n"
                                else: md+="❧Autoleave「OFF」\n"
                                if msg.to in protectqr: md+="❧Protecturl「ON」\n"
                                else: md+="❧Protecturl「OFF」\n"
                                if msg.to in protectjoin: md+="❧Protectjoin「ON」\n"
                                else: md+="❧Protectjoin「OFF」\n"
                                if msg.to in protectkick: md+="❧Protectkick「ON」\n"
                                else: md+="❧Protectkick「OFF」\n"
                                if msg.to in protectinvite: md+="❧Protectinvite「ON」\n"
                                else: md+="❧Protectinvite「OFF」\n"
                                if msg.to in protectcancel: md+="❧Protectcancel「ON」\n"
                                else: md+="❧Protectcancel「OFF」\n"
                                if msg.to in protectantijs: md+="❧Antijs「ON」\n"
                                else: md+="❧Antijs「OFF」\n"
                                cl.sendMessage(msg.to, md+"\nTanggal : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nJam [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]")

                        elif cmd == "creator" or text.lower() == 'creator':
                            if msg._from in admin:
                                cl.sendText(msg.to,"Creator : bang samudra\nsamudrabots.py")
                                ma = ""
                                for i in creator:
                                    ma = cl.getContact(i)
                                    cl.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)

                        elif cmd == "about" or cmd == "informasi":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               sendMention(msg.to, sender, "「 Type Selfbot 」\n")
                               cl.sendMessage(msg.to, None, contentMetadata={'mid': selfmid}, contentType=13)

                        elif cmd == "me" or text.lower() == 'aim':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               cl.sendMessage(to, "team ﴾ sᴀмuᴅʀᴀ____ʙoтs ﴿")
                               cl.sendMessage(msg.to, None, contentMetadata= barstick["saya"], contentType=7)

                        elif text.lower() == "mid":
                               cl.sendMessage(msg.to, msg._from)

                        elif ("Mid " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key1 = key["MENTIONEES"][0]["M"]
                               mi = cl.getContact(key1)
                               cl.sendMessage(msg.to, "Nama : "+str(mi.displayName)+"\nMID : " +key1)
                               cl.sendMessage(msg.to, None, contentMetadata={'mid': key1}, contentType=13)

                        elif ("Info " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key1 = key["MENTIONEES"][0]["M"]
                               mi = cl.getContact(key1)
                               cl.sendMessage(msg.to, "❧Nama : "+str(mi.displayName)+"\n❧Mid : " +key1+"\n❧Status Msg"+str(mi.statusMessage))
                               cl.sendMessage(msg.to, None, contentMetadata={'mid': key1}, contentType=13)
                               if "videoProfile='{" in str(cl.getContact(key1)):
                                   cl.sendVideoWithURL(msg.to, 'http://dl.profile.line.naver.jp'+str(mi.picturePath)+'/vp.small')
                               else:
                                   cl.sendImageWithURL(msg.to, 'http://dl.profile.line.naver.jp'+str(mi.picturePath))

                        elif text.lower() == "hapus chat":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               try:
                                   cl.removeAllMessages(op.param2)
                               except:
                                   pass

                        elif text.lower() == "remove chat":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               try:
                                   cl.removeAllMessages(op.param2)
                                   ki.removeAllMessages(op.param2)
                                   kk.removeAllMessages(op.param2)
                                   kc.removeAllMessages(op.param2)
                                   km.removeAllMessages(op.param2)
                                   kb.removeAllMessages(op.param2)
                                   kn.removeAllMessages(op.param2)
                                   ko.removeAllMessages(op.param2)
                                   kw.removeAllMessages(op.param2)
                                   ke.removeAllMessages(op.param2)
                                   ky.removeAllMessages(op.param2)
                                   cl.sendMessage(msg.to,"All Chat Clear...")
                                   ki.sendMessage(msg.to,"All Chat Clear...")
                                   kk.sendMessage(msg.to,"All Chat Clear...")
                                   kc.sendMessage(msg.to,"All Chat Clear...")
                                   km.sendMessage(msg.to,"All Chat Clear...")
                                   kb.sendMessage(msg.to,"All Chat Clear...")
                                   kn.sendMessage(msg.to,"All Chat Clear...")
                                   ko.sendMessage(msg.to,"All Chat Clear...")
                                   kw.sendMessage(msg.to,"All Chat Clear...")
                                   ke.sendMessage(msg.to,"All Chat Clear...")
                                   ky.sendMessage(msg.to,"All Chat Clear...")
                               except:
                                   pass

                        elif cmd.startswith("broadcast: "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               sep = text.split(" ")
                               pesan = text.replace(sep[0] + " ","")
                               saya = cl.getGroupIdsJoined()
                               for group in saya:
                                   cl.sendMessage(group,"[ Broadcast ]\n" + str(pesan))

                        elif cmd.startswith("inviteme"):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               saya = cl.getGroupIdsJoined()
                               for group in saya:
                                   cl.inviteIntoGroup(group,["mid"])

                        elif text.lower() == "mykey":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               cl.sendMessage(msg.to, "「Mykey」\nSetkey bot mu「 " + str(Setmain["keyCommand"]) + " 」")

                        elif cmd.startswith("setkey "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   cl.sendMessage(msg.to, "Gagal mengganti key")
                               else:
                                   Setmain["keyCommand"] = str(key).lower()
                                   cl.sendMessage(msg.to, "「Setkey」\nSetkey diganti jadi「{}」".format(str(key).lower()))

                        elif text.lower() == "resetkey":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               Setmain["keyCommand"] = ""
                               cl.sendMessage(msg.to, "「Setkey」\nSetkey mu kembali ke awal")

                        elif cmd == "restart":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               cl.sendMessage(msg.to, "Tunggu sebentar...")
                               Setmain["restartPoint"] = msg.to
                               restartBot()
                               cl.sendMessage(msg.to, "Silahkan gunakan seperti semula...")

                        elif cmd == "runtime":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               eltime = time.time() - mulai
                               bot = "Aktif " +waktu(eltime)
                               cl.sendMessage(msg.to,bot)

                        elif cmd == "ginfo":
                          if msg._from in admin:
                            try:
                                G = cl.getGroup(msg.to)
                                if G.invitee is None:
                                    gPending = "0"
                                else:
                                    gPending = str(len(G.invitee))
                                if G.preventedJoinByTicket == True:
                                    gQr = "Tertutup"
                                    gTicket = "Tidak ada"
                                else:
                                    gQr = "Terbuka"
                                    gTicket = "https://line.me/R/ti/g/{}".format(str(cl.reissueGroupTicket(G.id)))
                                timeCreated = []
                                timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(G.createdTime) / 1000)))
                                cl.sendMessage(msg.to, "Grup Info\n\n❧Nama Group : {}".format(G.name)+ "\n❧ID Group : {}".format(G.id)+ "\n❧Pembuat : {}".format(G.creator.displayName)+ "\n❧Waktu Dibuat : {}".format(str(timeCreated))+ "\n❧Jumlah Member : {}".format(str(len(G.members)))+ "\n❧Jumlah Pending : {}".format(gPending)+ "\n❧Group Qr : {}".format(gQr)+ "\n❧Group Ticket : {}".format(gTicket))
                                cl.sendMessage(msg.to, None, contentMetadata={'mid': G.creator.mid}, contentType=13)
                                cl.sendImageWithURL(msg.to, 'http://dl.profile.line-cdn.net/'+G.pictureStatus)
                            except Exception as e:
                                cl.sendMessage(msg.to, str(e))

                        elif cmd.startswith("infogrup "):
                          if msg._from in admin:
                            separate = text.split(" ")
                            number = text.replace(separate[0] + " ","")
                            groups = cl.getGroupIdsJoined()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = cl.getGroup(group)
                                try:
                                    gCreator = G.creator.displayName
                                except:
                                    gCreator = "Tidak ditemukan"
                                if G.invitee is None:
                                    gPending = "0"
                                else:
                                    gPending = str(len(G.invitee))
                                if G.preventedJoinByTicket == True:
                                    gQr = "Tertutup"
                                    gTicket = "Tidak ada"
                                else:
                                    gQr = "Terbuka"
                                    gTicket = "https://line.me/R/ti/g/{}".format(str(cl.reissueGroupTicket(G.id)))
                                timeCreated = []
                                timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(G.createdTime) / 1000)))
                                ret_ += "❧Info Grup\n"
                                ret_ += "\n❧Nama Group : {}".format(G.name)
                                ret_ += "\n❧ID Group : {}".format(G.id)
                                ret_ += "\n❧Pembuat : {}".format(gCreator)
                                ret_ += "\n❧Waktu Dibuat : {}".format(str(timeCreated))
                                ret_ += "\n❧Jumlah Member : {}".format(str(len(G.members)))
                                ret_ += "\n❧Jumlah Pending : {}".format(gPending)
                                ret_ += "\n❧Group Qr : {}".format(gQr)
                                ret_ += "\n❧Group Ticket : {}".format(gTicket)
                                ret_ += ""
                                cl.sendMessage(to, str(ret_))
                            except:
                                pass

                        elif cmd.startswith("infomem "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            number = msg.text.replace(separate[0] + " ","")
                            groups = cl.getGroupIdsJoined()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = cl.getGroup(group)
                                no = 0
                                ret_ = ""
                                for mem in G.members:
                                    no += 1
                                    ret_ += "\n " "❧"+ str(no) + ". " + mem.displayName
                                cl.sendMessage(to,"❧Group Name : [ " + str(G.name) + " ]\n\n   [ List Member ]\n" + ret_ + "\n\n「Total %i Members」" % len(G.members))
                            except:
                                pass

                        elif cmd == "myfriend":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = cl.getAllContactIds()
                               for i in gid:
                                   G = cl.getContact(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠ " + str(a) + ". " +G.displayName+ "\n"
                               cl.sendMessage(msg.to,"╔══[ FRIEND LIST ]\n║\n"+ma+"║\n╚══[ Total「"+str(len(gid))+"」Friends ]")

                        elif cmd == "myfriend1":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = ki.getAllContactIds()
                               for i in gid:
                                   G = ki.getContact(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠ " + str(a) + ". " +G.displayName+ "\n"
                               ki.sendMessage(msg.to,"╔══[ FRIEND LIST ]\n║\n"+ma+"║\n╚══[ Total「"+str(len(gid))+"」Friends ]")

                        elif cmd == "myfriend2":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = kk.getAllContactIds()
                               for i in gid:
                                   G = kk.getContact(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠ " + str(a) + ". " +G.displayName+ "\n"
                               kk.sendMessage(msg.to,"╔══[ FRIEND LIST ]\n║\n"+ma+"║\n╚══[ Total「"+str(len(gid))+"」Friends ]")

                        elif cmd == "myfriend3":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = kc.getAllContactIds()
                               for i in gid:
                                   G = kc.getContact(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠ " + str(a) + ". " +G.displayName+ "\n"
                               kc.sendMessage(msg.to,"╔══[ FRIEND LIST ]\n║\n"+ma+"║\n╚══[ Total「"+str(len(gid))+"」Friends ]")

                        elif cmd == "myfriend4":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = km.getAllContactIds()
                               for i in gid:
                                   G = km.getContact(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠ " + str(a) + ". " +G.displayName+ "\n"
                               km.sendMessage(msg.to,"╔══[ FRIEND LIST ]\n║\n"+ma+"║\n╚══[ Total「"+str(len(gid))+"」Friends ]")

                        elif cmd == "myfriend5":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = kb.getAllContactIds()
                               for i in gid:
                                   G = kb.getContact(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠ " + str(a) + ". " +G.displayName+ "\n"
                               kb.sendMessage(msg.to,"╔══[ FRIEND LIST ]\n║\n"+ma+"║\n╚══[ Total「"+str(len(gid))+"」Friends ]")

                        elif cmd == "myfriend6":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = kn.getAllContactIds()
                               for i in gid:
                                   G = kn.getContact(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠ " + str(a) + ". " +G.displayName+ "\n"
                               kn.sendMessage(msg.to,"╔══[ FRIEND LIST ]\n║\n"+ma+"║\n╚══[ Total「"+str(len(gid))+"」Friends ]")

                        elif cmd == "myfriend7":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = ko.getAllContactIds()
                               for i in gid:
                                   G = ko.getContact(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠ " + str(a) + ". " +G.displayName+ "\n"
                               ko.sendMessage(msg.to,"╔══[ FRIEND LIST ]\n║\n"+ma+"║\n╚══[ Total「"+str(len(gid))+"」Friends ]")

                        elif cmd == "myfriend8":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = kw.getAllContactIds()
                               for i in gid:
                                   G = kw.getContact(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠ " + str(a) + ". " +G.displayName+ "\n"
                               kw.sendMessage(msg.to,"╔══[ FRIEND LIST ]\n║\n"+ma+"║\n╚══[ Total「"+str(len(gid))+"」Friends ]")

                        elif cmd == "myfriend9":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = ke.getAllContactIds()
                               for i in gid:
                                   G = ke.getContact(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠ " + str(a) + ". " +G.displayName+ "\n"
                               ke.sendMessage(msg.to,"╔══[ FRIEND LIST ]\n║\n"+ma+"║\n╚══[ Total「"+str(len(gid))+"」Friends ]")

                        elif cmd == "myfriend10":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = ky.getAllContactIds()
                               for i in gid:
                                   G = ky.getContact(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠ " + str(a) + ". " +G.displayName+ "\n"
                               ky.sendMessage(msg.to,"╔══[ FRIEND LIST ]\n║\n"+ma+"║\n╚══[ Total「"+str(len(gid))+"」Friends ]")

                        elif cmd == "gruplist":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = cl.getGroupIdsJoined()
                               for i in gid:
                                   G = cl.getGroup(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠ " + str(a) + ". " +G.name+ "\n"
                               cl.sendMessage(msg.to,"╔══[ GROUP LIST ]\n║\n"+ma+"║\n╚══[ Total「"+str(len(gid))+"」Groups ]")

                        elif cmd == "open":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                if msg.toType == 2:
                                   X = cl.getGroup(msg.to)
                                   X.preventedJoinByTicket = False
                                   cl.updateGroup(X)
                                   cl.sendMessage(msg.to, "Url Opened")

                        elif cmd == "close":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                if msg.toType == 2:
                                   X = cl.getGroup(msg.to)
                                   X.preventedJoinByTicket = True
                                   cl.updateGroup(X)
                                   cl.sendMessage(msg.to, "Url Closed")

                        elif cmd == "url grup":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                if msg.toType == 2:
                                   x = cl.getGroup(msg.to)
                                   if x.preventedJoinByTicket == True:
                                      x.preventedJoinByTicket = False
                                      cl.updateGroup(x)
                                   gurl = cl.reissueGroupTicket(msg.to)
                                   cl.sendMessage(msg.to, "Nama : "+str(x.name)+ "\nUrl grup : http://line.me/R/ti/g/"+gurl)

#===========BOT UPDATE============#
                        elif cmd == "updategrup":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if msg.toType == 2:
                                settings["groupPicture"] = True
                                cl.sendMessage(msg.to,"Kirim fotonya.....")

                        elif cmd == "updatebot":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                settings["changePicture"] = True
                                ki.sendMessage(msg.to,"please send new photo.....")
                                kk.sendMessage(msg.to,"please send new photo.....")
                                kc.sendMessage(msg.to,"please send new photo.....")
                                km.sendMessage(msg.to,"please send new photo.....")
                                kb.sendMessage(msg.to,"please send new photo.....")
                                kn.sendMessage(msg.to,"please send new photo.....")
                                ko.sendMessage(msg.to,"please send new photo.....")
                                kw.sendMessage(msg.to,"please send new photo.....")
                                ke.sendMessage(msg.to,"please send new photo.....")
                                ky.sendMessage(msg.to,"please send new photo.....")

                        elif cmd == "updatefoto":
                            if msg._from in admin:
                                Setmain["ARfoto"][selfmid] = True
                                cl.sendMessage(msg.to,"please send new photo.....")

                        elif cmd == "bot1up":
                            if msg._from in admin:
                                Setmain["ARfoto"][Amid] = True
                                ki.sendMessage(msg.to,"please send new photo.....")

                        elif cmd == "bot2up":
                            if msg._from in admin:
                                Setmain["ARfoto"][Bmid] = True
                                kk.sendMessage(msg.to,"please send new photo.....")

                        elif cmd == "bot3up":
                            if msg._from in admin:
                                Setmain["ARfoto"][Cmid] = True
                                kc.sendMessage(msg.to,"please send new photo.....")

                        elif cmd == "bot4up":
                            if msg._from in admin:
                                Setmain["ARfoto"][Dmid] = True
                                km.sendMessage(msg.to,"please send new photo.....")

                        elif cmd == "bot5up":
                            if msg._from in admin:
                                Setmain["ARfoto"][Emid] = True
                                kb.sendMessage(msg.to,"please send new photo.....")

                        elif cmd == "bot6up":
                            if msg._from in admin:
                                Setmain["ARfoto"][Fmid] = True
                                kn.sendMessage(msg.to,"please send new photo.....")

                        elif cmd == "bot7up":
                            if msg._from in admin:
                                Setmain["ARfoto"][Gmid] = True
                                ko.sendMessage(msg.to,"please send new photo.....")

                        elif cmd == "bot8up":
                            if msg._from in admin:
                                Setmain["ARfoto"][Hmid] = True
                                kw.sendMessage(msg.to,"please send new photo.....")

                        elif cmd == "bot9up":
                            if msg._from in admin:
                                Setmain["ARfoto"][Imid] = True
                                ke.sendMessage(msg.to,"please send new photo.....")

                        elif cmd == "bot10up":
                            if msg._from in admin:
                                Setmain["ARfoto"][Jmid] = True
                                ky.sendMessage(msg.to,"please send new photo.....")

                        elif cmd == "jsup":
                            if msg._from in admin:
                                Setmain["ARfoto"][Xmid] = True
                                aj.sendMessage(msg.to,"please send new photo.....")

                        elif cmd == "ghostup":
                            if msg._from in admin:
                                Setmain["ARfoto"][Zmid] = True
                                sw.sendMessage(msg.to,"please send new photo.....")

                        elif cmd.startswith("myname: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = cl.getProfile()
                                profile.displayName = string
                                cl.updateProfile(profile)
                                cl.sendMessage(msg.to,"Name change to " + string + "")

                        elif cmd.startswith("bot1name: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = ki.getProfile()
                                profile.displayName = string
                                ki.updateProfile(profile)
                                ki.sendMessage(msg.to,"Name change to " + string + "")

                        elif cmd.startswith("bot2name: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = kk.getProfile()
                                profile.displayName = string
                                kk.updateProfile(profile)
                                kk.sendMessage(msg.to,"Name change to " + string + "")

                        elif cmd.startswith("bot3name: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = kc.getProfile()
                                profile.displayName = string
                                kc.updateProfile(profile)
                                kc.sendMessage(msg.to,"Name change to " + string + "")

                        elif cmd.startswith("bot4name: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = km.getProfile()
                                profile.displayName = string
                                km.updateProfile(profile)
                                km.sendMessage(msg.to,"Name change to " + string + "")

                        elif cmd.startswith("bot5name: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = kb.getProfile()
                                profile.displayName = string
                                kb.updateProfile(profile)
                                kb.sendMessage(msg.to,"Name change to " + string + "")

                        elif cmd.startswith("bot6name: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = kn.getProfile()
                                profile.displayName = string
                                kn.updateProfile(profile)
                                kn.sendMessage(msg.to,"Name change to " + string + "")

                        elif cmd.startswith("bot7name: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = ko.getProfile()
                                profile.displayName = string
                                ko.updateProfile(profile)
                                ko.sendMessage(msg.to,"Name change to " + string + "")

                        elif cmd.startswith("bot8name: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = kw.getProfile()
                                profile.displayName = string
                                kw.updateProfile(profile)
                                kw.sendMessage(msg.to,"Name change to " + string + "")

                        elif cmd.startswith("bot9name: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = ke.getProfile()
                                profile.displayName = string
                                ke.updateProfile(profile)
                                ke.sendMessage(msg.to,"Name change to " + string + "")

                        elif cmd.startswith("bot10name: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = ky.getProfile()
                                profile.displayName = string
                                ky.updateProfile(profile)
                                ky.sendMessage(msg.to,"Name change to " + string + "")

                        elif cmd.startswith("jsname: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = aj.getProfile()
                                profile.displayName = string
                                aj.updateProfile(profile)
                                aj.sendMessage(msg.to,"Name change to " + string + "")

                        elif cmd.startswith("ghostname: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = sw.getProfile()
                                profile.displayName = string
                                sw.updateProfile(profile)
                                sw.sendMessage(msg.to,"Name change to " + string + "")

#===========BOT UPDATE============#
                        elif msg.text in ["sayang","clbk","cinta","cipok"]:
                               if wait["selfbot"] == True:
                                if msg._from in admin:
                                 group = cl.getGroup(msg.to)
                                nama = [contact.mid for contact in group.members]
                                k = len(nama)//20
                                for a in range(k+1):
                                    txt = u''
                                    s=0
                                    b=[]
                                    for i in group.members[a*20 : (a+1)*20]:
                                        b.append({"S":str(s), "E" :str(s+6), "M":i.mid})
                                        s += 7
                                        txt += u'@Zero \n'
                                    cl.sendMessage(msg.to, text=txt, contentMetadata={u'MENTION': json.dumps({'MENTIONEES':b})}, contentType=0)

                        elif cmd == "listbot":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                ma = ""
                                a = 0
                                for m_id in Bots:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +cl.getContact(m_id).displayName + "\n"
                                cl.sendMessage(msg.to,"❧﴾ sᴀмuᴅʀᴀ____ʙoтs ﴿\n\n"+ma+"\nTotal「%s」 Bots" %(str(len(Bots))))

                        elif cmd == "adminlist":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                ma = ""
                                mb = ""
                                mc = ""
                                a = 0
                                b = 0
                                c = 0
                                for m_id in owner:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +cl.getContact(m_id).displayName + "\n"
                                for m_id in admin:
                                    b = b + 1
                                    end = '\n'
                                    mb += str(b) + ". " +cl.getContact(m_id).displayName + "\n"
                                for m_id in famzadmin["staff"]:
                                    c = c + 1
                                    end = '\n'
                                    mc += str(c) + ". " +cl.getContact(m_id).displayName + "\n"
                                cl.sendMessage(msg.to,"♻﴾ ᴅᴀғтᴀʀ ᴀᴅмιɴ ﴿♻ \n\nSuper admin: Samudra\nAdmin:\n"+mb+"\nStaff:\n"+mc+"\nTotal「%s」 Anggota" %(str(len(owner)+len(admin)+len(staff))))

                        elif cmd == "listprotect":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                ma = ""
                                mb = ""
                                mc = ""
                                md = ""
                                me = ""
                                mf = ""
                                a = 0
                                gid = protectqr
                                for group in gid:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +cl.getGroup(group).name + "\n"
                                gid = protectkick
                                for group in gid:
                                    a = a + 1
                                    end = '\n'
                                    mb += str(a) + ". " +cl.getGroup(group).name + "\n"
                                gid = protectjoin
                                for group in gid:
                                    a = a + 1
                                    end = '\n'
                                    md += str(a) + ". " +cl.getGroup(group).name + "\n"
                                gid = protectcancel
                                for group in gid:
                                    a = a + 1
                                    end = '\n'
                                    mc += str(a) + ". " +cl.getGroup(group).name + "\n"
                                gid = protectinvite
                                for group in gid:
                                    a = a + 1
                                    end = '\n'
                                    me += str(a) + ". " +cl.getGroup(group).name + "\n"
                                gid = protectantijs
                                for group in gid:
                                    a = a + 1
                                    end = '\n'
                                    mf += str(a) + ". " +cl.getGroup(group).name + "\n"
                                cl.sendMessage(msg.to,"「♻﴾ sᴀмuᴅʀᴀ ᴘʀoтᴇcтιoɴ ﴿♻」\n\n「✭」 PROTECT URL :\n"+ma+"\n「✭」 PROTECT KICK :\n"+mb+"\n「✭」 PROTECT JOIN :\n"+md+"\n「✭」 PROTECT CANCEL:\n"+mc+"\n「✭」 PROTECT INVITE:\n"+me+"\n「✭」 PROTECT ANTIJS :\n"+mf+"\nTotal「%s」Grup diamankan" %(str(len(protectqr)+len(protectkick)+len(protectjoin)+len(protectcancel)+len(protectinvite)+len(protectantijs))))

                        elif cmd == "absen" or cmd == "respon":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["qr"] = False
                                wait["inv"] = False
                                ki.sendMessage(msg.to, "We Are Famz ...! ")
                                kk.sendMessage(msg.to, "We Are Famz ...! ")
                                kc.sendMessage(msg.to, "We Are Famz ...! ")
                                km.sendMessage(msg.to, "We Are Famz ...! ")
                                kb.sendMessage(msg.to, "We Are Famz ...! ")
                                kn.sendMessage(msg.to, "We Are Famz ...! ")
                                ko.sendMessage(msg.to, "We Are Famz ...! ")
                                kw.sendMessage(msg.to, "We Are Famz ...! ")
                                ke.sendMessage(msg.to, "We Are Famz ...! ")
                                ky.sendMessage(msg.to, "We Are Famz ...! ")

                        elif cmd == "jsabsen" or cmd == "jsrespon":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["qr"] = False
                                aj.sendMessage(msg.to, "oit broo aim ada kok ...! ")
                                sw.sendMessage(msg.to, "oit broo aim ada kok ...! ")


                        elif cmd == "invite":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                try:
                                    anggota = [Amid,Bmid,Cmid,Dmid,Emid,Fmid,Gmid,Hmid,Imid,Jmid,Xmid,Zmid]
                                    cl.inviteIntoGroup(msg.to, anggota)
                                    ki.acceptGroupInvitation(msg.to)
                                    kk.acceptGroupInvitation(msg.to)
                                    kc.acceptGroupInvitation(msg.to)
                                    km.acceptGroupInvitation(msg.to)
                                    kb.acceptGroupInvitation(msg.to)
                                    kn.acceptGroupInvitation(msg.to)
                                    ko.acceptGroupInvitation(msg.to)
                                    kw.acceptGroupInvitation(msg.to)
                                    ke.acceptGroupInvitation(msg.to)
                                    ky.acceptGroupInvitation(msg.to)
                                except:
                                    pass

                        elif cmd == "stay":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                try:
                                    cl.findAndAddContactsByMid(Xmid)
                                    cl.findAndAddContactsByMid(Zmid)
                                    cl.inviteIntoGroup(msg.to, [Xmid,Zmid])
                                    cl.sendMessage(msg.to,"Grup 「"+str(ginfo.name)+"」 save")
                                except:
                                    pass

                        elif cmd == "in":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                G = cl.getGroup(msg.to)
                                ginfo = cl.getGroup(msg.to)
                                G.preventedJoinByTicket = False
                                cl.updateGroup(G)
                                Ticket = cl.reissueGroupTicket(msg.to)
                                ki.acceptGroupInvitationByTicket(msg.to,Ticket)
                                kk.acceptGroupInvitationByTicket(msg.to,Ticket)
                                kc.acceptGroupInvitationByTicket(msg.to,Ticket)
                                km.acceptGroupInvitationByTicket(msg.to,Ticket)
                                kb.acceptGroupInvitationByTicket(msg.to,Ticket)
                                kn.acceptGroupInvitationByTicket(msg.to,Ticket)
                                ko.acceptGroupInvitationByTicket(msg.to,Ticket)
                                kw.acceptGroupInvitationByTicket(msg.to,Ticket)
                                ke.acceptGroupInvitationByTicket(msg.to,Ticket)
                                ky.acceptGroupInvitationByTicket(msg.to,Ticket)
                                G = ky.getGroup(msg.to)
                                G.preventedJoinByTicket = True
                                ky.updateGroup(G)
                                ginfo = cl.getGroup(msg.to)
                                cl.inviteIntoGroup(msg.to, [Xmid,Zmid])

                        elif cmd == "out":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                G = cl.getGroup(msg.to)
                                cl.cancelGroupInvitation(msg.to, [Xmid])
                                cl.cancelGroupInvitation(msg.to, [Zmid])
                                ki.leaveGroup(msg.to)
                                kk.leaveGroup(msg.to)
                                kc.leaveGroup(msg.to)
                                km.leaveGroup(msg.to)
                                kb.leaveGroup(msg.to)
                                kn.leaveGroup(msg.to)
                                ko.leaveGroup(msg.to)
                                kw.leaveGroup(msg.to)
                                ke.leaveGroup(msg.to)
                                ky.leaveGroup(msg.to)


                        elif cmd == "byeme":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                G = cl.getGroup(msg.to)
                                cl.leaveGroup(msg.to)

                        elif cmd == "leaveall":
                            if msg._from in admin:
                                gid = random.choice(KAC).getGroupIdsJoined()
                                for i in gid:
                                    cl.sendMessage(i, "please contact my creator")
                                    cl.leaveGroup(i)
                                    ki.leaveGroup(i)
                                    kk.leaveGroup(i)
                                    kc.leaveGroup(i)
                                    km.leaveGroup(i)
                                    kb.leaveGroup(i)
                                    kn.leaveGroup(i)
                                    ko.leaveGroup(i)
                                    kw.leaveGroup(i)
                                    ke.leaveGroup(i)
                                    ky.leaveGroup(i)

                        elif cmd == "js in":
                            if msg._from in admin:
                                G = cl.getGroup(msg.to)
                                ginfo = cl.getGroup(msg.to)
                                G.preventedJoinByTicket = False
                                cl.updateGroup(G)
                                invsend = 0
                                Ticket = cl.reissueGroupTicket(msg.to)
                                aj.acceptGroupInvitationByTicket(msg.to,Ticket)
                                sw.acceptGroupInvitationByTicket(msg.to,Ticket)
                                G = sw.getGroup(msg.to)
                                G.preventedJoinByTicket = True
                                sw.updateGroup(G)

                        elif cmd == "js out":
                            if msg._from in admin:
                                aj.leaveGroup(msg.to)
                                sw.leaveGroup(msg.to)

                        elif cmd == "sprespon":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                get_profile_time_start = time.time()
                                get_profile = cl.getProfile()
                                get_profile_time = time.time() - get_profile_time_start
                                get_group_time_start = time.time()
                                get_group = cl.getGroupIdsJoined()
                                get_group_time = time.time() - get_group_time_start
                                get_contact_time_start = time.time()
                                get_contact = cl.getContact(selfmid)
                                get_contact_time = time.time() - get_contact_time_start
                                cl.sendMessage(msg.to, "❧﴾ sᴀмuᴅʀᴀ____ʙoтs ﴿ Speed respon\n\n - Get Profile\n   %.10f\n - Get Contact\n   %.10f\n - Get Group\n   %.10f" % (get_profile_time/3,get_contact_time/3,get_group_time/3))

                        elif cmd == "mysp" or cmd == "myspeed":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               get_group_time_start = time.time()
                               get_group = cl.getGroupIdsJoined()
                               get_group_time = time.time() - get_group_time_start
                               cl.sendMessage(msg.to, "%s secc" % (get_group_time))

                        elif cmd == "sp" or cmd == "sp":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               get_group_time_start = time.time()
                               get_group = ki.getGroupIdsJoined()
                               get_group_time = time.time() - get_group_time_start
                               ki.sendMessage(msg.to, "%s secc" % (get_group_time))
                               get_group_time_start = time.time()
                               get_group = kk.getGroupIdsJoined()
                               get_group_time = time.time() - get_group_time_start
                               kk.sendMessage(msg.to, "%s secc" % (get_group_time))
                               get_group_time_start = time.time()
                               get_group = kc.getGroupIdsJoined()
                               get_group_time = time.time() - get_group_time_start
                               kc.sendMessage(msg.to, "%s secc" % (get_group_time))
                               get_group_time_start = time.time()
                               get_group = km.getGroupIdsJoined()
                               get_group_time = time.time() - get_group_time_start
                               km.sendMessage(msg.to, "%s secc" % (get_group_time))
                               get_group_time_start = time.time()
                               get_group = kb.getGroupIdsJoined()
                               get_group_time = time.time() - get_group_time_start
                               kb.sendMessage(msg.to, "%s secc" % (get_group_time))
                               get_group_time_start = time.time()
                               get_group = kn.getGroupIdsJoined()
                               get_group_time = time.time() - get_group_time_start
                               kn.sendMessage(msg.to, "%s secc" % (get_group_time))
                               get_group_time_start = time.time()
                               get_group = ko.getGroupIdsJoined()
                               get_group_time = time.time() - get_group_time_start
                               ko.sendMessage(msg.to, "%s secc" % (get_group_time))
                               get_group_time_start = time.time()
                               get_group = kw.getGroupIdsJoined()
                               get_group_time = time.time() - get_group_time_start
                               kw.sendMessage(msg.to, "%s secc" % (get_group_time))
                               get_group_time_start = time.time()
                               get_group = ke.getGroupIdsJoined()
                               get_group_time = time.time() - get_group_time_start
                               ke.sendMessage(msg.to, "%s secc" % (get_group_time))
                               get_group_time_start = time.time()
                               get_group = ky.getGroupIdsJoined()
                               get_group_time = time.time() - get_group_time_start
                               ky.sendMessage(msg.to, "%s secc" % (get_group_time))

                        elif cmd == "lurking on":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                 tz = pytz.timezone("Asia/Jakarta")
                                 timeNow = datetime.now(tz=tz)
                                 Setmain['ARreadPoint'][msg.to] = msg_id
                                 Setmain['ARreadMember'][msg.to] = {}
                                 cl.sendText(msg.to, "Lurking berhasil diaktifkan\n\nTanggal : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nJam [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]")

                        elif cmd == "lurking off":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                 tz = pytz.timezone("Asia/Jakarta")
                                 timeNow = datetime.now(tz=tz)
                                 del Setmain['ARreadPoint'][msg.to]
                                 del Setmain['ARreadMember'][msg.to]
                                 cl.sendMessage(msg.to, "Lurking berhasil dinoaktifkan\n\nTanggal : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nJam [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]")

                        elif cmd == "lurkers":
                          if msg._from in admin:
                            if msg.to in Setmain['ARreadPoint']:
                                if Setmain['ARreadMember'][msg.to] != {}:
                                    aa = []
                                    for x in Setmain['ARreadMember'][msg.to]:
                                        aa.append(x)
                                    try:
                                        arrData = ""
                                        textx = "  [ Result {} member ]    \n\n  [ Lurkers ]\n1. ".format(str(len(aa)))
                                        arr = []
                                        no = 1
                                        b = 1
                                        for i in aa:
                                            b = b + 1
                                            end = "\n"
                                            mention = "@x\n"
                                            slen = str(len(textx))
                                            elen = str(len(textx) + len(mention) - 1)
                                            arrData = {'S':slen, 'E':elen, 'M':i}
                                            arr.append(arrData)
                                            tz = pytz.timezone("Asia/Jakarta")
                                            timeNow = datetime.now(tz=tz)
                                            textx += mention
                                            if no < len(aa):
                                                no += 1
                                                textx += str(b) + ". "
                                            else:
                                                try:
                                                    no = "[ {} ]".format(str(cl.getGroup(msg.to).name))
                                                except:
                                                    no = "  "
                                        msg.to = msg.to
                                        msg.text = textx+"\nTanggal : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nJam [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]"
                                        msg.contentMetadata = {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}
                                        msg.contentType = 0
                                        cl.sendMessage1(msg)
                                    except:
                                        pass
                                    try:
                                        del Setmain['ARreadPoint'][msg.to]
                                        del Setmain['ARreadMember'][msg.to]
                                    except:
                                        pass
                                    Setmain['ARreadPoint'][msg.to] = msg.id
                                    Setmain['ARreadMember'][msg.to] = {}
                                else:
                                    cl.sendText(msg.to, "User kosong...")
                            else:
                                cl.sendText(msg.to, "Ketik lurking on dulu")

                        elif cmd == "ciluk ba":
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                              try:
                                  tz = pytz.timezone("Asia/Jakarta")
                                  timeNow = datetime.now(tz=tz)
                                  cl.sendMessage(msg.to, "sider actif\n\ndate : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nclock [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]")
                                  del cctv['point'][msg.to]
                                  del cctv['sidermem'][msg.to]
                                  del cctv['cyduk'][msg.to]
                              except:
                                  pass
                              cctv['point'][msg.to] = msg.id
                              cctv['sidermem'][msg.to] = ""
                              cctv['cyduk'][msg.to]=True

                        elif cmd == "colok ni":
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                              if msg.to in cctv['point']:
                                  tz = pytz.timezone("Asia/Jakarta")
                                  timeNow = datetime.now(tz=tz)
                                  cctv['cyduk'][msg.to]=False
                                  cl.sendMessage(msg.to, "sider not actif\n\ndate : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nclock [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]")
                              else:
                                  cl.sendMessage(msg.to, "not active")
#===========Hiburan============#
                        elif cmd.startswith("spamtag: "):
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                                proses = text.split(":")
                                strnum = text.replace(proses[0] + ":","")
                                num =  int(strnum)
                                Setmain["ARlimit"] = num
                                cl.sendMessage(msg.to,"now spamtag " +strnum)

                        elif cmd.startswith("spamcall: "):
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                                proses = text.split(":")
                                strnum = text.replace(proses[0] + ":","")
                                num =  int(strnum)
                                wait["limit"] = num
                                cl.sendMessage(msg.to,"now spamcall " +strnum)
#----Sticker--------------------------------------------------------------------
                        elif cmd.startswith("setsticker "):
                          if msg._from in admin:
                            sep = text.split(" ")
                            name = text.replace(sep[0] + " ","")
                            name = name.lower()
                            if name in barstick:
                                wait["setsticker"]["status"] = True
                                wait["setsticker"]["name"] = str(name.lower())
                                barstick[str(name.lower())] = ""
                                f = codecs.open('sticker4.json','w','utf-8')
                                json.dump(barstick, f, sort_keys=True, indent=4, ensure_ascii=False)
                                cl.sendMessage(to, "Silahkan kirim stiker yang ingin anda ubah")
                            else:
                                cl.sendMessage(to, "Stiker tidak ada dalam list")
#-------------------------------------------------------------------------------
                        elif cmd.startswith("spamtag "):
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                                if 'MENTION' in msg.contentMetadata.keys()!=None:
                                    key = eval(msg.contentMetadata["MENTION"])
                                    key1 = key["MENTIONEES"][0]["M"]
                                    zx = ""
                                    zxc = " "
                                    zx2 = []
                                    pesan2 = "@a"" "
                                    xlen = str(len(zxc))
                                    xlen2 = str(len(zxc)+len(pesan2)-1)
                                    zx = {'S':xlen, 'E':xlen2, 'M':key1}
                                    zx2.append(zx)
                                    zxc += pesan2
                                    msg.contentType = 0
                                    msg.text = zxc
                                    lol = {'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}
                                    msg.contentMetadata = lol
                                    jmlh = int(Setmain["ARlimit"])
                                    if jmlh <= 1000:
                                        for x in range(jmlh):
                                            try:
                                                cl.sendMessage(msg)
                                            except Exception as e:
                                                cl.sendMessage(msg.to,str(e))
                                    else:
                                        cl.sendMessage(msg.to,"Jumlah melebihi 1000")

                        elif cmd == "spamcall":
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                             if msg.toType == 2:
                                group = cl.getGroup(to)
                                members = [mem.mid for mem in group.members]
                                jmlh = int(wait["limit"])
                                cl.sendMessage(msg.to, "succes invite {} Call Grup".format(str(wait["limit"])))
                                if jmlh <= 1000:
                                  for x in range(jmlh):
                                     try:
                                        call.acquireGroupCallRoute(to)
                                        call.inviteIntoGroupCall(to, contactIds=members)
                                     except Exception as e:
                                        cl.sendMessage(msg.to,str(e))
                                else:
                                    cl.sendText(msg.to,"Jumlah melebihi batas")

                        elif 'Spam ' in msg.text:
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                              korban = msg.text.replace('Spam ','')
                              korban2 = korban.split()
                              midd = korban2[0]
                              jumlah = int(korban2[15])
                              if jumlah <= 1000:
                                  for var in range(0,jumlah):
                                      cl.sendMessage(midd, str(Setmain["ARmessage1"]))
                                      ki.sendMessage(midd, str(Setmain["ARmessage1"]))
                                      kk.sendMessage(midd, str(Setmain["ARmessage1"]))
                                      kc.sendMessage(midd, str(Setmain["ARmessage1"]))
                                      km.sendMessage(midd, str(Setmain["ARmessage1"]))
                                      kb.sendMessage(midd, str(Setmain["ARmessage1"]))
                                      kn.sendMessage(midd, str(Setmain["ARmessage1"]))

                        elif 'ID line: ' in msg.text:
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                              msgs = msg.text.replace('ID line: ','')
                              conn = cl.findContactsByUserid(msgs)
                              if True:
                                  cl.sendMessage(msg.to, "http://line.me/ti/p/~" + msgs)
                                  cl.sendMessage(msg.to, None, contentMetadata={'mid': conn.mid}, contentType=13)

#===========Protection============#
                        elif 'Welcome ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Welcome ','')
                              if spl == 'on':
                                  if msg.to in welcome:
                                       msgs = "Welcome Msg sudah aktif"
                                  else:
                                       welcome.append(msg.to)
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "Welcome Msg diaktifkan\nDi Group : " +str(ginfo.name)
                                  cl.sendMessage(msg.to, "「Diaktifkan」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in welcome:
                                         welcome.remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "Welcome Msg dinonaktifkan\nDi Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Welcome Msg sudah tidak aktif"
                                    cl.sendMessage(msg.to, "「Dinonaktifkan」\n" + msgs)

                        elif 'Protecturl ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Protecturl ','')
                              if spl == 'on':
                                  if msg.to in protectqr:
                                       msgs = "Protect url active"
                                  else:
                                       protectqr.append(msg.to)
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "Protect url active\nin Group : " +str(ginfo.name)
                                  cl.sendMessage(msg.to, "「active」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectqr:
                                         protectqr.remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "Protect url not active\nin Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Protect url not active"
                                    cl.sendMessage(msg.to, "「not active」\n" + msgs)

                        elif 'Protectkick ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Protectkick ','')
                              if spl == 'on':
                                  if msg.to in protectkick:
                                       msgs = "Protect kick active"
                                  else:
                                       protectkick.append(msg.to)
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "Protect kick active\nin Group : " +str(ginfo.name)
                                  cl.sendMessage(msg.to, "「active」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectkick:
                                         protectkick.remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "Protect kick not active\nin Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Protect kick not active"
                                    cl.sendMessage(msg.to, "「not active」\n" + msgs)

                        elif 'Protectinvite ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Protectinvite ','')
                              if spl == 'on':
                                  if msg.to in protectinvite:
                                       msgs = "Protect invite active"
                                  else:
                                       protectinvite.append(msg.to)
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "Protect invite active\nin Group : " +str(ginfo.name)
                                  cl.sendMessage(msg.to, "「active」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectinvite:
                                         protectinvite.remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "Protect invite not active\nin Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Protect invite not active"
                                    cl.sendMessage(msg.to, "「not active」\n" + msgs)

                        elif 'Protectjoin ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Protectjoin ','')
                              if spl == 'on':
                                  if msg.to in protectjoin:
                                       msgs = "Protect join active"
                                  else:
                                       protectjoin.append(msg.to)
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "Protect join active\nin Group : " +str(ginfo.name)
                                  cl.sendMessage(msg.to, "「active」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectjoin:
                                         protectjoin.remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "Protect join not active\nin Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Protect join not active"
                                    cl.sendMessage(msg.to, "「not active」\n" + msgs)

                        elif 'Protectcancel ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Protectcancel ','')
                              if spl == 'on':
                                  if msg.to in protectcancel:
                                       msgs = "Protect cancel active"
                                  else:
                                       protectcancel.append(msg.to)
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "Protect cancel active\nin Group : " +str(ginfo.name)
                                  cl.sendMessage(msg.to, "「active」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectcancel:
                                         protectcancel.remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "Protect cancel not active\nin Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Protect cancel not active"
                                    cl.sendMessage(msg.to, "「not active」\n" + msgs)

                        elif 'Antijs ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Antijs ','')
                              if spl == 'on':
                                  if msg.to in protectantijs:
                                       msgs = "Anti JS active"
                                  else:
                                       protectantijs.append(msg.to)
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "Anti JS active\nin Group : " +str(ginfo.name)
                                  cl.sendMessage(msg.to, "「active」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectantijs:
                                         protectantijs.remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "Anti JS not active\nin Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Anti JS not active"
                                    cl.sendMessage(msg.to, "「not active」\n" + msgs)

                        elif 'Allpro ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Allpro ','')
                              if spl == 'on':
                                #if wait["allprotect"] == True:
                                  if msg.to in protectqr:
                                       msgs = ""
                                  else:
                                       protectqr.append(msg.to)
                                  if msg.to in protectkick:
                                      msgs = ""
                                  else:
                                      protectkick.append(msg.to)
                                  if msg.to in protectinvite:
                                      msgs = ""
                                  else:
                                      protectinvite.append(msg.to)
                                  if msg.to in protectantijs:
                                      msgs = ""
                                  else:
                                      protectantijs.append(msg.to)
                                  if msg.to in protectcancel:
                                      ginfo = cl.getGroup(msg.to)
                                      msgs = "Status : [ ON ]\nin Group : " +str(ginfo.name)
                                      msgs += "\nAll protection active"
                                  else:
                                      protectcancel.append(msg.to)
                                      ginfo = cl.getGroup(msg.to)
                                      msgs = "Status : [ ON ]\nin Group : " +str(ginfo.name)
                                      msgs += "\nAll protection active"
                                  cl.sendMessage(msg.to, "「 Status Protection 」\n" + msgs)
                              elif spl == 'off':
                                 #if wait["allprotect"] == False:
                                    if msg.to in protectqr:
                                         protectqr.remove(msg.to)
                                    else:
                                         msgs = ""
                                    if msg.to in protectkick:
                                         protectkick.remove(msg.to)
                                    else:
                                         msgs = ""
                                    if msg.to in protectinvite:
                                         protectinvite.remove(msg.to)
                                    else:
                                         msgs = ""
                                    if msg.to in protectantijs:
                                         protectantijs.remove(msg.to)
                                    else:
                                         msgs = ""
                                    if msg.to in protectcancel:
                                         protectcancel.remove(msg.to)
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "Status : [ OFF ]\nin Group : " +str(ginfo.name)
                                         msgs += "\nAll protection not active"
                                    else:
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "Status : [ OFF ]\nin Group : " +str(ginfo.name)
                                         msgs += "\nAll protection not active"
                                    cl.sendMessage(msg.to, "「 Status Protection 」\n" + msgs)

#===========KICKOUT============#
                        elif ("Kick " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Bots:
                                       try:
                                           random.choice(ABC).kickoutFromGroup(msg.to, [target])
                                       except:
                                           pass

                        elif ("Vkick " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                nk0 = msg.text.replace("Vkick ","")
                                nk1 = nk0.lstrip()
                                nk2 = nk1.replace("@","")
                                nk3 = nk2.rstrip()
                                _name = nk3
                                gs = random.choice(ABC).getGroup(msg.to)
                                targets = []
                                for g in gs.members:
                                    if _name in g.displayName:
                                        targets.append(g.mid)
                                if targets == []:
                                    pass
                                else:
                                    for target in targets:
                                        if target in Bots and target in admin:
                                            pass
                                        else:
                                            try:
                                                wait["blacklist"][target] = True
                                                random.choice(ABC).kickoutFromGroup(msg.to,[target])
                                            except:
                                                pass

                        elif ("Nk " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                nk0 = msg.text.replace("Nk ","")
                                nk1 = nk0.lstrip()
                                nk2 = nk1.replace("@","")
                                nk3 = nk2.rstrip()
                                _name = nk3
                                gs = cl.getGroup(msg.to)
                                targets = []
                                for g in gs.members:
                                    if _name in g.displayName:
                                        targets.append(g.mid)
                                if targets == []:
                                    pass
                                else:
                                    for target in targets:
                                        if target in Bots and target in admin:
                                            pass
                                        else:
                                            try:
                                                G = cl.getGroup(msg.to)
                                                G.preventedJoinByTicket = False
                                                cl.updateGroup(G)
                                                Ticket = cl.reissueGroupTicket(msg.to)
                                                sw.acceptGroupInvitationByTicket(msg.to,Ticket)
                                                sw.kickoutFromGroup(msg.to,[target])
                                                sw.leaveGroup(msg.to)
                                                G = cl.getGroup(msg.to)
                                                G.preventedJoinByTicket = True
                                                cl.updateGroup(G)
                                                cl.inviteIntoGroup(msg.to,[Zmid])
                                            except:
                                                pass

                        elif cmd == "clean" or text.lower() == 'clean':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                group = random.choice(ABC).getGroup(msg.to)
                                prabowo = [contact.mid for contact in group.invitee]
                                jokowi = [contact.mid for contact in group.members]
                                for kampret in prabowo:
                                    if kampret not in Bots and kampret not in owner and kampret not in admin and kampret not in staff:
                                        try:
                                            klist = [ki,kk,kc,km,kb,kn,ko,kw,ke,ky]
                                            samudra = random.choice(klist)
                                            samudra.getContact(kampret).mid
                                            samudra.cancelGroupInvitation(msg.to, [kampret])
                                        except:
                                            pass
                                for cebong in jokowi:
                                    if cebong not in Bots and cebong not in owner and cebong not in admin and cebong not in staff:
                                        try:
                                            klist = [ki,kk,kc,km,kb,kn,ko,kw,ke,ky]
                                            samudra = random.choice(klist)
                                            samudra.getContact(cebong).mid
                                            samudra.kickoutFromGroup(msg.to, [cebong])
                                        except:
                                            pass

                        elif cmd == "cancelall" or text.lower() == 'cancelall':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                group = random.choice(ABC).getGroup(msg.to)
                                prabowo = [contact.mid for contact in group.invitee]
                                for kampret in prabowo:
                                    if kampret not in Bots and kampret not in owner and kampret not in admin and kampret not in staff:
                                        try:
                                            klist = [ki,kk,kc,km,kb,kn,ko,kw,ke,ky]
                                            samudra = random.choice(klist)
                                            samudra.getContact(kampret).mid
                                            samudra.cancelGroupInvitation(msg.to, [kampret])
                                        except:
                                            pass
#===========ADMIN ADD============#
                        elif ("Addfriend " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           cl.findAndAddContactsByMid(target)
                                           ki.findAndAddContactsByMid(target)
                                           kk.findAndAddContactsByMid(target)
                                           kc.findAndAddContactsByMid(target)
                                           km.findAndAddContactsByMid(target)
                                           kb.findAndAddContactsByMid(target)
                                           kn.findAndAddContactsByMid(target)
                                           ko.findAndAddContactsByMid(target)
                                           kw.findAndAddContactsByMid(target)
                                           ke.findAndAddContactsByMid(target)
                                           ky.findAndAddContactsByMid(target)
                                           cl.sendMessage(msg.to,"succes add friend")
                                           ki.sendMessage(msg.to,"succes add friend")
                                           kk.sendMessage(msg.to,"succes add friend")
                                           kc.sendMessage(msg.to,"succes add friend")
                                           km.sendMessage(msg.to,"succes add friend")
                                           kb.sendMessage(msg.to,"succes add friend")
                                           kn.sendMessage(msg.to,"succes add friend")
                                           ko.sendMessage(msg.to,"succes add friend")
                                           kw.sendMessage(msg.to,"succes add friend")
                                           ke.sendMessage(msg.to,"succes add friend")
                                           ky.sendMessage(msg.to,"succes add friend")
                                       except:
                                           pass

                        elif ("Adminadd " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           admin.append(target)
                                           cl.sendMessage(msg.to,"succes add admin")
                                       except:
                                           pass

                        elif ("Staffadd " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           famzadmin["staff"][target] = True
                                           f=codecs.open('samudraadmin.json','w','utf-8')
                                           json.dump(famzadmin, f, sort_keys=True, indent=4,ensure_ascii=False)
                                           cl.sendMessage(msg.to,"Succes add staff")
                                       except:
                                           pass

                        elif ("Botadd " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           Bots.append(target)
                                           cl.sendMessage(msg.to,"Berhasil menambahkan bot")
                                       except:
                                           pass

                        elif ("Admindell " in msg.text):
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Famz:
                                       try:
                                           admin.remove(target)
                                           cl.sendMessage(msg.to,"succes remove admin")
                                       except:
                                           pass

                        elif ("Staffdell " in msg.text):
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Famz:
                                       try:
                                           del famzadmin["staff"][target]
                                           f=codecs.open('famzadmin.json','w','utf-8')
                                           json.dump(famzadmin, f, sort_keys=True, indent=4,ensure_ascii=False)
                                           cl.sendMessage(msg.to,"Succes remove staff")
                                       except:
                                           pass

                        elif ("Botdell " in msg.text):
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Famz:
                                       try:
                                           Bots.remove(target)
                                           cl.sendMessage(msg.to,"Berhasil menghapus admin")
                                       except:
                                           pass

                        elif cmd == "admin:on" or text.lower() == 'admin:on':
                            if msg._from in admin:
                                wait["addadmin"] = True
                                cl.sendMessage(msg.to,"send contact and typing refresh...")

                        elif cmd == "admin:repeat" or text.lower() == 'admin:repeat':
                            if msg._from in admin:
                                wait["delladmin"] = True
                                cl.sendMessage(msg.to,"send contact and typing refresh...")

                        elif cmd == "staff:on" or text.lower() == 'staff:on':
                            if msg._from in admin:
                                wait["addstaff"] = True
                                cl.sendMessage(msg.to,"send contact and typing refresh...")

                        elif cmd == "staff:repeat" or text.lower() == 'staff:repeat':
                            if msg._from in admin:
                                wait["dellstaff"] = True
                                cl.sendMessage(msg.to,"send contact and typing refresh...")

                        elif cmd == "bot:on" or text.lower() == 'bot:on':
                            if msg._from in admin:
                                wait["addbots"] = True
                                cl.sendMessage(msg.to,"Kirim kontaknya...")

                        elif cmd == "bot:repeat" or text.lower() == 'bot:repeat':
                            if msg._from in admin:
                                wait["dellbots"] = True
                                cl.sendMessage(msg.to,"Kirim kontaknya...")

                        elif cmd == "refresh" or text.lower() == 'refresh':
                            if msg._from in admin:
                                wait["addadmin"] = False
                                wait["delladmin"] = False
                                wait["addstaff"] = False
                                wait["dellstaff"] = False
                                wait["addbots"] = False
                                wait["dellbots"] = False
                                wait["wblacklist"] = False
                                wait["dblacklist"] = False
                                wait["Talkwblacklist"] = False
                                wait["Talkdblacklist"] = False
                                wait["qr"] = False
                                wait["inv"] = False
                                cl.sendMessage(msg.to,"succes to Refresh...")

                        elif cmd == "listadmin" or text.lower() == 'contact admin':
                            if msg._from in admin:
                                ma = ""
                                for i in admin:
                                    ma = cl.getContact(i)
                                    cl.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)
                                for i in famzadmin["staff"]:
                                    ma = cl.getContact(i)
                                    cl.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)

                        elif cmd == "mybot" or text.lower() == 'contact bot':
                            if msg._from in admin:
                                ma = ""
                                for i in Bots:
                                    ma = cl.getContact(i)
                                    cl.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)

#===========COMMAND ON OFF============#
                        elif cmd == "notag on" or text.lower() == 'notag on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["Mentionkick"] = True
                                cl.sendMessage(msg.to,"Notag diaktifkan")

                        elif cmd == "notag off" or text.lower() == 'notag off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["MentionKick"] = False
                                cl.sendMessage(msg.to,"Notag dinonaktifkan")

                        elif cmd == "contact on" or text.lower() == 'contact on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["contact"] = True
                                cl.sendMessage(msg.to,"Detect contact active")

                        elif cmd == "contact off" or text.lower() == 'contact off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["contact"] = False
                                cl.sendMessage(msg.to,"Detect contact not active")

                        elif cmd == "respon on" or text.lower() == 'respon on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectMention"] = True
                                cl.sendMessage(msg.to,"Auto respon active")

                        elif cmd == "respon off" or text.lower() == 'respon off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["detectMention"] = False
                                cl.sendMessage(msg.to,"Auto respon not active")

                        elif cmd == "autojoin on" or text.lower() == 'autojoin on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoJoin"] = True
                                cl.sendMessage(msg.to,"Autojoin active")

                        elif cmd == "autojoin off" or text.lower() == 'autojoin off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoJoin"] = False
                                cl.sendMessage(msg.to,"Autojoin not active")
#-------------------------------------------------------------------------------------
                        elif cmd == "left on" or text.lower() == 'left on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["left"] = True
                                cl.sendMessage(msg.to,"leave message active")

                        elif cmd == "left off" or text.lower() == 'left off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["left"] = False
                                cl.sendMessage(msg.to,"leave message not active")
#----------------------------------------------------------------------------------------
                        elif cmd == "autoleave on" or text.lower() == 'autoleave on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoLeave"] = True
                                cl.sendMessage(msg.to,"Autoleave diaktifkan")

                        elif cmd == "autoleave off" or text.lower() == 'autoleave off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoLeave"] = False
                                cl.sendMessage(msg.to,"Autoleave dinonaktifkan")

                        elif cmd == "autoadd on" or text.lower() == 'autoadd on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoAdd"] = True
                                cl.sendMessage(msg.to,"Auto add diaktifkan")

                        elif cmd == "autoadd off" or text.lower() == 'autoadd off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoAdd"] = False
                                cl.sendMessage(msg.to,"Auto add dinonaktifkan")

                        elif cmd == "read on" or text.lower() == 'autoread on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoRead"] = True
                                cl.sendMessage(msg.to,"Auto add diaktifkan")

                        elif cmd == "read off" or text.lower() == 'autoread off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoRead"] = False
                                cl.sendMessage(msg.to,"Auto add dinonaktifkan")

                        elif cmd == "sticker on" or text.lower() == 'sticker on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["sticker"] = True
                                cl.sendMessage(msg.to,"Deteksi sticker diaktifkan")

                        elif cmd == "sticker off" or text.lower() == 'sticker off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["sticker"] = False
                                cl.sendMessage(msg.to,"Deteksi sticker dinonaktifkan")

                        elif cmd == "jointicket on" or text.lower() == 'jointicket on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoJoinTicket"] = True
                                cl.sendMessage(msg.to,"Join ticket diaktifkan")

                        elif cmd == "jointicket off" or text.lower() == 'jointicket off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoJoinTicket"] = False
                                cl.sendMessage(msg.to,"Autojoin Tiket dinonaktifkan")
#===========COMMAND BLACKLIST============#
                        elif ("Talkban " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           wait["Talkblacklist"][target] = True
                                           cl.sendMessage(msg.to,"Berhasil menambahkan blacklist")
                                       except:
                                           pass

                        elif ("Untalkban " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           del wait["Talkblacklist"][target]
                                           cl.sendMessage(msg.to,"Berhasil menghapus blacklist")
                                       except:
                                           pass

                        elif cmd == "talkban:on" or text.lower() == 'talkban:on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["Talkwblacklist"] = True
                                cl.sendMessage(msg.to,"Kirim kontaknya...")

                        elif cmd == "untalkban:on" or text.lower() == 'untalkban:on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["Talkdblacklist"] = True
                                cl.sendMessage(msg.to,"Kirim kontaknya...")

                        elif ("Ban " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           wait["blacklist"][target] = True
                                           cl.sendMessage(msg.to,"succes add blacklist")
                                       except:
                                           pass

                        elif ("Unban " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           del wait["blacklist"][target]
                                           cl.sendMessage(msg.to,"succes remove blacklist")
                                       except:
                                           pass

                        elif cmd == "ban:on" or text.lower() == 'ban:on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["wblacklist"] = True
                                cl.sendMessage(msg.to,"send contact...")

                        elif cmd == "unban:on" or text.lower() == 'unban:on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["dblacklist"] = True
                                cl.sendMessage(msg.to,"send contact...")

                        elif cmd == "banlist" or text.lower() == 'banlist':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if wait["blacklist"] == {}:
                                cl.sendMessage(msg.to,"have't blacklist")
                              else:
                                ma = ""
                                a = 0
                                for m_id in wait["blacklist"]:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +cl.getContact(m_id).displayName + "\n"
                                cl.sendMessage(msg.to,"﴾ sᴀмuᴅʀᴀ____ʙoтs ﴿ Blacklist User\n\n"+ma+"\nTotal「%s」Blacklist User" %(str(len(wait["blacklist"]))))
                                wait["qr"] = False
                                wait["inv"] = False

                        elif cmd == "talkbanlist" or text.lower() == 'talkbanlist':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if wait["Talkblacklist"] == {}:
                                cl.sendMessage(msg.to,"Tidak ada Talkban user")
                              else:
                                ma = ""
                                a = 0
                                for m_id in wait["Talkblacklist"]:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +cl.getContact(m_id).displayName + "\n"
                                cl.sendMessage(msg.to,"❧ĐPĶ Talkban User\n\n"+ma+"\nTotal「%s」Talkban User" %(str(len(wait["Talkblacklist"]))))

                        elif cmd == "blc" or text.lower() == 'blc':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if wait["blacklist"] == {}:
                                    cl.sendMessage(msg.to,"Tidak ada blacklist")
                              else:
                                    ma = ""
                                    for i in wait["blacklist"]:
                                        ma = cl.getContact(i)
                                        cl.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)

                        elif cmd == "ceban" or text.lower() == 'clearban':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              wait["blacklist"] = {}
                              ragets = cl.getContacts(wait["blacklist"])
                              mc = "「%i」User Blacklist" % len(ragets)
                              wait["qr"] = False
                              wait["inv"] = False
                              cl.sendMessage(msg.to,"Clearrrr....!!! ")
                              ki.sendMessage(msg.to,"Clearrrr....!!! ")
                              kk.sendMessage(msg.to,"Clearrrr....!!! ")
                              kc.sendMessage(msg.to,"Clearrrr....!!! ")
                              km.sendMessage(msg.to,"Clearrrr....!!! ")
                              kb.sendMessage(msg.to,"Clearrrr....!!! ")
                              kn.sendMessage(msg.to,"Clearrrr....!!! ")
                              ko.sendMessage(msg.to,"Clearrrr....!!! ")
                              kw.sendMessage(msg.to,"Clearrrr....!!! ")
                              ke.sendMessage(msg.to,"Clearrrr....!!! ")
                              ky.sendMessage(msg.to,"Clearrrr....!!! ")

                        elif text.lower() == "cekbot":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                try:cl.inviteIntoGroup(to, [selfmid]);has = "OK"
                                except:has = "NOT"
                                try:cl.kickoutFromGroup(to, [selfmid]);has1 = "OK"
                                except:has1 = "NOT"
                                if has == "OK":sil = "Ѵ"
                                else:sil = "×"
                                if has1 == "OK":sil1 = "Ѵ"
                                else:sil1 = "×"
                                cl.sendMessage(to, "Status bot\n║☯➸ Kick : {} \n║☯➸ Invite : {}".format(sil1,sil))
                                try:ki.inviteIntoGroup(to, [Amid]);has = "OK"
                                except:has = "NOT"
                                try:ki.kickoutFromGroup(to, [Amid]);has1 = "OK"
                                except:has1 = "NOT"
                                if has == "OK":sil = "Ѵ"
                                else:sil = "×"
                                if has1 == "OK":sil1 = "Ѵ"
                                else:sil1 = "×"
                                ki.sendMessage(to, "Status bot\n║☯➸ Kick : {} \n║☯➸ Invite : {}".format(sil1,sil))
                                try:kk.inviteIntoGroup(to, [Bmid]);has = "OK"
                                except:has = "NOT"
                                try:kk.kickoutFromGroup(to, [Bmid]);has1 = "OK"
                                except:has1 = "NOT"
                                if has == "OK":sil = "Ѵ"
                                else:sil = "×"
                                if has1 == "OK":sil1 = "Ѵ"
                                else:sil1 = "×"
                                kk.sendMessage(to, "Status bot\n║☯➸ Kick : {} \n║☯➸ Invite : {}".format(sil1,sil))
                                try:kc.inviteIntoGroup(to, [Cmid]);has = "OK"
                                except:has = "NOT"
                                try:kc.kickoutFromGroup(to, [Cmid]);has1 = "OK"
                                except:has1 = "NOT"
                                if has == "OK":sil = "Ѵ"
                                else:sil = "×"
                                if has1 == "OK":sil1 = "Ѵ"
                                else:sil1 = "×"
                                kc.sendMessage(to, "Status bot\n║☯➸ Kick : {} \n║☯➸ Invite : {}".format(sil1,sil))
                                try:km.inviteIntoGroup(to, [Dmid]);has = "OK"
                                except:has = "NOT"
                                try:km.kickoutFromGroup(to, [Dmid]);has1 = "OK"
                                except:has1 = "NOT"
                                if has == "OK":sil = "Ѵ"
                                else:sil = "×"
                                if has1 == "OK":sil1 = "Ѵ"
                                else:sil1 = "×"
                                km.sendMessage(to, "Status bot\n║☯➸ Kick : {} \n║☯➸ Invite : {}".format(sil1,sil))
                                try:kb.inviteIntoGroup(to, [Emid]);has = "OK"
                                except:has = "NOT"
                                try:kb.kickoutFromGroup(to, [Emid]);has1 = "OK"
                                except:has1 = "NOT"
                                if has == "OK":sil = "Ѵ"
                                else:sil = "×"
                                if has1 == "OK":sil1 = "Ѵ"
                                else:sil1 = "×"
                                kb.sendMessage(to, "Status bot\n║☯➸ Kick : {} \n║☯➸ Invite : {}".format(sil1,sil))
                                try:kn.inviteIntoGroup(to, [Fmid]);has = "OK"
                                except:has = "NOT"
                                try:kn.kickoutFromGroup(to, [Fmid]);has1 = "OK"
                                except:has1 = "NOT"
                                if has == "OK":sil = "Ѵ"
                                else:sil = "×"
                                if has1 == "OK":sil1 = "Ѵ"
                                else:sil1 = "×"
                                kn.sendMessage(to, "Status bot\n║☯➸ Kick : {} \n║☯➸ Invite : {}".format(sil1,sil))
                                try:ko.inviteIntoGroup(to, [Gmid]);has = "OK"
                                except:has = "NOT"
                                try:ko.kickoutFromGroup(to, [Gmid]);has1 = "OK"
                                except:has1 = "NOT"
                                if has == "OK":sil = "Ѵ"
                                else:sil = "×"
                                if has1 == "OK":sil1 = "Ѵ"
                                else:sil1 = "×"
                                ko.sendMessage(to, "Status bot\n║☯➸ Kick : {} \n║☯➸ Invite : {}".format(sil1,sil))
                                try:kw.inviteIntoGroup(to, [Hmid]);has = "OK"
                                except:has = "NOT"
                                try:kw.kickoutFromGroup(to, [Hmid]);has1 = "OK"
                                except:has1 = "NOT"
                                if has == "OK":sil = "Ѵ"
                                else:sil = "×"
                                if has1 == "OK":sil1 = "Ѵ"
                                else:sil1 = "×"
                                kw.sendMessage(to, "Status bot\n║☯➸ Kick : {} \n║☯➸ Invite : {}".format(sil1,sil))
                                try:ke.inviteIntoGroup(to, [Imid]);has = "OK"
                                except:has = "NOT"
                                try:ke.kickoutFromGroup(to, [Imid]);has1 = "OK"
                                except:has1 = "NOT"
                                if has == "OK":sil = "Ѵ"
                                else:sil = "×"
                                if has1 == "OK":sil1 = "Ѵ"
                                else:sil1 = "×"
                                ke.sendMessage(to, "Status bot\n║☯➸ Kick : {} \n║☯➸ Invite : {}".format(sil1,sil))
                                try:ky.inviteIntoGroup(to, [Jmid]);has = "OK"
                                except:has = "NOT"
                                try:ky.kickoutFromGroup(to, [Jmid]);has1 = "OK"
                                except:has1 = "NOT"
                                if has == "OK":sil = "Ѵ"
                                else:sil = "×"
                                if has1 == "OK":sil1 = "Ѵ"
                                else:sil1 = "×"
                                ky.sendMessage(to, "Status bot\n║☯➸ Kick : {} \n║☯➸ Invite : {}".format(sil1,sil))
#===========COMMAND SET============#
                        elif 'Set pesan: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set pesan: ','')
                              if spl in [""," ","\n",None]:
                                  cl.sendMessage(msg.to, "Gagal mengganti Pesan Msg")
                              else:
                                  wait["message"] = spl
                                  cl.sendMessage(msg.to, "「Pesan Msg」\nPesan Msg diganti jadi :\n\n「{}」".format(str(spl)))

                        elif 'Set welcome: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set welcome: ','')
                              if spl in [""," ","\n",None]:
                                  cl.sendMessage(msg.to, "Gagal mengganti Welcome Msg")
                              else:
                                  wait["welcome"] = spl
                                  cl.sendMessage(msg.to, "「Welcome Msg」\nWelcome Msg diganti jadi :\n\n「{}」".format(str(spl)))

                        elif 'Set leave: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set leave: ','')
                              if spl in [""," ","\n",None]:
                                  cl.sendMessage(msg.to, "Gagal mengganti leave Msg")
                              else:
                                  wait["leave"] = spl
                                  cl.sendMessage(msg.to, "「leave Msg」\leave Msg diganti jadi :\n\n「{}」".format(str(spl)))

                        elif 'Set respon: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set respon: ','')
                              if spl in [""," ","\n",None]:
                                  cl.sendMessage(msg.to, "Gagal mengganti Respon Msg")
                              else:
                                  wait["Respontag"] = spl
                                  cl.sendMessage(msg.to, "「Respon Msg」\nRespon Msg diganti jadi :\n\n「{}」".format(str(spl)))

                        elif 'Set spam: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set spam: ','')
                              if spl in [""," ","\n",None]:
                                  cl.sendMessage(msg.to, "Gagal mengganti Spam")
                              else:
                                  Setmain["ARmessage1"] = spl
                                  cl.sendMessage(msg.to, "「Spam Msg」\nSpam Msg diganti jadi :\n\n「{}」".format(str(spl)))

                        elif 'Set sider: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set sider: ','')
                              if spl in [""," ","\n",None]:
                                  cl.sendMessage(msg.to, "Gagal mengganti Sider Msg")
                              else:
                                  wait["mention"] = spl
                                  cl.sendMessage(msg.to, "「Sider Msg」\nSider Msg diganti jadi :\n\n「{}」".format(str(spl)))

                        elif text.lower() == "cek pesan":
                            if msg._from in admin:
                               cl.sendMessage(msg.to, "「Pesan Msg」\nPesan Msg mu :\n\n「 " + str(wait["message"]) + " 」")

                        elif text.lower() == "cek welcome":
                            if msg._from in admin:
                               cl.sendMessage(msg.to, "「Welcome Msg」\nWelcome Msg mu :\n\n「 " + str(wait["welcome"]) + " 」")

                        elif text.lower() == "cek respon":
                            if msg._from in admin:
                               cl.sendMessage(msg.to, "「Respon Msg」\nRespon Msg mu :\n\n「 " + str(wait["Respontag"]) + " 」")

                        elif text.lower() == "cek spam":
                            if msg._from in admin:
                               cl.sendMessage(msg.to, "「Spam Msg」\nSpam Msg mu :\n\n「 " + str(Setmain["ARmessage1"]) + " 」")

                        elif text.lower() == "cek sider":
                            if msg._from in admin:
                               cl.sendMessage(msg.to, "「Sider Msg」\nSider Msg mu :\n\n「 " + str(wait["mention"]) + " 」")

#===========JOIN TICKET============#
                        elif "/ti/g/" in msg.text.lower():
                          if wait["selfbot"] == True:
                              if settings["autoJoinTicket"] == True:
                                 link_re = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                                 links = link_re.findall(text)
                                 n_links = []
                                 for l in links:
                                     if l not in n_links:
                                        n_links.append(l)
                                 for ticket_id in n_links:
                                     group = cl.findGroupByTicket(ticket_id)
                                     cl.acceptGroupInvitationByTicket(group.id,ticket_id)
                                     cl.sendMessage(msg.to, "Masuk : %s" % str(group.name))
                                     group1 = ki.findGroupByTicket(ticket_id)
                                     ki.acceptGroupInvitationByTicket(group1.id,ticket_id)
                                     ki.sendMessage(msg.to, "Masuk : %s" % str(group.name))
                                     group2 = kk.findGroupByTicket(ticket_id)
                                     kk.acceptGroupInvitationByTicket(group2.id,ticket_id)
                                     kk.sendMessage(msg.to, "Masuk : %s" % str(group.name))
                                     group3 = kc.findGroupByTicket(ticket_id)
                                     kc.acceptGroupInvitationByTicket(group3.id,ticket_id)
                                     kc.sendMessage(msg.to, "Masuk : %s" % str(group.name))
                                     group4 = km.findGroupByTicket(ticket_id)
                                     km.acceptGroupInvitationByTicket(group4.id,ticket_id)
                                     km.sendMessage(msg.to, "Masuk : %s" % str(group.name))
                                     group5 = kb.findGroupByTicket(ticket_id)
                                     kb.acceptGroupInvitationByTicket(group5.id,ticket_id)
                                     kb.sendMessage(msg.to, "Masuk : %s" % str(group.name))
                                     group6 = kn.findGroupByTicket(ticket_id)
                                     kn.acceptGroupInvitationByTicket(group6.id,ticket_id)
                                     kn.sendMessage(msg.to, "Masuk : %s" % str(group.name))
                                     group7 = ko.findGroupByTicket(ticket_id)
                                     ko.acceptGroupInvitationByTicket(group7.id,ticket_id)
                                     ko.sendMessage(msg.to, "Masuk : %s" % str(group.name))
                                     group8 = kw.findGroupByTicket(ticket_id)
                                     kw.acceptGroupInvitationByTicket(group8.id,ticket_id)
                                     kw.sendMessage(msg.to, "Masuk : %s" % str(group.name))
                                     group9 = ke.findGroupByTicket(ticket_id)
                                     ke.acceptGroupInvitationByTicket(group9.id,ticket_id)
                                     ke.sendMessage(msg.to, "Masuk : %s" % str(group.name))
                                     group10 = ky.findGroupByTicket(ticket_id)
                                     ky.acceptGroupInvitationByTicket(group10.id,ticket_id)
                                     ky.sendMessage(msg.to, "Masuk : %s" % str(group.name))
    except Exception as error:
        print (error)

while True:
    try:
        ops = oepoll.singleTrace(count=50)
        if ops is not None:
            for op in ops:
                bot(op)
                oepoll.setRevision(op.revision)
    except Exception as e:
        print(e)