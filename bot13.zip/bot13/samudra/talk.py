# -*- coding: utf-8 -*-
from akad.ttypes import Message
from random import randint

import json, ntpath

def loggedIn(func):
    def checkLogin(*args, **kwargs):
        if args[0].isLogin:
            return func(*args, **kwargs)
        else:
            args[0].callback.other('You want to call the function, you must login to LINE')
    return checkLogin

class Talk(object):
    isLogin = False
    _messageReq = {}
    _unsendMessageReq = 0

    def __init__(self):
        self.isLogin = True
        
    def __init__(self1):
        self1.isLogin = True
        
    def __init__(self2):
        self2.isLogin = True
        
    def __init__(self3):
        self3.isLogin = True
        
    def __init__(self4):
        self4.isLogin = True
        
    def __init__(self5):
        self5.isLogin = True
        
    def __init__(self6):
        self6.isLogin = True
        
    def __init__(self7):
        self7.isLogin = True
        
    def __init__(self8):
        self8.isLogin = True

    """User"""
    @loggedIn
    def getRecentMessagesV2(self, chatId, count=1001):
        return self.talk.getRecentMessagesV2(chatId,count)
        
    @loggedIn
    def getRecentMessagesV2(self1, chatId, count=1001):
        return self1.talk.getRecentMessagesV2(chatId,count)
        
    @loggedIn
    def getRecentMessagesV2(self2, chatId, count=1001):
        return self2.talk.getRecentMessagesV2(chatId,count)
        
    @loggedIn
    def getRecentMessagesV2(self3, chatId, count=1001):
        return self3.talk.getRecentMessagesV2(chatId,count)
        
    @loggedIn
    def getRecentMessagesV2(self4, chatId, count=1001):
        return self4.talk.getRecentMessagesV2(chatId,count)
        
    @loggedIn
    def getRecentMessagesV2(self5, chatId, count=1001):
        return self5.talk.getRecentMessagesV2(chatId,count)
        
    @loggedIn
    def getRecentMessagesV2(self6, chatId, count=1001):
        return self6.talk.getRecentMessagesV2(chatId,count)
        
    @loggedIn
    def getRecentMessagesV2(self8, chatId, count=1001):
        return self8.talk.getRecentMessagesV2(chatId,count)

    @loggedIn
    def acquireEncryptedAccessToken(self, featureType=2):
        return self.talk.acquireEncryptedAccessToken(featureType)
        
    @loggedIn
    def acquireEncryptedAccessToken(self1, featureType=2):
        return self1.talk.acquireEncryptedAccessToken(featureType)
        
    @loggedIn
    def acquireEncryptedAccessToken(self2, featureType=2):
        return self2.talk.acquireEncryptedAccessToken(featureType)
        
    @loggedIn
    def acquireEncryptedAccessToken(self3, featureType=2):
        return self3.talk.acquireEncryptedAccessToken(featureType)
        
    @loggedIn
    def acquireEncryptedAccessToken(self4, featureType=2):
        return self4.talk.acquireEncryptedAccessToken(featureType)
        
    @loggedIn
    def acquireEncryptedAccessToken(self5, featureType=2):
        return self5.talk.acquireEncryptedAccessToken(featureType)
        
    @loggedIn
    def acquireEncryptedAccessToken(self6, featureType=2):
        return self6.talk.acquireEncryptedAccessToken(featureType)
        
    @loggedIn
    def acquireEncryptedAccessToken(self7, featureType=2):
        return self7.talk.acquireEncryptedAccessToken(featureType)
        
    @loggedIn
    def acquireEncryptedAccessToken(self8, featureType=2):
        return self8.talk.acquireEncryptedAccessToken(featureType)

    @loggedIn
    def getProfile(self):
        return self.talk.getProfile()
        
    @loggedIn
    def getProfile(self1):
        return self1.talk.getProfile()
        
    @loggedIn
    def getProfile(self2):
        return self2.talk.getProfile()
        
    @loggedIn
    def getProfile(self3):
        return self3.talk.getProfile()
        
    @loggedIn
    def getProfile(self4):
        return self4.talk.getProfile()
        
    @loggedIn
    def getProfile(self5):
        return self5.talk.getProfile()
        
    @loggedIn
    def getProfile(self6):
        return self6.talk.getProfile()
        
    @loggedIn
    def getProfile(self7):
        return self7.talk.getProfile()
        
    @loggedIn
    def getProfile(self8):
        return self8.talk.getProfile()
        
    @loggedIn
    def getSettings(self):
        return self.talk.getSettings()
        
    @loggedIn
    def getSettings(self1):
        return self1.talk.getSettings()
        
    @loggedIn
    def getSettings(self2):
        return self2.talk.getSettings()
        
    @loggedIn
    def getSettings(self3):
        return self3.talk.getSettings()
        
    @loggedIn
    def getSettings(self4):
        return self4.talk.getSettings()
        
    @loggedIn
    def getSettings(self5):
        return self5.talk.getSettings()
        
    @loggedIn
    def getSettings(self6):
        return self6.talk.getSettings()
        
    @loggedIn
    def getSettings(self7):
        return self7.talk.getSettings()
        
    @loggedIn
    def getSettings(self8):
        return self8.talk.getSettings()

    @loggedIn
    def getUserTicket(self):
        return self.talk.getUserTicket()
        
    @loggedIn
    def getUserTicket(self1):
        return self1.talk.getUserTicket()
        
    @loggedIn
    def getUserTicket(self2):
        return self2.talk.getUserTicket()
        
    @loggedIn
    def getUserTicket(self3):
        return self3.talk.getUserTicket()
        
    @loggedIn
    def getUserTicket(self4):
        return self4.talk.getUserTicket()
        
    @loggedIn
    def getUserTicket(self5):
        return self5.talk.getUserTicket()
        
    @loggedIn
    def getUserTicket(self6):
        return self6.talk.getUserTicket()
        
    @loggedIn
    def getUserTicket(self7):
        return self7.talk.getUserTicket()
        
    @loggedIn
    def getUserTicket(self8):
        return self8.talk.getUserTicket()

    @loggedIn
    def updateProfile(self, profileObject):
        return self.talk.updateProfile(0, profileObject)
        
    @loggedIn
    def updateProfile(self1, profileObject):
        return self1.talk.updateProfile(0, profileObject)
        
    @loggedIn
    def updateProfile(self2, profileObject):
        return self2.talk.updateProfile(0, profileObject)
        
    @loggedIn
    def updateProfile(self3, profileObject):
        return self3.talk.updateProfile(0, profileObject)
        
    @loggedIn
    def updateProfile(self4, profileObject):
        return self4.talk.updateProfile(0, profileObject)
        
    @loggedIn
    def updateProfile(self5, profileObject):
        return self5.talk.updateProfile(0, profileObject)
        
    @loggedIn
    def updateProfile(self6, profileObject):
        return self6.talk.updateProfile(0, profileObject)
        
    @loggedIn
    def updateProfile(self7, profileObject):
        return self7.talk.updateProfile(0, profileObject)
        
    @loggedIn
    def updateProfile(self8, profileObject):
        return self8.talk.updateProfile(0, profileObject)

    @loggedIn
    def updateSettings(self, settingObject):
        return self.talk.updateSettings(0, settingObject)
        
    @loggedIn
    def updateSettings(self1, settingObject):
        return self1.talk.updateSettings(0, settingObject)
        
    @loggedIn
    def updateSettings(self2, settingObject):
        return self2.talk.updateSettings(0, settingObject)
        
    @loggedIn
    def updateSettings(self3, settingObject):
        return self3.talk.updateSettings(0, settingObject)
        
    @loggedIn
    def updateSettings(self4, settingObject):
        return self4.talk.updateSettings(0, settingObject)
        
    @loggedIn
    def updateSettings(self5, settingObject):
        return self5.talk.updateSettings(0, settingObject)
        
    @loggedIn
    def updateSettings(self6, settingObject):
        return self6.talk.updateSettings(0, settingObject)
        
    @loggedIn
    def updateSettings(self7, settingObject):
        return self7.talk.updateSettings(0, settingObject)
        
    @loggedIn
    def updateSettings(self8, settingObject):
        return self8.talk.updateSettings(0, settingObject)

    @loggedIn
    def updateProfileAttribute(self, attrId, value):
        return self.talk.updateProfileAttribute(0, attrId, value)
        
    @loggedIn
    def updateProfileAttribute(self1, attrId, value):
        return self1.talk.updateProfileAttribute(0, attrId, value)
        
    @loggedIn
    def updateProfileAttribute(self2, attrId, value):
        return self2.talk.updateProfileAttribute(0, attrId, value)
        
    @loggedIn
    def updateProfileAttribute(self3, attrId, value):
        return self3.talk.updateProfileAttribute(0, attrId, value)
        
    @loggedIn
    def updateProfileAttribute(self4, attrId, value):
        return self4.talk.updateProfileAttribute(0, attrId, value)
        
    @loggedIn
    def updateProfileAttribute(self5, attrId, value):
        return self5.talk.updateProfileAttribute(0, attrId, value)
        
    @loggedIn
    def updateProfileAttribute(self6, attrId, value):
        return self6.talk.updateProfileAttribute(0, attrId, value)
        
    @loggedIn
    def updateProfileAttribute(self7, attrId, value):
        return self7.talk.updateProfileAttribute(0, attrId, value)
        
    @loggedIn
    def updateProfileAttribute(self8, attrId, value):
        return self8.talk.updateProfileAttribute(0, attrId, value)

    """Operation"""

    @loggedIn
    def fetchOperation(self, revision, count):
        return self.talk.fetchOperations(revision, count)
        
    @loggedIn
    def fetchOperation(self1, revision, count):
        return self1.talk.fetchOperations(revision, count)
        
    @loggedIn
    def fetchOperation(self2, revision, count):
        return self2.talk.fetchOperations(revision, count)
        
    @loggedIn
    def fetchOperation(self3, revision, count):
        return self3.talk.fetchOperations(revision, count)
        
    @loggedIn
    def fetchOperation(self4, revision, count):
        return self4.talk.fetchOperations(revision, count)
        
    @loggedIn
    def fetchOperation(self5, revision, count):
        return self5.talk.fetchOperations(revision, count)
        
    @loggedIn
    def fetchOperation(self6, revision, count):
        return self6.talk.fetchOperations(revision, count)
        
    @loggedIn
    def fetchOperation(self7, revision, count):
        return self7.talk.fetchOperations(revision, count)
        
    @loggedIn
    def fetchOperation(self8, revision, count):
        return self8.talk.fetchOperations(revision, count)

    @loggedIn
    def getLastOpRevision(self):
        return self.talk.getLastOpRevision()
        
    @loggedIn
    def getLastOpRevision(self1):
        return self1.talk.getLastOpRevision()
        
    @loggedIn
    def getLastOpRevision(self2):
        return self2.talk.getLastOpRevision()
        
    @loggedIn
    def getLastOpRevision(self3):
        return self3.talk.getLastOpRevision()
        
    @loggedIn
    def getLastOpRevision(self4):
        return self4.talk.getLastOpRevision()
        
    @loggedIn
    def getLastOpRevision(self5):
        return self5.talk.getLastOpRevision()
        
    @loggedIn
    def getLastOpRevision(self6):
        return self6.talk.getLastOpRevision()
        
    @loggedIn
    def getLastOpRevision(self7):
        return self7.talk.getLastOpRevision()
        
    @loggedIn
    def getLastOpRevision(self8):
        return self8.talk.getLastOpRevision()

    """Message"""
    
    @loggedIn
    def sendMentionFooter(self, to, text, mid, link, icon, footer):
        arr = []
        list_text=''
        list_text+=' @novi '
        text=text+list_text
        name='@novi '
        ln_text=text.replace('\n',' ')
        if ln_text.find(name):
            line_s=int(ln_text.index(name))
            line_e=(int(line_s)+int(len(name)))
        arrData={'S': str(line_s), 'E': str(line_e), 'M': mid}
        arr.append(arrData)
        contentMetadata={'AGENT_LINK': link, 'AGENT_ICON': icon, 'AGENT_NAME': footer,'MENTION':str('{"MENTIONEES":' + json.dumps(arr).replace(' ','') + '}')}
        return self.sendMessage(to, text, contentMetadata)
        
    @loggedIn
    def sendMentionFooter(self1, to, text, mid, link, icon, footer):
        arr = []
        list_text=''
        list_text+=' @novi '
        text=text+list_text
        name='@novi '
        ln_text=text.replace('\n',' ')
        if ln_text.find(name):
            line_s=int(ln_text.index(name))
            line_e=(int(line_s)+int(len(name)))
        arrData={'S': str(line_s), 'E': str(line_e), 'M': mid}
        arr.append(arrData)
        contentMetadata={'AGENT_LINK': link, 'AGENT_ICON': icon, 'AGENT_NAME': footer,'MENTION':str('{"MENTIONEES":' + json.dumps(arr).replace(' ','') + '}')}
        return self1.sendMessage(to, text, contentMetadata)
        
    @loggedIn
    def sendMentionFooter(self2, to, text, mid, link, icon, footer):
        arr = []
        list_text=''
        list_text+=' @novi '
        text=text+list_text
        name='@novi '
        ln_text=text.replace('\n',' ')
        if ln_text.find(name):
            line_s=int(ln_text.index(name))
            line_e=(int(line_s)+int(len(name)))
        arrData={'S': str(line_s), 'E': str(line_e), 'M': mid}
        arr.append(arrData)
        contentMetadata={'AGENT_LINK': link, 'AGENT_ICON': icon, 'AGENT_NAME': footer,'MENTION':str('{"MENTIONEES":' + json.dumps(arr).replace(' ','') + '}')}
        return self2.sendMessage(to, text, contentMetadata)
        
    @loggedIn
    def sendMentionFooter(self3, to, text, mid, link, icon, footer):
        arr = []
        list_text=''
        list_text+=' @novi '
        text=text+list_text
        name='@novi '
        ln_text=text.replace('\n',' ')
        if ln_text.find(name):
            line_s=int(ln_text.index(name))
            line_e=(int(line_s)+int(len(name)))
        arrData={'S': str(line_s), 'E': str(line_e), 'M': mid}
        arr.append(arrData)
        contentMetadata={'AGENT_LINK': link, 'AGENT_ICON': icon, 'AGENT_NAME': footer,'MENTION':str('{"MENTIONEES":' + json.dumps(arr).replace(' ','') + '}')}
        return self3.sendMessage(to, text, contentMetadata)
        
    @loggedIn
    def sendMentionFooter(self4, to, text, mid, link, icon, footer):
        arr = []
        list_text=''
        list_text+=' @novi '
        text=text+list_text
        name='@novi '
        ln_text=text.replace('\n',' ')
        if ln_text.find(name):
            line_s=int(ln_text.index(name))
            line_e=(int(line_s)+int(len(name)))
        arrData={'S': str(line_s), 'E': str(line_e), 'M': mid}
        arr.append(arrData)
        contentMetadata={'AGENT_LINK': link, 'AGENT_ICON': icon, 'AGENT_NAME': footer,'MENTION':str('{"MENTIONEES":' + json.dumps(arr).replace(' ','') + '}')}
        return self4.sendMessage(to, text, contentMetadata)
        
    @loggedIn
    def sendMentionFooter(self5, to, text, mid, link, icon, footer):
        arr = []
        list_text=''
        list_text+=' @novi '
        text=text+list_text
        name='@novi '
        ln_text=text.replace('\n',' ')
        if ln_text.find(name):
            line_s=int(ln_text.index(name))
            line_e=(int(line_s)+int(len(name)))
        arrData={'S': str(line_s), 'E': str(line_e), 'M': mid}
        arr.append(arrData)
        contentMetadata={'AGENT_LINK': link, 'AGENT_ICON': icon, 'AGENT_NAME': footer,'MENTION':str('{"MENTIONEES":' + json.dumps(arr).replace(' ','') + '}')}
        return self5.sendMessage(to, text, contentMetadata)
        
    @loggedIn
    def sendMentionFooter(self6, to, text, mid, link, icon, footer):
        arr = []
        list_text=''
        list_text+=' @novi '
        text=text+list_text
        name='@novi '
        ln_text=text.replace('\n',' ')
        if ln_text.find(name):
            line_s=int(ln_text.index(name))
            line_e=(int(line_s)+int(len(name)))
        arrData={'S': str(line_s), 'E': str(line_e), 'M': mid}
        arr.append(arrData)
        contentMetadata={'AGENT_LINK': link, 'AGENT_ICON': icon, 'AGENT_NAME': footer,'MENTION':str('{"MENTIONEES":' + json.dumps(arr).replace(' ','') + '}')}
        return self6.sendMessage(to, text, contentMetadata)
        
    @loggedIn
    def sendMentionFooter(self7, to, text, mid, link, icon, footer):
        arr = []
        list_text=''
        list_text+=' @novi '
        text=text+list_text
        name='@novi '
        ln_text=text.replace('\n',' ')
        if ln_text.find(name):
            line_s=int(ln_text.index(name))
            line_e=(int(line_s)+int(len(name)))
        arrData={'S': str(line_s), 'E': str(line_e), 'M': mid}
        arr.append(arrData)
        contentMetadata={'AGENT_LINK': link, 'AGENT_ICON': icon, 'AGENT_NAME': footer,'MENTION':str('{"MENTIONEES":' + json.dumps(arr).replace(' ','') + '}')}
        return self7.sendMessage(to, text, contentMetadata)
        
    @loggedIn
    def sendMentionFooter(self8, to, text, mid, link, icon, footer):
        arr = []
        list_text=''
        list_text+=' @novi '
        text=text+list_text
        name='@novi '
        ln_text=text.replace('\n',' ')
        if ln_text.find(name):
            line_s=int(ln_text.index(name))
            line_e=(int(line_s)+int(len(name)))
        arrData={'S': str(line_s), 'E': str(line_e), 'M': mid}
        arr.append(arrData)
        contentMetadata={'AGENT_LINK': link, 'AGENT_ICON': icon, 'AGENT_NAME': footer,'MENTION':str('{"MENTIONEES":' + json.dumps(arr).replace(' ','') + '}')}
        return self8.sendMessage(to, text, contentMetadata)
        
    @loggedIn
    def sendMessage(self, to, text, contentMetadata={}, contentType=0):
        msg = Message()
        msg.to, msg._from = to, self.profile.mid
        msg.text = text
        msg.contentType, msg.contentMetadata = contentType, contentMetadata
        if to not in self._messageReq:
            self._messageReq[to] = -1
        self._messageReq[to] += 1
        return self.talk.sendMessage(self._messageReq[to], msg)
        
    @loggedIn
    def sendMessage(self1, to, text, contentMetadata={}, contentType=0):
        msg = Message()
        msg.to, msg._from = to, self1.profile.mid
        msg.text = text
        msg.contentType, msg.contentMetadata = contentType, contentMetadata
        if to not in self1._messageReq:
            self1._messageReq[to] = -1
        self1._messageReq[to] += 1
        return self1.talk.sendMessage(self1._messageReq[to], msg)
        
    @loggedIn
    def sendMessage(self2, to, text, contentMetadata={}, contentType=0):
        msg = Message()
        msg.to, msg._from = to, self2.profile.mid
        msg.text = text
        msg.contentType, msg.contentMetadata = contentType, contentMetadata
        if to not in self2._messageReq:
            self2._messageReq[to] = -1
        self2._messageReq[to] += 1
        return self2.talk.sendMessage(self2._messageReq[to], msg)
    
    @loggedIn
    def sendMessage(self3, to, text, contentMetadata={}, contentType=0):
        msg = Message()
        msg.to, msg._from = to, self3.profile.mid
        msg.text = text
        msg.contentType, msg.contentMetadata = contentType, contentMetadata
        if to not in self3._messageReq:
            self3._messageReq[to] = -1
        self3._messageReq[to] += 1
        return self3.talk.sendMessage(self3._messageReq[to], msg)
    
    @loggedIn
    def sendMessage(self4, to, text, contentMetadata={}, contentType=0):
        msg = Message()
        msg.to, msg._from = to, self4.profile.mid
        msg.text = text
        msg.contentType, msg.contentMetadata = contentType, contentMetadata
        if to not in self4._messageReq:
            self4._messageReq[to] = -1
        self4._messageReq[to] += 1
        return self4.talk.sendMessage(self4._messageReq[to], msg)
    
    @loggedIn
    def sendMessage(self5, to, text, contentMetadata={}, contentType=0):
        msg = Message()
        msg.to, msg._from = to, self5.profile.mid
        msg.text = text
        msg.contentType, msg.contentMetadata = contentType, contentMetadata
        if to not in self5._messageReq:
            self5._messageReq[to] = -1
        self5._messageReq[to] += 1
        return self5.talk.sendMessage(self5._messageReq[to], msg)
    
    @loggedIn
    def sendMessage(self6, to, text, contentMetadata={}, contentType=0):
        msg = Message()
        msg.to, msg._from = to, self6.profile.mid
        msg.text = text
        msg.contentType, msg.contentMetadata = contentType, contentMetadata
        if to not in self6._messageReq:
            self6._messageReq[to] = -1
        self6._messageReq[to] += 1
        return self6.talk.sendMessage(self6._messageReq[to], msg)
    
    @loggedIn
    def sendMessage(self7, to, text, contentMetadata={}, contentType=0):
        msg = Message()
        msg.to, msg._from = to, self7.profile.mid
        msg.text = text
        msg.contentType, msg.contentMetadata = contentType, contentMetadata
        if to not in self7._messageReq:
            self7._messageReq[to] = -1
        self7._messageReq[to] += 1
        return self7.talk.sendMessage(self7._messageReq[to], msg)
    
    @loggedIn
    def sendMessage(self8, to, text, contentMetadata={}, contentType=0):
        msg = Message()
        msg.to, msg._from = to, self8.profile.mid
        msg.text = text
        msg.contentType, msg.contentMetadata = contentType, contentMetadata
        if to not in self8._messageReq:
            self8._messageReq[to] = -1
        self8._messageReq[to] += 1
        return self8.talk.sendMessage(self8._messageReq[to], msg)
    
    """ Usage:
        @to Integer
        @text String
        @dataMid List of user Mid
    """
#pembatas
    @loggedIn
    def sendMessageWithMention(self, to, text='', dataMid=[]):
        arr = []
        list_text=''
        if '[list]' in text.lower():
            i=0
            for l in dataMid:
                list_text+='\n@[list-'+str(i)+']'
                i=i+1
            text=text.replace('[list]', list_text)
        elif '[list-' in text.lower():
            text=text
        else:
            i=0
            for l in dataMid:
                list_text+=' @[list-'+str(i)+']'
                i=i+1
            text=text+list_text
        i=0
        for l in dataMid:
            mid=l
            name='@[list-'+str(i)+']'
            ln_text=text.replace('\n',' ')
            if ln_text.find(name):
                line_s=int(ln_text.index(name))
                line_e=(int(line_s)+int(len(name)))
            arrData={'S': str(line_s), 'E': str(line_e), 'M': mid}
            arr.append(arrData)
            i=i+1
        contentMetadata={'MENTION':str('{"MENTIONEES":' + json.dumps(arr).replace(' ','') + '}')}
        return self.sendMessage(to, text, contentMetadata)

    @loggedIn
    def sendSticker(self, to, packageId, stickerId):
        contentMetadata = {
            'STKVER': '100',
            'STKPKGID': packageId,
            'STKID': stickerId
        }
        return self.sendMessage(to, '', contentMetadata, 7)
        
    @loggedIn
    def sendContact(self, to, mid):
        contentMetadata = {'mid': mid}
        return self.sendMessage(to, '', contentMetadata, 13)

    @loggedIn
    def sendGift(self, to, productId, productType):
        if productType not in ['theme','sticker']:
            raise Exception('Invalid productType value')
        contentMetadata = {
            'MSGTPL': str(randint(0, 12)),
            'PRDTYPE': productType.upper(),
            'STKPKGID' if productType == 'sticker' else 'PRDID': productId
        }
        return self.sendMessage(to, '', contentMetadata, 9)

    @loggedIn
    def sendMessageAwaitCommit(self, to, text, contentMetadata={}, contentType=0):
        msg = Message()
        msg.to, msg._from = to, self.profile.mid
        msg.text = text
        msg.contentType, msg.contentMetadata = contentType, contentMetadata
        if to not in self._messageReq:
            self._messageReq[to] = -1
        self._messageReq[to] += 1
        return self.talk.sendMessageAwaitCommit(self._messageReq[to], msg)

    @loggedIn
    def unsendMessage(self, messageId):
        self._unsendMessageReq += 1
        return self.talk.unsendMessage(self._unsendMessageReq, messageId)

    @loggedIn
    def requestResendMessage(self, senderMid, messageId):
        return self.talk.requestResendMessage(0, senderMid, messageId)

    @loggedIn
    def respondResendMessage(self, receiverMid, originalMessageId, resendMessage, errorCode):
        return self.talk.respondResendMessage(0, receiverMid, originalMessageId, resendMessage, errorCode)

    @loggedIn
    def removeMessage(self, messageId):
        return self.talk.removeMessage(messageId)
    
    @loggedIn
    def removeAllMessages(self, lastMessageId):
        return self.talk.removeAllMessages(0, lastMessageId)

    @loggedIn
    def removeMessageFromMyHome(self, messageId):
        return self.talk.removeMessageFromMyHome(messageId)

    @loggedIn
    def destroyMessage(self, chatId, messageId):
        return self.talk.destroyMessage(0, chatId, messageId, sessionId)
    
    @loggedIn
    def sendChatChecked(self, consumer, messageId):
        return self.talk.sendChatChecked(0, consumer, messageId)

    @loggedIn
    def sendEvent(self, messageObject):
        return self.talk.sendEvent(0, messageObject)

    @loggedIn
    def getLastReadMessageIds(self, chatId):
        return self.talk.getLastReadMessageIds(0, chatId)

    @loggedIn
    def getPreviousMessagesV2WithReadCount(self, messageBoxId, endMessageId, messagesCount=50):
        return self.talk.getPreviousMessagesV2WithReadCount(messageBoxId, endMessageId, messagesCount)

    """Object"""

    @loggedIn
    def sendImage(self, to, path):
        objectId = self.sendMessage(to=to, text=None, contentType = 1).id
        return self.uploadObjTalk(path=path, type='image', returnAs='bool', objId=objectId)

    @loggedIn
    def sendImageWithURL(self, to, url):
        path = self.downloadFileURL(url, 'path')
        return self.sendImage(to, path)

    @loggedIn
    def sendGIF(self, to, path):
        return self.uploadObjTalk(path=path, type='gif', returnAs='bool', to=to)

    @loggedIn
    def sendGIFWithURL(self, to, url):
        path = self.downloadFileURL(url, 'path')
        return self.sendGIF(to, path)

    @loggedIn
    def sendVideo(self, to, path):
        objectId = self.sendMessage(to=to, text=None, contentMetadata={'VIDLEN': '60000','DURATION': '60000'}, contentType = 2).id
        return self.uploadObjTalk(path=path, type='video', returnAs='bool', objId=objectId)

    @loggedIn
    def sendVideoWithURL(self, to, url):
        path = self.downloadFileURL(url, 'path')
        return self.sendVideo(to, path)

    @loggedIn
    def sendAudio(self, to, path):
        objectId = self.sendMessage(to=to, text=None, contentType = 3).id
        return self.uploadObjTalk(path=path, type='audio', returnAs='bool', objId=objectId)

    @loggedIn
    def sendAudioWithURL(self, to, url):
        path = self.downloadFileURL(url, 'path')
        return self.sendAudio(to, path)

    @loggedIn
    def sendFile(self, to, path, file_name=''):
        if file_name == '':
            file_name = ntpath.basename(path)
        file_size = len(open(path, 'rb').read())
        objectId = self.sendMessage(to=to, text=None, contentMetadata={'FILE_NAME': str(file_name),'FILE_SIZE': str(file_size)}, contentType = 14).id
        return self.uploadObjTalk(path=path, type='file', returnAs='bool', objId=objectId)

    @loggedIn
    def sendFileWithURL(self, to, url, fileName=''):
        path = self.downloadFileURL(url, 'path')
        return self.sendFile(to, path, fileName)

    """Contact"""
        
    @loggedIn
    def blockContact(self, mid):
        return self.talk.blockContact(0, mid)

    @loggedIn
    def unblockContact(self, mid):
        return self.talk.unblockContact(0, mid)

    @loggedIn
    def findAndAddContactByMetaTag(self, userid, reference):
        return self.talk.findAndAddContactByMetaTag(0, userid, reference)

    @loggedIn
    def findAndAddContactsByMid(self, mid):
        return self.talk.findAndAddContactsByMid(0, mid, 0, '')

    @loggedIn
    def findAndAddContactsByEmail(self, emails=[]):
        return self.talk.findAndAddContactsByEmail(0, emails)

    @loggedIn
    def findAndAddContactsByUserid(self, userid):
        return self.talk.findAndAddContactsByUserid(0, userid)

    @loggedIn
    def findContactsByUserid(self, userid):
        return self.talk.findContactByUserid(userid)

    @loggedIn
    def findContactByTicket(self, ticketId):
        return self.talk.findContactByUserTicket(ticketId)

    @loggedIn
    def getAllContactIds(self):
        return self.talk.getAllContactIds()

    @loggedIn
    def getBlockedContactIds(self):
        return self.talk.getBlockedContactIds()

    @loggedIn
    def getContact(self, mid):
        return self.talk.getContact(mid)

    @loggedIn
    def getContacts(self, midlist):
        return self.talk.getContacts(midlist)

    @loggedIn
    def getFavoriteMids(self):
        return self.talk.getFavoriteMids()

    @loggedIn
    def getHiddenContactMids(self):
        return self.talk.getHiddenContactMids()

    @loggedIn
    def tryFriendRequest(self, midOrEMid, friendRequestParams, method=1):
        return self.talk.tryFriendRequest(midOrEMid, method, friendRequestParams)

    @loggedIn
    def makeUserAddMyselfAsContact(self, contactOwnerMid):
        return self.talk.makeUserAddMyselfAsContact(contactOwnerMid)

    @loggedIn
    def getContactWithFriendRequestStatus(self, id):
        return self.talk.getContactWithFriendRequestStatus(id)

    @loggedIn
    def reissueUserTicket(self, expirationTime=100, maxUseCount=100):
        return self.talk.reissueUserTicket(expirationTime, maxUseCount)
    
    @loggedIn
    def cloneContactProfile(self, mid):
        contact = self.getContact(mid)
        profile = self.profile
        profile.displayName = contact.displayName
        profile.statusMessage = contact.statusMessage
        profile.pictureStatus = contact.pictureStatus
        if self.getProfileCoverId(mid) is not None:
            self.updateProfileCoverById(self.getProfileCoverId(mid))
        self.updateProfileAttribute(8, profile.pictureStatus)
        return self.updateProfile(profile)

    """Group"""

    @loggedIn
    def getChatRoomAnnouncementsBulk(self, chatRoomMids):
        return self.talk.getChatRoomAnnouncementsBulk(chatRoomMids)

    @loggedIn
    def getChatRoomAnnouncements(self, chatRoomMid):
        return self.talk.getChatRoomAnnouncements(chatRoomMid)

    @loggedIn
    def createChatRoomAnnouncement(self, chatRoomMid, type, contents):
        return self.talk.createChatRoomAnnouncement(0, chatRoomMid, type, contents)

    @loggedIn
    def removeChatRoomAnnouncement(self, chatRoomMid, announcementSeq):
        return self.talk.removeChatRoomAnnouncement(0, chatRoomMid, announcementSeq)
#pembatas
    @loggedIn
    def getGroupWithoutMembers(self, groupId):
        return self.talk.getGroupWithoutMembers(groupId)
        
    @loggedIn
    def getGroupWithoutMembers(self1, groupId):
        return self1.talk.getGroupWithoutMembers(groupId)
        
    @loggedIn
    def getGroupWithoutMembers(self2, groupId):
        return self2.talk.getGroupWithoutMembers(groupId)
        
    @loggedIn
    def getGroupWithoutMembers(self3, groupId):
        return sel3.talk.getGroupWithoutMembers(groupId)
        
    @loggedIn
    def getGroupWithoutMembers(self4, groupId):
        return self4.talk.getGroupWithoutMembers(groupId)
        
    @loggedIn
    def getGroupWithoutMembers(self5, groupId):
        return self5.talk.getGroupWithoutMembers(groupId)
        
    @loggedIn
    def getGroupWithoutMembers(self6, groupId):
        return self6.talk.getGroupWithoutMembers(groupId)
        
    @loggedIn
    def getGroupWithoutMembers(self7, groupId):
        return self7.talk.getGroupWithoutMembers(groupId)
        
    @loggedIn
    def getGroupWithoutMembers(self8, groupId):
        return self8.talk.getGroupWithoutMembers(groupId)
    
    @loggedIn
    def findGroupByTicket(self, ticketId):
        return self.talk.findGroupByTicket(ticketId)
        
    @loggedIn
    def findGroupByTicket(self1, ticketId):
        return self1.talk.findGroupByTicket(ticketId)
        
    @loggedIn
    def findGroupByTicket(self2, ticketId):
        return self2.talk.findGroupByTicket(ticketId)
        
    @loggedIn
    def findGroupByTicket(self3, ticketId):
        return self3.talk.findGroupByTicket(ticketId)
        
    @loggedIn
    def findGroupByTicket(self4, ticketId):
        return self4.talk.findGroupByTicket(ticketId)
        
    @loggedIn
    def findGroupByTicket(self5, ticketId):
        return self5.talk.findGroupByTicket(ticketId)
        
    @loggedIn
    def findGroupByTicket(self6, ticketId):
        return self6.talk.findGroupByTicket(ticketId)
        
    @loggedIn
    def findGroupByTicket(self7, ticketId):
        return self7.talk.findGroupByTicket(ticketId)
        
    @loggedIn
    def findGroupByTicket(self8, ticketId):
        return self8.talk.findGroupByTicket(ticketId)

    @loggedIn
    def acceptGroupInvitation(self, groupId):
        return self.talk.acceptGroupInvitation(0, groupId)
        
    @loggedIn
    def acceptGroupInvitation(self1, groupId):
        return self1.talk.acceptGroupInvitation(0, groupId)
        
    @loggedIn
    def acceptGroupInvitation(self2, groupId):
        return self2.talk.acceptGroupInvitation(0, groupId)
        
    @loggedIn
    def acceptGroupInvitation(self3, groupId):
        return self3.talk.acceptGroupInvitation(0, groupId)
        
    @loggedIn
    def acceptGroupInvitation(self4, groupId):
        return self4.talk.acceptGroupInvitation(0, groupId)
        
    @loggedIn
    def acceptGroupInvitation(self5, groupId):
        return self5.talk.acceptGroupInvitation(0, groupId)
        
    @loggedIn
    def acceptGroupInvitation(self6, groupId):
        return self6.talk.acceptGroupInvitation(0, groupId)
        
    @loggedIn
    def acceptGroupInvitation(self7, groupId):
        return self7.talk.acceptGroupInvitation(0, groupId)
        
    @loggedIn
    def acceptGroupInvitation(self8, groupId):
        return self8.talk.acceptGroupInvitation(0, groupId)

    @loggedIn
    def acceptGroupInvitationByTicket(self, groupId, ticketId):
        return self.talk.acceptGroupInvitationByTicket(0, groupId, ticketId)
        
    @loggedIn
    def acceptGroupInvitationByTicket(self1, groupId, ticketId):
        return self1.talk.acceptGroupInvitationByTicket(0, groupId, ticketId)
        
    @loggedIn
    def acceptGroupInvitationByTicket(self2, groupId, ticketId):
        return self2.talk.acceptGroupInvitationByTicket(0, groupId, ticketId)
        
    @loggedIn
    def acceptGroupInvitationByTicket(self3, groupId, ticketId):
        return self3.talk.acceptGroupInvitationByTicket(0, groupId, ticketId)
        
    @loggedIn
    def acceptGroupInvitationByTicket(self4, groupId, ticketId):
        return self4.talk.acceptGroupInvitationByTicket(0, groupId, ticketId)
        
    @loggedIn
    def acceptGroupInvitationByTicket(self5, groupId, ticketId):
        return self5.talk.acceptGroupInvitationByTicket(0, groupId, ticketId)
        
    @loggedIn
    def acceptGroupInvitationByTicket(self6, groupId, ticketId):
        return self6.talk.acceptGroupInvitationByTicket(0, groupId, ticketId)
        
    @loggedIn
    def acceptGroupInvitationByTicket(self7, groupId, ticketId):
        return self7.talk.acceptGroupInvitationByTicket(0, groupId, ticketId)
        
    @loggedIn
    def acceptGroupInvitationByTicket(self8, groupId, ticketId):
        return self8.talk.acceptGroupInvitationByTicket(0, groupId, ticketId)

    @loggedIn
    def cancelGroupInvitation(self, groupId, contactIds):
        return self.talk.cancelGroupInvitation(0, groupId, contactIds)
        
    @loggedIn
    def cancelGroupInvitation(self1, groupId, contactIds):
        return self1.talk.cancelGroupInvitation(0, groupId, contactIds)
        
    @loggedIn
    def cancelGroupInvitation(self2, groupId, contactIds):
        return self2.talk.cancelGroupInvitation(0, groupId, contactIds)
        
    @loggedIn
    def cancelGroupInvitation(self3, groupId, contactIds):
        return self3.talk.cancelGroupInvitation(0, groupId, contactIds)
        
    @loggedIn
    def cancelGroupInvitation(self4, groupId, contactIds):
        return self4.talk.cancelGroupInvitation(0, groupId, contactIds)
        
    @loggedIn
    def cancelGroupInvitation(self5, groupId, contactIds):
        return self5.talk.cancelGroupInvitation(0, groupId, contactIds)
        
    @loggedIn
    def cancelGroupInvitation(self6, groupId, contactIds):
        return self6.talk.cancelGroupInvitation(0, groupId, contactIds)
        
    @loggedIn
    def cancelGroupInvitation(self7, groupId, contactIds):
        return self7.talk.cancelGroupInvitation(0, groupId, contactIds)
        
    @loggedIn
    def cancelGroupInvitation(self8, groupId, contactIds):
        return self8.talk.cancelGroupInvitation(0, groupId, contactIds)
#pembatas
    @loggedIn
    def createGroup(self, name, midlist):
        return self.talk.createGroup(0, name, midlist)

    @loggedIn
    def getGroup(self, groupId):
        return self.talk.getGroup(groupId)
        
    @loggedIn
    def getGroup(self1, groupId):
        return self1.talk.getGroup(groupId)
        
    @loggedIn
    def getGroup(self2, groupId):
        return self2.talk.getGroup(groupId)
        
    @loggedIn
    def getGroup(self3, groupId):
        return self3.talk.getGroup(groupId)
        
    @loggedIn
    def getGroup(self4, groupId):
        return self4.talk.getGroup(groupId)
        
    @loggedIn
    def getGroup(self5, groupId):
        return self5.talk.getGroup(groupId)
        
    @loggedIn
    def getGroup(self6, groupId):
        return self6.talk.getGroup(groupId)
        
    @loggedIn
    def getGroup(self7, groupId):
        return self7.talk.getGroup(groupId)
        
    @loggedIn
    def getGroup(self8, groupId):
        return self8.talk.getGroup(groupId)

    @loggedIn
    def getGroups(self, groupIds):
        return self.talk.getGroups(groupIds)
        
    @loggedIn
    def getGroups(self1, groupIds):
        return self1.talk.getGroups(groupIds)
        
    @loggedIn
    def getGroups(self2, groupIds):
        return self2.talk.getGroups(groupIds)
        
    @loggedIn
    def getGroups(self3, groupIds):
        return self3.talk.getGroups(groupIds)
        
    @loggedIn
    def getGroups(self4, groupIds):
        return self4.talk.getGroups(groupIds)
        
    @loggedIn
    def getGroups(self5, groupIds):
        return self5.talk.getGroups(groupIds)
        
    @loggedIn
    def getGroups(self6, groupIds):
        return self6.talk.getGroups(groupIds)
        
    @loggedIn
    def getGroups(self7, groupIds):
        return self7.talk.getGroups(groupIds)
        
    @loggedIn
    def getGroups(self8, groupIds):
        return self8.talk.getGroups(groupIds)

    @loggedIn
    def getGroupsV2(self, groupIds):
        return self.talk.getGroupsV2(groupIds)
        
    @loggedIn
    def getGroupsV2(self1, groupIds):
        return self1.talk.getGroupsV2(groupIds)
        
    @loggedIn
    def getGroupsV2(self2, groupIds):
        return self2.talk.getGroupsV2(groupIds)
        
    @loggedIn
    def getGroupsV2(self3, groupIds):
        return self3.talk.getGroupsV2(groupIds)
        
    @loggedIn
    def getGroupsV2(self4, groupIds):
        return self4.talk.getGroupsV2(groupIds)
        
    @loggedIn
    def getGroupsV2(self5, groupIds):
        return self5.talk.getGroupsV2(groupIds)
        
    @loggedIn
    def getGroupsV2(self6, groupIds):
        return self6.talk.getGroupsV2(groupIds)
        
    @loggedIn
    def getGroupsV2(self7, groupIds):
        return self7.talk.getGroupsV2(groupIds)
        
    @loggedIn
    def getGroupsV2(self8, groupIds):
        return self8.talk.getGroupsV2(groupIds)

    @loggedIn
    def getCompactGroup(self, groupId):
        return self.talk.getCompactGroup(groupId)
        
    @loggedIn
    def getCompactGroup(self1, groupId):
        return self1.talk.getCompactGroup(groupId)
        
    @loggedIn
    def getCompactGroup(self2, groupId):
        return self2.talk.getCompactGroup(groupId)
        
    @loggedIn
    def getCompactGroup(self3, groupId):
        return self3.talk.getCompactGroup(groupId)
        
    @loggedIn
    def getCompactGroup(self4, groupId):
        return self4.talk.getCompactGroup(groupId)
        
    @loggedIn
    def getCompactGroup(self5, groupId):
        return self5.talk.getCompactGroup(groupId)
        
    @loggedIn
    def getCompactGroup(self6, groupId):
        return self6.talk.getCompactGroup(groupId)
        
    @loggedIn
    def getCompactGroup(self7, groupId):
        return self7.talk.getCompactGroup(groupId)
        
    @loggedIn
    def getCompactGroup(self8, groupId):
        return self8.talk.getCompactGroup(groupId)

    @loggedIn
    def getCompactRoom(self, roomId):
        return self.talk.getCompactRoom(roomId)
        
    @loggedIn
    def getCompactRoom(self1, roomId):
        return self1.talk.getCompactRoom(roomId)
        
    @loggedIn
    def getCompactRoom(self2, roomId):
        return self2.talk.getCompactRoom(roomId)
        
    @loggedIn
    def getCompactRoom(self3, roomId):
        return self3.talk.getCompactRoom(roomId)
        
    @loggedIn
    def getCompactRoom(self4, roomId):
        return self4.talk.getCompactRoom(roomId)
        
    @loggedIn
    def getCompactRoom(self5, roomId):
        return self5.talk.getCompactRoom(roomId)
        
    @loggedIn
    def getCompactRoom(self6, roomId):
        return self6.talk.getCompactRoom(roomId)
        
    @loggedIn
    def getCompactRoom(self7, roomId):
        return self7.talk.getCompactRoom(roomId)
        
    @loggedIn
    def getCompactRoom(self8, roomId):
        return self8.talk.getCompactRoom(roomId)
#pembatas
    @loggedIn
    def getGroupIdsByName(self, groupName):
        gIds = []
        for gId in self.getGroupIdsJoined():
            g = self.getCompactGroup(gId)
            if groupName in g.name:
                gIds.append(gId)
        return gIds

    @loggedIn
    def getGroupIdsInvited(self):
        return self.talk.getGroupIdsInvited()
        
    @loggedIn
    def getGroupIdsInvited(self1):
        return self1.talk.getGroupIdsInvited()
        
    @loggedIn
    def getGroupIdsInvited(self2):
        return self2.talk.getGroupIdsInvited()
        
    @loggedIn
    def getGroupIdsInvited(self3):
        return self3.talk.getGroupIdsInvited()
        
    @loggedIn
    def getGroupIdsInvited(self4):
        return self4.talk.getGroupIdsInvited()
        
    @loggedIn
    def getGroupIdsInvited(self5):
        return self5.talk.getGroupIdsInvited()
        
    @loggedIn
    def getGroupIdsInvited(self6):
        return self6.talk.getGroupIdsInvited()
        
    @loggedIn
    def getGroupIdsInvited(self7):
        return self7.talk.getGroupIdsInvited()
        
    @loggedIn
    def getGroupIdsInvited(self8):
        return self8.talk.getGroupIdsInvited()
#pembatas
    @loggedIn
    def getGroupIdsJoined(self):
        return self.talk.getGroupIdsJoined()
        
    @loggedIn
    def getGroupIdsJoined(self1):
        return self1.talk.getGroupIdsJoined()
        
    @loggedIn
    def getGroupIdsJoined(self2):
        return self2.talk.getGroupIdsJoined()
        
    @loggedIn
    def getGroupIdsJoined(self3):
        return self3.talk.getGroupIdsJoined()
        
    @loggedIn
    def getGroupIdsJoined(self4):
        return self4.talk.getGroupIdsJoined()
        
    @loggedIn
    def getGroupIdsJoined(self5):
        return self5.talk.getGroupIdsJoined()
        
    @loggedIn
    def getGroupIdsJoined(self6):
        return self6.talk.getGroupIdsJoined()
        
    @loggedIn
    def getGroupIdsJoined(self7):
        return self7.talk.getGroupIdsJoined()
        
    @loggedIn
    def getGroupIdsJoined(self8):
        return self8.talk.getGroupIdsJoined()
#pembatas
    @loggedIn
    def updateGroupPreferenceAttribute(self, groupMid, updatedAttrs):
        return self.talk.updateGroupPreferenceAttribute(0, groupMid, updatedAttrs)
#pembatas
    @loggedIn
    def inviteIntoGroup(self, groupId, midlist):
        return self.talk.inviteIntoGroup(0, groupId, midlist)
        
    @loggedIn
    def inviteIntoGroup(self1, groupId, midlist):
        return self1.talk.inviteIntoGroup(0, groupId, midlist)
        
    @loggedIn
    def inviteIntoGroup(self2, groupId, midlist):
        return self2.talk.inviteIntoGroup(0, groupId, midlist)
        
    @loggedIn
    def inviteIntoGroup(self3, groupId, midlist):
        return self3.talk.inviteIntoGroup(0, groupId, midlist)
        
    @loggedIn
    def inviteIntoGroup(self4, groupId, midlist):
        return self4.talk.inviteIntoGroup(0, groupId, midlist)
        
    @loggedIn
    def inviteIntoGroup(self5, groupId, midlist):
        return self5.talk.inviteIntoGroup(0, groupId, midlist)
        
    @loggedIn
    def inviteIntoGroup(self6, groupId, midlist):
        return self6.talk.inviteIntoGroup(0, groupId, midlist)
        
    @loggedIn
    def inviteIntoGroup(self7, groupId, midlist):
        return self7.talk.inviteIntoGroup(0, groupId, midlist)
        
    @loggedIn
    def inviteIntoGroup(self8, groupId, midlist):
        return self8.talk.inviteIntoGroup(0, groupId, midlist)
#pembatas
    @loggedIn
    def kickoutFromGroup(self, groupId, midlist):
        return self.talk.kickoutFromGroup(0, groupId, midlist)
        
    @loggedIn
    def kickoutFromGroup(self1, groupId, midlist):
        return self1.talk.kickoutFromGroup(0, groupId, midlist)
        
    @loggedIn
    def kickoutFromGroup(self2, groupId, midlist):
        return self2.talk.kickoutFromGroup(0, groupId, midlist)
        
    @loggedIn
    def kickoutFromGroup(self3, groupId, midlist):
        return self3.talk.kickoutFromGroup(0, groupId, midlist)
        
    @loggedIn
    def kickoutFromGroup(self4, groupId, midlist):
        return self4.talk.kickoutFromGroup(0, groupId, midlist)
        
    @loggedIn
    def kickoutFromGroup(self5, groupId, midlist):
        return self5.talk.kickoutFromGroup(0, groupId, midlist)
        
    @loggedIn
    def kickoutFromGroup(self6, groupId, midlist):
        return self6.talk.kickoutFromGroup(0, groupId, midlist)
        
    @loggedIn
    def kickoutFromGroup(self7, groupId, midlist):
        return self7.talk.kickoutFromGroup(0, groupId, midlist)
        
    @loggedIn
    def kickoutFromGroup(self8, groupId, midlist):
        return self8.talk.kickoutFromGroup(0, groupId, midlist)
#pembatas
    @loggedIn
    def leaveGroup(self, groupId):
        return self.talk.leaveGroup(0, groupId)
#pembatas
    @loggedIn
    def rejectGroupInvitation(self, groupId):
        return self.talk.rejectGroupInvitation(0, groupId)
#pembatas
    @loggedIn
    def reissueGroupTicket(self, groupId):
        return self.talk.reissueGroupTicket(groupId)
#pembatas
    @loggedIn
    def updateGroup(self, groupObject):
        return self.talk.updateGroup(0, groupObject)
#pembatas
    """Room"""

    @loggedIn
    def createRoom(self, midlist):
        return self.talk.createRoom(0, midlist)
#pembatas
    @loggedIn
    def getRoom(self, roomId):
        return self.talk.getRoom(roomId)
        
    @loggedIn
    def getRoom(self1, roomId):
        return self1.talk.getRoom(roomId)
        
    @loggedIn
    def getRoom(self2, roomId):
        return self2.talk.getRoom(roomId)
        
    @loggedIn
    def getRoom(self3, roomId):
        return self3.talk.getRoom(roomId)
        
    @loggedIn
    def getRoom(self4, roomId):
        return self4.talk.getRoom(roomId)
        
    @loggedIn
    def getRoom(self5, roomId):
        return self5.talk.getRoom(roomId)
        
    @loggedIn
    def getRoom(self6, roomId):
        return self6.talk.getRoom(roomId)
        
    @loggedIn
    def getRoom(self7, roomId):
        return self7.talk.getRoom(roomId)
        
    @loggedIn
    def getRoom(self8, roomId):
        return self8.talk.getRoom(roomId)
#pembatas
    @loggedIn
    def inviteIntoRoom(self, roomId, midlist):
        return self.talk.inviteIntoRoom(0, roomId, midlist)
        
    @loggedIn
    def inviteIntoRoom(self1, roomId, midlist):
        return self1.talk.inviteIntoRoom(0, roomId, midlist)
        
    @loggedIn
    def inviteIntoRoom(self2, roomId, midlist):
        return self2.talk.inviteIntoRoom(0, roomId, midlist)
        
    @loggedIn
    def inviteIntoRoom(self3, roomId, midlist):
        return self3.talk.inviteIntoRoom(0, roomId, midlist)
        
    @loggedIn
    def inviteIntoRoom(self4, roomId, midlist):
        return self4.talk.inviteIntoRoom(0, roomId, midlist)
        
    @loggedIn
    def inviteIntoRoom(self5, roomId, midlist):
        return self5.talk.inviteIntoRoom(0, roomId, midlist)
        
    @loggedIn
    def inviteIntoRoom(self6, roomId, midlist):
        return self6.talk.inviteIntoRoom(0, roomId, midlist)
        
    @loggedIn
    def inviteIntoRoom(self7, roomId, midlist):
        return self7.talk.inviteIntoRoom(0, roomId, midlist)
        
    @loggedIn
    def inviteIntoRoom(self8, roomId, midlist):
        return self8.talk.inviteIntoRoom(0, roomId, midlist)
#pembatas
    @loggedIn
    def leaveRoom(self, roomId):
        return self.talk.leaveRoom(0, roomId)
        
    @loggedIn
    def leaveRoom(self1, roomId):
        return self1.talk.leaveRoom(0, roomId)
        
    @loggedIn
    def leaveRoom(self2, roomId):
        return self2.talk.leaveRoom(0, roomId)
        
    @loggedIn
    def leaveRoom(self3, roomId):
        return self3.talk.leaveRoom(0, roomId)
        
    @loggedIn
    def leaveRoom(self4, roomId):
        return self4.talk.leaveRoom(0, roomId)
        
    @loggedIn
    def leaveRoom(self5, roomId):
        return self5.talk.leaveRoom(0, roomId)
        
    @loggedIn
    def leaveRoom(self6, roomId):
        return self6.talk.leaveRoom(0, roomId)
        
    @loggedIn
    def leaveRoom(self7, roomId):
        return self7.talk.leaveRoom(0, roomId)
        
    @loggedIn
    def leaveRoom(self8, roomId):
        return self8.talk.leaveRoom(0, roomId)
#pembatas
    """Call"""
        
    @loggedIn
    def acquireCallTalkRoute(self, to):
        return self.talk.acquireCallRoute(to)
    
    """Report"""

    @loggedIn
    def reportSpam(self, chatMid, memberMids=[], spammerReasons=[], senderMids=[], spamMessageIds=[], spamMessages=[]):
        return self.talk.reportSpam(chatMid, memberMids, spammerReasons, senderMids, spamMessageIds, spamMessages)
        
    @loggedIn
    def reportSpammer(self, spammerMid, spammerReasons=[], spamMessageIds=[]):
        return self.talk.reportSpammer(spammerMid, spammerReasons, spamMessageIds)
#finish